package dev.lumen.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

import dev.lumen.core.Category;
import dev.lumen.core.Config;
import dev.lumen.core.Module;
import dev.lumen.core.Modules;
import dev.lumen.core.Setting;
import dev.lumen.core.Theme;
import dev.lumen.hud.HudRenderer;
import dev.lumen.hud.HudWidget;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import dev.lumen.util.Fonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

/**
 * Меню на Right Shift в стиле «liquid glass». Открывается/закрывается плавно (масштаб + прозрачность + сдвиг).
 * ЛКМ по модулю — вкл/выкл, ПКМ — настройки. HUD-элементы таскаются мышью за пределами панели.
 */
public final class MenuScreen extends Screen {
	private static final int PW = 414, PH = 256, SB = 106;
	private static final int CX = SB + 8, CW = PW - CX - 14, VY0 = 42, VY1 = PH - 12;
	private static final int CARD = 28, ROW = 19;
	private static final float OPEN_TIME = 0.30f;

	private static Category lastCat = Category.HUD;

	private interface FloatCb { void run(float v); }

	private record Region(float x, float y, float w, float h, IntConsumer click, FloatCb drag) {
		boolean has(float px, float py) {
			return px >= x && px <= x + w && py >= y && py <= y + h;
		}
	}

	private final Anim.Timer timer = new Anim.Timer();
	private final List<Region> regions = new ArrayList<>();
	private Category cat = lastCat;
	private float t, scale = 1f, alpha = 1f, offY;
	private boolean closing;
	private float scroll, scrollTarget, contentH, catY = -1f;
	private Region activeDrag;
	private HudWidget dragWidget;
	private float dragOx, dragOy;

	public MenuScreen() {
		super(Component.literal("Lumen"));
	}

	public HudWidget draggingWidget() {
		return dragWidget;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		closing = true;
	}

	@Override
	public void removed() {
		Config.save();
	}

	// ───────────────────────── координаты ─────────────────────────

	private float lx(double mx) {
		return (float) ((mx - width / 2.0) / scale + PW / 2.0);
	}

	private float ly(double my) {
		return (float) ((my - height / 2.0 - offY) / scale + PH / 2.0);
	}

	private int c(int color) {
		return Draw.a(color, alpha);
	}

	private static boolean in(float px, float py, float x, float y, float w, float h) {
		return px >= x && px <= x + w && py >= y && py <= y + h;
	}

	private void zone(float x, float y, float w, float h, IntConsumer click, FloatCb drag) {
		float y1 = Math.max(y, VY0), y2 = Math.min(y + h, VY1);
		if (y2 <= y1) return;
		regions.add(new Region(x, y1, w, y2 - y1, click, drag));
	}

	// ───────────────────────── рендер ─────────────────────────

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		float d = timer.tick();
		Anim.dt = d;
		t = Mth.clamp(t + (closing ? -d : d) / OPEN_TIME, 0f, 1f);
		if (closing && t <= 0f) {
			Minecraft.getInstance().setScreen(null);
			return;
		}
		alpha = Anim.smooth(Mth.clamp(t * 1.6f, 0f, 1f));
		float pop = closing ? Anim.easeOut(t) : Anim.easeOutBack(t);
		float fit = Math.min(1f, Math.min(width / (PW + 16f), height / (PH + 16f)));
		scale = fit * (0.84f + 0.16f * pop);
		offY = (1f - Anim.easeOut(t)) * 18f;

		g.fill(0, 0, width, height, Draw.a(0xFF000000, 0.46f * alpha));

		float lx = lx(mx), ly = ly(my);
		regions.clear();
		Matrix3x2fStack ps = g.pose();
		ps.pushMatrix();
		ps.translate(width / 2f, height / 2f + offY);
		ps.scale(scale, scale);
		ps.translate(-PW / 2f, -PH / 2f);
		drawPanel(g, lx, ly);
		ps.popMatrix();

		String hint = "Drag HUD elements outside the menu to move them";
		Draw.text(g, hint, (width - Draw.width(hint) * 0.8f) / 2f, height - 12, 0.8f, c(0xFFB8C0CE), true);
	}

	private void drawPanel(GuiGraphics g, float lx, float ly) {
		Draw.shadow(g, 0, 0, PW, PH, 10, alpha);
		Draw.glass(g, 0, 0, PW, PH, 10, Math.min(1f, alpha * 1.25f));

		// ── боковая панель ──
		Draw.rounded(g, 7, 7, SB - 7, PH - 14, 8, c(0x55000000));
		String logo = "LUMEN";
		float lxx = 18;
		for (int i = 0; i < logo.length(); i++) {
			String ch = String.valueOf(logo.charAt(i));
			Draw.text(g, ch, lxx, 17, 1.45f, c(Draw.lerp(Theme.accent(), Theme.accent2(), i / 4f)), true);
			lxx += Draw.width(ch) * 1.45f + 1f;
		}
		Draw.text(g, "VISUALS", 19, 33, 0.72f, c(Theme.MUTED), false);

		float targetY = 54 + cat.ordinal() * 26;
		catY = catY < 0 ? targetY : Anim.approach(catY, targetY, 16f);
		Draw.rounded(g, 11, catY, SB - 15, 22, 7, c(0x1CFFFFFF));
		Draw.glow(g, 14, catY + 11, 26, c(Draw.a(Theme.accent(), 0.5f)));
		g.fill(11, Math.round(catY) + 5, 13, Math.round(catY) + 17, c(Theme.accent()));

		for (Category k : Category.values()) {
			float y = 54 + k.ordinal() * 26;
			boolean hov = in(lx, ly, 11, y, SB - 15, 22);
			int col = k == cat ? Theme.TEXT : hov ? 0xFFD5D5E4 : Theme.MUTED;
			Draw.text(g, k.label, 24, y + 7, c(col));
			regions.add(new Region(11, y, SB - 15, 22, b -> setCat(k), null));
		}
		Draw.text(g, "RShift - close", 18, PH - 22, 0.72f, c(0xFF62627A), false);

		// ── заголовок ──
		Draw.text(g, cat.label, CX, 13, 1.4f, c(Theme.TEXT), true);
		String tip = "LMB toggle  |  RMB settings";
		Draw.text(g, tip, CX + CW - Draw.width(tip) * 0.72f, 18, 0.72f, c(Theme.MUTED), false);
		g.fill(CX, 33, CX + CW, 34, c(0x16FFFFFF));

		// ── список модулей ──
		float maxScroll = Math.max(0f, contentH - (VY1 - VY0));
		scrollTarget = Mth.clamp(scrollTarget, 0f, maxScroll);
		scroll = Anim.approach(scroll, scrollTarget, 16f);

		g.enableScissor(CX - 2, VY0, CX + CW + 2, VY1);
		float yy = VY0 - scroll;
		for (Module m : Modules.ALL) {
			if (m.category != cat) continue;
			m.guiToggle = Anim.approach(m.guiToggle, m.enabled ? 1f : 0f, 16f);
			m.guiExpand = Anim.approach(m.guiExpand, m.expanded ? 1f : 0f, 14f);
			float h = CARD + (m.settings.isEmpty() ? 0 : Math.round(m.guiExpand * (m.settings.size() * ROW + 6)));
			if (yy + h > VY0 - 2 && yy < VY1 + 2) drawCard(g, m, CX, yy, CW, h, lx, ly);
			yy += h + 6;
		}
		contentH = yy + scroll - VY0;
		g.disableScissor();

		if (maxScroll > 1f) {
			float trackH = VY1 - VY0;
			float barH = Math.max(14f, trackH * trackH / contentH);
			float by = VY0 + (trackH - barH) * (scroll / maxScroll);
			Draw.rounded(g, CX + CW + 5, by, 2, barH, 1, c(Draw.a(Theme.accent(), 0.7f)));
		}
	}

	private void setCat(Category k) {
		cat = k;
		lastCat = k;
		scroll = scrollTarget = 0f;
		contentH = 0f;
	}

	// ───────────────────────── карточка модуля ─────────────────────────

	private void drawCard(GuiGraphics g, Module m, float x, float y, float w, float h, float lx, float ly) {
		boolean hov = in(lx, ly, x, y, w, CARD) && ly >= VY0 && ly <= VY1;
		Draw.rounded(g, x, y, w, h, 8, c(hov ? 0x20FFFFFF : 0x12FFFFFF));
		Draw.border(g, Math.round(x), Math.round(y), Math.round(w), Math.round(h), 8, c(0x0DFFFFFF));
		if (m.guiToggle > 0.01f) {
			Draw.glow(g, x + 3, y + CARD / 2f, 30, c(Draw.a(Theme.accent(), 0.45f * m.guiToggle)));
			g.fill(Math.round(x), Math.round(y) + 7, Math.round(x) + 2, Math.round(y) + CARD - 7,
				c(Draw.a(Theme.accent(), m.guiToggle)));
		}
		Draw.text(g, m.name, x + 11, y + 6, c(Draw.lerp(0xFFC9C9D8, Theme.TEXT, m.guiToggle)));
		Draw.text(g, Draw.clip(m.desc, 170), x + 11, y + 17, 0.72f, c(Theme.MUTED), false);

		float sx = x + w - 36;
		if (m.toggleable) drawSwitch(g, sx, y + 8, 26, 12, m.guiToggle, alpha);
		if (!m.settings.isEmpty()) {
			Draw.text(g, m.expanded ? "v" : ">", (m.toggleable ? sx - 14 : x + w - 18), y + 9, c(Theme.MUTED));
		}
		zone(x, y, w, CARD, b -> {
			if (b == 1 || !m.toggleable) {
				if (!m.settings.isEmpty()) m.expanded = !m.expanded;
			} else if (b == 0) {
				m.toggle();
			}
		}, null);

		if (m.guiExpand > 0.02f && !m.settings.isEmpty()) {
			g.enableScissor(Math.round(x), Math.round(Math.max(y, VY0)), Math.round(x + w), Math.round(Math.min(y + h, VY1)));
			float ea = m.guiExpand * alpha;
			for (int i = 0; i < m.settings.size(); i++) {
				drawSetting(g, m.settings.get(i), x, y + CARD + 3 + i * ROW, w, ea, m.guiExpand > 0.85f);
			}
			g.disableScissor();
		}
	}

	private static void drawSwitch(GuiGraphics g, float x, float y, float w, float h, float tg, float al) {
		Draw.rounded(g, x, y, w, h, (int) (h / 2), Draw.a(Draw.lerp(0x40FFFFFF, Theme.accent(), tg), al));
		float k = h - 4;
		float kx = x + 2 + (w - k - 4) * tg;
		Draw.rounded(g, kx, y + 2, k, k, (int) (k / 2), Draw.a(Draw.lerp(0xFFFFFFFF, 0xFF0B0B10, tg * 0.85f), al));
	}

	private void drawSetting(GuiGraphics g, Setting s, float x, float ry, float w, float al, boolean live) {
		Draw.text(g, s.name, x + 12, ry + 5, Draw.a(Theme.MUTED, al));
		switch (s.type) {
			case BOOL -> {
				s.anim = Anim.approach(s.anim, s.bool ? 1f : 0f, 18f);
				drawSwitch(g, x + w - 36, ry + 3, 22, 11, s.anim, al);
				if (live) zone(x, ry, w, ROW, b -> {
					s.bool = !s.bool;
					if (s == Modules.TH_FONT) Fonts.reset();
				}, null);
			}
			case NUM -> {
				float tx = x + w - 130, tw = 80, ty = ry + 8;
				float frac = (float) ((s.num - s.min) / (s.max - s.min));
				Draw.rounded(g, tx, ty, tw, 3, 1, Draw.a(0x40FFFFFF, al));
				Draw.rounded(g, tx, ty, Math.max(2f, tw * frac), 3, 1, Draw.a(Theme.accent(), al));
				Draw.glow(g, tx + tw * frac, ty + 1.5f, 16, Draw.a(Theme.accent(), al * 0.5f));
				Draw.rounded(g, tx + tw * frac - 3, ty - 2, 6, 7, 3, Draw.a(0xFFFFFFFF, al));
				String v = s.display();
				Draw.text(g, v, x + w - 11 - Draw.width(v), ry + 5, Draw.a(Theme.TEXT, al));
				if (live) {
					zone(tx - 4, ry, tw + 8, ROW, b -> {},
						mxl -> s.setNum(s.min + Mth.clamp((mxl - tx) / tw, 0f, 1f) * (s.max - s.min)));
				}
			}
			case MODE -> {
				float bx = x + w - 108, bw = 98;
				Draw.rounded(g, bx, ry + 2, bw, 15, 5, Draw.a(0x1FFFFFFF, al));
				String mn = s.modeName();
				Draw.text(g, mn, bx + (bw - Draw.width(mn)) / 2f, ry + 5, Draw.a(Theme.TEXT, al));
				Draw.text(g, "<", bx + 5, ry + 5, Draw.a(Theme.MUTED, al * 0.8f));
				Draw.text(g, ">", bx + bw - 10, ry + 5, Draw.a(Theme.MUTED, al * 0.8f));
				if (live) zone(bx, ry, bw, ROW, b -> s.cycle(b == 1 ? -1 : 1), null);
			}
		}
	}

	// ───────────────────────── ввод ─────────────────────────

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		if (closing) return true;
		float lx = lx(e.x()), ly = ly(e.y());
		int b = e.button();

		for (int i = regions.size() - 1; i >= 0; i--) {
			Region r = regions.get(i);
			if (!r.has(lx, ly)) continue;
			r.click().accept(b);
			if (r.drag() != null && b == 0) {
				activeDrag = r;
				r.drag().run(lx);
			}
			return true;
		}
		if (in(lx, ly, 0, 0, PW, PH)) return true;

		List<HudWidget> ws = HudRenderer.widgets();
		for (int i = ws.size() - 1; i >= 0; i--) {
			HudWidget w = ws.get(i);
			if (w.module.enabled && w.contains(e.x(), e.y())) {
				dragWidget = w;
				dragOx = (float) e.x() - w.px;
				dragOy = (float) e.y() - w.py;
				return true;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
		if (activeDrag != null && activeDrag.drag() != null) {
			activeDrag.drag().run(lx(e.x()));
			return true;
		}
		if (dragWidget != null) {
			dragWidget.moveTo((float) e.x() - dragOx, (float) e.y() - dragOy, width, height);
			return true;
		}
		return super.mouseDragged(e, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent e) {
		boolean had = activeDrag != null || dragWidget != null;
		activeDrag = null;
		dragWidget = null;
		if (had) Config.save();
		return had || super.mouseReleased(e);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double sx, double sy) {
		scrollTarget -= (float) sy * 26f;
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		if (e.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
			onClose();
			return true;
		}
		return super.keyPressed(e);
	}
}
