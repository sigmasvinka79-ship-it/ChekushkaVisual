package dev.lumen.hud;

import dev.lumen.core.Config;
import dev.lumen.core.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Базовый перетаскиваемый HUD-элемент. Позиция хранится в долях экрана. */
public abstract class HudWidget {
	public final Module module;
	public float fx, fy;
	/** Последние нарисованные координаты и размер (в GUI-пикселях). */
	public float px, py, w, h;

	protected HudWidget(Module module, float defX, float defY) {
		this.module = module;
		float[] p = Config.POS.get(module.name);
		this.fx = p != null ? p[0] : defX;
		this.fy = p != null ? p[1] : defY;
	}

	public final void draw(GuiGraphics g, float pt, int sw, int sh, float alpha) {
		px = Mth.clamp(fx * sw, 0f, Math.max(0f, sw - w));
		py = Mth.clamp(fy * sh, 0f, Math.max(0f, sh - h));
		render(g, px, py, pt, sw, sh, alpha);
	}

	protected abstract void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a);

	public boolean contains(double mx, double my) {
		return w > 0 && mx >= px - 3 && mx <= px + w + 3 && my >= py - 3 && my <= py + h + 3;
	}

	public void moveTo(float nx, float ny, int sw, int sh) {
		fx = nx / sw;
		fy = ny / sh;
	}
}
