package dev.lumen.hud;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dev.lumen.core.Module;
import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.GuiGraphics;

/** Список включённых модулей справа, как в чит-клиентах: выезжает и плавно перестраивается. */
public final class ArrayListWidget extends HudWidget {
	private static final float ROW = 14f;
	private final Map<Module, Float> ys = new HashMap<>();
	private final List<Module> rows = new ArrayList<>();

	public ArrayListWidget() {
		super(Modules.ARRAY, 0.865f, 0.115f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		int maxAll = 0;
		rows.clear();
		for (Module m : Modules.ALL) {
			if (!m.toggleable || m == Modules.ARRAY) continue;
			maxAll = Math.max(maxAll, Draw.width(m.name));
			if (m.vis > 0.03f) rows.add(m);
		}
		rows.sort((p, q) -> Integer.compare(Draw.width(q.name), Draw.width(p.name)));

		w = maxAll + 16;
		h = Math.max(ROW, rows.size() * ROW);
		boolean bar = Modules.AL_BAR.bool;

		for (int i = 0; i < rows.size(); i++) {
			Module m = rows.get(i);
			float ty = i * ROW;
			Float cur = ys.get(m);
			float yy = cur == null ? ty : Anim.approach(cur, ty, 14f);
			ys.put(m, yy);

			float vis = m.enabled ? m.vis : m.vis * m.vis;
			float rw = Draw.width(m.name) + 12;
			float rx = x + w - rw + (1f - vis) * (rw + 8);
			float al = a * vis;
			int col = Draw.lerp(Theme.accent(), Theme.accent2(), i / (float) Math.max(1, rows.size()));

			Draw.rounded(g, rx, y + yy, rw, ROW - 1, 2, Theme.bg(al));
			if (bar) g.fill(Math.round(rx + rw) - 2, Math.round(y + yy) + 1, Math.round(rx + rw), Math.round(y + yy + ROW - 1) - 1, Draw.a(col, al));
			Draw.text(g, m.name, rx + 5, y + yy + 3, Draw.a(Draw.lerp(Theme.TEXT, col, 0.35f), al));
		}
	}
}
