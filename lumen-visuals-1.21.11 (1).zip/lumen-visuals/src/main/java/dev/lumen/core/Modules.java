package dev.lumen.core;

import java.util.ArrayList;
import java.util.List;

/** Реестр всех модулей и их настроек. */
public final class Modules {
	public static final List<Module> ALL = new ArrayList<>();

	private static Module reg(Module m) {
		ALL.add(m);
		return m;
	}

	// ───────────── HUD ─────────────
	public static final Module WATERMARK = reg(new Module("Watermark", "Name, FPS, ping and clock", Category.HUD, true, true));
	public static final Setting WM_FPS = WATERMARK.add(Setting.bool("fps", "Show FPS", true));
	public static final Setting WM_PING = WATERMARK.add(Setting.bool("ping", "Show ping", true));
	public static final Setting WM_TIME = WATERMARK.add(Setting.bool("time", "Show clock", true));

	public static final Module EFFECTS = reg(new Module("Effects", "Potion list with countdown timers", Category.HUD, true, true));
	public static final Setting EF_VANILLA = EFFECTS.add(Setting.bool("hide_vanilla", "Hide vanilla icons", true));
	public static final Setting EF_ICONS = EFFECTS.add(Setting.bool("icons", "Icons", true));
	public static final Setting EF_BAR = EFFECTS.add(Setting.bool("bar", "Progress bar", true));
	public static final Setting EF_FORMAT = EFFECTS.add(Setting.mode("format", "Time format", 0, "m:ss", "Seconds"));
	public static final Setting EF_WARN = EFFECTS.add(Setting.num("warn", "Blink below (sec)", 10, 0, 30, 1));

	public static final Module ARMOR = reg(new Module("Armor", "Armor pieces with durability", Category.HUD, true, true));
	public static final Setting AR_LAYOUT = ARMOR.add(Setting.mode("layout", "Layout", 0, "Vertical", "Horizontal"));
	public static final Setting AR_PCT = ARMOR.add(Setting.bool("percent", "Show percent", true));

	public static final Module TARGET = reg(new Module("Target HUD", "Info about what you look at", Category.HUD, true, true));
	public static final Setting TG_STYLE = TARGET.add(Setting.mode("style", "Style", 0, "Modern", "Minimal"));
	public static final Setting TG_ARMOR = TARGET.add(Setting.bool("armor", "Show armor", true));
	public static final Setting TG_DIST = TARGET.add(Setting.bool("distance", "Show distance", true));
	public static final Setting TG_LINGER = TARGET.add(Setting.num("linger", "Keep visible (sec)", 2, 0.5, 6, 0.5));

	public static final Module KEYS = reg(new Module("Keystrokes", "WASD, mouse buttons and CPS", Category.HUD, true, true));
	public static final Setting KS_MOUSE = KEYS.add(Setting.bool("mouse", "Mouse buttons", true));
	public static final Setting KS_SPACE = KEYS.add(Setting.bool("space", "Space bar", true));
	public static final Setting KS_CPS = KEYS.add(Setting.bool("cps", "Show CPS", true));

	public static final Module INFO = reg(new Module("Info", "Coordinates, speed and direction", Category.HUD, true, true));
	public static final Setting IN_COORDS = INFO.add(Setting.bool("coords", "Coordinates", true));
	public static final Setting IN_SPEED = INFO.add(Setting.bool("speed", "Speed", true));
	public static final Setting IN_DIR = INFO.add(Setting.bool("direction", "Direction", true));

	public static final Module ITEMS = reg(new Module("Item counter", "Totems, apples, pearls, fireworks", Category.HUD, true, true));
	public static final Setting IT_TOTEM = ITEMS.add(Setting.bool("totem", "Totems", true));
	public static final Setting IT_GAPPLE = ITEMS.add(Setting.bool("gapple", "Golden apples", true));
	public static final Setting IT_PEARL = ITEMS.add(Setting.bool("pearl", "Ender pearls", true));
	public static final Setting IT_FIREWORK = ITEMS.add(Setting.bool("firework", "Fireworks", true));
	public static final Setting IT_CRYSTAL = ITEMS.add(Setting.bool("crystal", "End crystals", false));
	public static final Setting IT_XP = ITEMS.add(Setting.bool("xp", "XP bottles", false));
	public static final Setting IT_HIDE = ITEMS.add(Setting.bool("hide_empty", "Hide empty", true));

	public static final Module ARRAY = reg(new Module("ArrayList", "List of enabled modules", Category.HUD, true, true));
	public static final Setting AL_BAR = ARRAY.add(Setting.bool("bar", "Accent bar", true));

	public static final Module NOTIFS = reg(new Module("Notifications", "Toasts when modules are toggled", Category.HUD, true, true));
	public static final Setting NF_TIME = NOTIFS.add(Setting.num("time", "Duration (sec)", 2.5, 1, 6, 0.5));

	// ───────────── Visuals ─────────────
	public static final Module ESP = reg(new Module("Target ESP", "Effects around the entity you look at", Category.VISUALS, true, true));
	public static final Setting ESP_MODE = ESP.add(Setting.mode("mode", "Mode", 0,
		"Ghosts", "Souls", "Orbit", "Ring", "Spiral", "Marker", "Corners"));
	public static final Setting ESP_COUNT = ESP.add(Setting.num("count", "Count", 3, 1, 8, 1));
	public static final Setting ESP_SIZE = ESP.add(Setting.num("size", "Size", 1.0, 0.5, 2.0, 0.1));
	public static final Setting ESP_SPEED = ESP.add(Setting.num("speed", "Speed", 1.0, 0.4, 2.5, 0.1));
	public static final Setting ESP_HOLD = ESP.add(Setting.num("hold", "Keep visible (sec)", 2, 0.5, 8, 0.5));

	public static final Module CROSSHAIR = reg(new Module("Crosshair", "Custom crosshair with hit marker", Category.VISUALS, true, true));
	public static final Setting CH_STYLE = CROSSHAIR.add(Setting.mode("style", "Style", 0, "Cross", "Dot", "Circle", "T-Shape"));
	public static final Setting CH_COLOR = CROSSHAIR.add(Setting.mode("color", "Color", 0, "Accent", "White", "Rainbow"));
	public static final Setting CH_SIZE = CROSSHAIR.add(Setting.num("size", "Size", 4, 1, 12, 1));
	public static final Setting CH_GAP = CROSSHAIR.add(Setting.num("gap", "Gap", 2, 0, 10, 1));
	public static final Setting CH_THICK = CROSSHAIR.add(Setting.num("thickness", "Thickness", 1, 1, 4, 1));
	public static final Setting CH_DYNAMIC = CROSSHAIR.add(Setting.bool("dynamic", "Dynamic gap", true));
	public static final Setting CH_OUTLINE = CROSSHAIR.add(Setting.bool("outline", "Outline", true));
	public static final Setting CH_HIT = CROSSHAIR.add(Setting.bool("hitmarker", "Hit marker", true));

	public static final Module PARTICLES = reg(new Module("Particles", "Client-side hit and aura particles", Category.VISUALS, true, true));
	public static final Setting PA_HIT = PARTICLES.add(Setting.bool("hit", "On hit", true));
	public static final Setting PA_TYPE = PARTICLES.add(Setting.mode("type", "Hit type", 0, ParticleNames.NAMES));
	public static final Setting PA_AMOUNT = PARTICLES.add(Setting.num("amount", "Amount", 14, 3, 40, 1));
	public static final Setting PA_AURA = PARTICLES.add(Setting.bool("aura", "Self aura", false));
	public static final Setting PA_AURA_TYPE = PARTICLES.add(Setting.mode("aura_type", "Aura type", 2, ParticleNames.NAMES));

	public static final Module DAMAGE = reg(new Module("Damage numbers", "Floating damage on your target", Category.VISUALS, true, true));
	public static final Setting DM_SIZE = DAMAGE.add(Setting.num("size", "Size", 1.2, 0.8, 2.0, 0.1));

	public static final Module HITSOUND = reg(new Module("Hit sound", "Sound when you hit a target", Category.VISUALS, false, true));
	public static final Setting HS_SOUND = HITSOUND.add(Setting.mode("sound", "Sound", 0, "Orb", "Chime", "Arrow"));
	public static final Setting HS_VOL = HITSOUND.add(Setting.num("volume", "Volume", 0.5, 0.1, 1.0, 0.1));
	public static final Setting HS_PITCH = HITSOUND.add(Setting.num("pitch", "Pitch", 1.2, 0.5, 2.0, 0.1));

	public static final Module FULLBRIGHT = reg(new Module("Fullbright", "Max brightness (gamma)", Category.VISUALS, false, true));

	public static final Module ATMOSPHERE = reg(new Module("Atmosphere", "Dark purple tint and vignette", Category.VISUALS, true, true));
	public static final Setting AT_PRESET = ATMOSPHERE.add(Setting.mode("preset", "Preset", 0, "Depressive", "Midnight", "Crimson", "Ash"));
	public static final Setting AT_TINT = ATMOSPHERE.add(Setting.num("tint", "Tint", 0.14, 0.0, 0.5, 0.02));
	public static final Setting AT_VIGN = ATMOSPHERE.add(Setting.num("vignette", "Vignette", 0.6, 0.0, 1.0, 0.05));
	public static final Setting AT_PULSE = ATMOSPHERE.add(Setting.bool("pulse", "Breathing pulse", true));

	// ───────────── Animations ─────────────
	public static final Module SWING = reg(new Module("Swing", "Swing animation and hand pose", Category.ANIMATIONS, true, true));
	public static final Setting SW_MODE = SWING.add(Setting.mode("mode", "Animation", 1,
		"Vanilla", "Smooth", "Slash", "Slide", "Block", "Spin", "Poke", "Whip", "Tap", "Hammer"));
	public static final Setting SW_POSE = SWING.add(Setting.mode("pose", "Hand pose", 0,
		"Default", "Horizontal", "Horizontal Up", "Vertical", "Low", "Tilted", "Block Pose", "Flat", "Reverse"));
	public static final Setting SW_POSE_AMT = SWING.add(Setting.num("pose_amount", "Pose strength", 1.0, 0.2, 1.5, 0.1));
	public static final Setting SW_POWER = SWING.add(Setting.num("power", "Intensity", 1.0, 0.3, 2.0, 0.1));
	public static final Setting SW_SCALE = SWING.add(Setting.num("scale", "Item scale", 1.0, 0.4, 1.6, 0.05));

	// ───────────── Utility ─────────────
	public static final Module GPS = reg(new Module("GPS", "Waypoint arrow, .gps x z, event auto-detect", Category.UTILITY, true, true));
	public static final Setting GPS_AUTO = GPS.add(Setting.bool("auto", "Auto from chat events", true));
	public static final Setting GPS_MARKER = GPS.add(Setting.bool("marker", "World marker", true));
	public static final Setting GPS_ARRIVE = GPS.add(Setting.num("arrive", "Arrive radius", 6, 2, 30, 1));

	public static final Module ELYTRA = reg(new Module("Elytra helper", "Keys: swap elytra/chestplate, firework", Category.UTILITY, true, true));
	public static final Setting EL_NOTIFY = ELYTRA.add(Setting.bool("notify", "Chat feedback", true));

	// ───────────── Theme ─────────────
	public static final Module THEME = reg(new Module("Interface", "Theme, glass style, font", Category.THEME, true, false));
	public static final Setting TH_ACCENT = THEME.add(Setting.mode("accent", "Theme", 0, Theme.NAMES));
	public static final Setting TH_OPACITY = THEME.add(Setting.num("opacity", "Glass opacity", 0.62, 0.3, 1.0, 0.02));
	public static final Setting TH_RADIUS = THEME.add(Setting.num("radius", "Corner radius", 5, 0, 8, 1));
	public static final Setting TH_FONT = THEME.add(Setting.bool("font", "Custom font", true));

	private Modules() {}
}
