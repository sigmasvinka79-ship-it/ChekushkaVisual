package dev.lumen.anim;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.lumen.core.Modules;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * Анимации взмаха и позы руки в первом лице. Полностью клиентские: меняется только матрица
 * отрисовки предмета в руке, на геймплей и сервер это не влияет.
 */
public final class SwingAnimations {
	private SwingAnimations() {}

	private static void rx(PoseStack p, float d) { p.mulPose(Axis.XP.rotationDegrees(d)); }
	private static void ry(PoseStack p, float d) { p.mulPose(Axis.YP.rotationDegrees(d)); }
	private static void rz(PoseStack p, float d) { p.mulPose(Axis.ZP.rotationDegrees(d)); }

	/** @return true, если ванильное преобразование взмаха нужно отменить. */
	public static boolean apply(PoseStack p, HumanoidArm arm, float swing) {
		if (!Modules.SWING.enabled) return false;
		int mode = Modules.SW_MODE.mode;
		if (mode == 0) return false;
		if (swing <= 0f) return true;

		float k = Modules.SW_POWER.f();
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		float w = Mth.sin(swing * Mth.PI);
		float s = Mth.sin(Mth.sqrt(swing) * Mth.PI);
		float e = swing * swing * (3f - 2f * swing);

		switch (mode) {
			case 1 -> { // Smooth
				ry(p, side * (45f - 8f * s * k));
				rz(p, side * s * -14f * k);
				rx(p, s * -62f * k);
				ry(p, side * -45f);
			}
			case 2 -> { // Slash
				ry(p, side * 45f);
				rz(p, side * -70f * w * k);
				rx(p, -18f * w * k);
				ry(p, side * (-45f + 38f * w * k));
			}
			case 3 -> { // Slide
				p.translate(side * 0.06f * w * k, -0.12f * w * k, -0.65f * w * k);
				rx(p, -12f * w * k);
			}
			case 4 -> { // Block
				p.translate(side * -0.12f * w * k, 0.08f * w * k, 0f);
				ry(p, side * 28f * w * k);
				rz(p, side * -22f * w * k);
				rx(p, (-52f * w - 26f * s) * k);
			}
			case 5 -> { // Spin
				rx(p, -25f * w * k);
				rz(p, side * 360f * e);
			}
			case 6 -> { // Poke
				p.translate(0f, 0.02f * w * k, -0.85f * w * k);
				rx(p, -6f * w * k);
				ry(p, side * 8f * w * k);
			}
			case 7 -> { // Whip
				float u = Mth.sin(swing * swing * Mth.PI);
				ry(p, side * 45f);
				rx(p, -105f * u * k);
				rz(p, side * -24f * u * k);
				ry(p, side * -45f);
			}
			case 8 -> { // Tap
				p.translate(0f, -0.14f * w * k, -0.22f * w * k);
				rx(p, -24f * w * k);
			}
			case 9 -> { // Hammer
				float a;
				if (swing < 0.4f) {
					a = -80f * Mth.sin(swing / 0.4f * Mth.HALF_PI);
				} else {
					float r = (swing - 0.4f) / 0.6f;
					a = -80f * (1f - Mth.sin(r * Mth.HALF_PI)) + 22f * Mth.sin(r * Mth.PI);
				}
				p.translate(0f, 0.12f * w * k, 0f);
				rx(p, a * k);
			}
			default -> {
				return false;
			}
		}
		return true;
	}

	/**
	 * Поза руки одной настройкой (без ручных координат): «меч горизонтально» и т.п.
	 * Вызывается после стандартного подъёма предмета, до взмаха.
	 */
	public static void applyOffset(PoseStack p, HumanoidArm arm) {
		if (!Modules.SWING.enabled) return;
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		float k = Modules.SW_POSE_AMT.f();

		switch (Modules.SW_POSE.mode) {
			case 1 -> { // Horizontal: клинок поперёк экрана
				p.translate(side * -0.10f * k, -0.05f * k, 0f);
				rz(p, side * 78f * k);
				ry(p, side * -14f * k);
			}
			case 2 -> { // Horizontal Up: поперёк и чуть приподнят
				p.translate(side * -0.08f * k, 0.03f * k, 0f);
				rz(p, side * 70f * k);
				rx(p, -22f * k);
			}
			case 3 -> { // Vertical: стоит почти вертикально
				rx(p, -18f * k);
				rz(p, side * -6f * k);
			}
			case 4 -> { // Low: опущен вниз
				p.translate(side * 0.04f * k, -0.22f * k, 0.06f * k);
				rx(p, 18f * k);
			}
			case 5 -> { // Tilted: наклон наружу
				rz(p, side * -38f * k);
				rx(p, -14f * k);
			}
			case 6 -> { // Block Pose: как блок мечом в 1.8
				p.translate(side * -0.18f * k, 0.04f * k, 0.08f * k);
				rx(p, -62f * k);
				ry(p, side * 32f * k);
				rz(p, side * 24f * k);
			}
			case 7 -> { // Flat: клинок вперёд, как копьё
				p.translate(0f, 0.05f * k, 0.06f * k);
				rx(p, -88f * k);
			}
			case 8 -> { // Reverse: обратный хват
				rz(p, side * 180f * k);
				p.translate(0f, -0.05f * k, 0f);
			}
			default -> {
			}
		}

		float sc = Modules.SW_SCALE.f();
		if (sc != 1f) p.scale(sc, sc, sc);
	}
}
