package dev.lumen;

import com.mojang.blaze3d.platform.InputConstants;
import dev.lumen.core.Config;
import dev.lumen.feature.Commands;
import dev.lumen.feature.ElytraHelper;
import dev.lumen.feature.EventDetector;
import dev.lumen.feature.Gps;
import dev.lumen.gui.MenuScreen;
import dev.lumen.hud.HudRenderer;
import dev.lumen.visual.Fullbright;
import dev.lumen.visual.HitSound;
import dev.lumen.visual.ParticleFx;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class LumenClient implements ClientModInitializer {
	public static final String ID = "lumen";
	public static KeyMapping OPEN_MENU;

	@Override
	public void onInitializeClient() {
		Config.load();

		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));
		OPEN_MENU = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key.lumen.open_menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
		ElytraHelper.SWAP = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key.lumen.elytra_swap", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));
		ElytraHelper.FIREWORK = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key.lumen.elytra_firework", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));

		HudRenderer.init();

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (OPEN_MENU.consumeClick()) {
				if (mc.level != null && mc.screen == null) mc.setScreen(new MenuScreen());
			}
			ElytraHelper.tick(mc);
			Fullbright.tick(mc);
			ParticleFx.tick(mc);
			HitSound.tick(mc);
			Gps.tick(mc);
		});

		// Команды клиента (.gps, .cfg) не уходят на сервер
		ClientSendMessageEvents.ALLOW_CHAT.register(message -> !Commands.handle(message));

		// Авто-метка на ивенты из чата
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
			if (!overlay) EventDetector.onMessage(message.getString());
		});
		ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, timestamp) ->
			EventDetector.onMessage(message.getString()));

		ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
			Fullbright.restore(mc);
			Config.save();
		});
	}
}
