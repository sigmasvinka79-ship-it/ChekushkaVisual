package dev.lumen.visual;

import dev.lumen.core.Modules;
import dev.lumen.util.Draw;
import net.minecraft.util.Util;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Депрессивная атмосфера: тёмно-фиолетовая вуаль и виньетка по краям экрана. */
public final class Atmosphere {
	private static final int[][] PRESETS = {
		{0x2B1050, 0x08001A},
		{0x0B1F4A, 0x00040F},
		{0x4A0B18, 0x120004},
		{0x26262E, 0x050507}
	};
	private static float shown;

	private Atmosphere() {}

	public static void render(GuiGraphics g, DeltaTracker dt) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) return;
		shown += ((Modules.ATMOSPHERE.enabled ? 1f : 0f) - shown) * 0.08f;
		if (shown < 0.01f) return;

		float pulse = 1f;
		if (Modules.AT_PULSE.bool) pulse = 0.88f + 0.12f * Mth.sin((Util.getMillis() % 100000L) / 1000f * 0.9f);

		int[] pr = PRESETS[Modules.AT_PRESET.mode];
		int w = g.guiWidth(), h = g.guiHeight();
		float tint = Modules.AT_TINT.f() * shown * pulse;
		if (tint > 0.004f) g.fill(0, 0, w, h, Draw.a(0xFF000000 | pr[0], tint));
		float vig = Modules.AT_VIGN.f() * shown * pulse;
		if (vig > 0.01f) Draw.vignette(g, w, h, Draw.a(0xFF000000 | pr[1], vig));
	}
}
