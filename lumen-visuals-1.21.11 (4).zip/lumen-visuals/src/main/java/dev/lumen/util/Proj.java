package dev.lumen.util;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

/**
 * Проекция точек мира в экранные координаты GUI (для Target ESP, GPS-метки, цифр урона).
 * Всё считается на клиенте только для того, что ты и так видишь в кадре.
 */
public final class Proj {
	private static double cx, cy, cz, fx, fy, fz, rx, ry, rz, ux, uy, uz;
	private static float tanHalf = 1f, aspect = 1f, sw = 1f, sh = 1f;
	public static boolean ready;

	private Proj() {}

	public static boolean begin(Minecraft mc, float pt, int w, int h) {
		ready = false;
		var p = mc.player;
		if (p == null) return false;
		var type = mc.options.getCameraType();
		if (type.isMirrored()) return false;

		double yaw = Math.toRadians(p.getViewYRot(pt)), pitch = Math.toRadians(p.getViewXRot(pt));
		double cp = Math.cos(pitch), sp = Math.sin(pitch), cyw = Math.cos(yaw), syw = Math.sin(yaw);
		fx = -syw * cp;
		fy = -sp;
		fz = cyw * cp;
		rx = -cyw;
		ry = 0;
		rz = -syw;
		ux = ry * fz - rz * fy;
		uy = rz * fx - rx * fz;
		uz = rx * fy - ry * fx;

		Vec3 eye = p.getEyePosition(pt);
		double back = type.isFirstPerson() ? 0.0 : 4.0;
		cx = eye.x - fx * back;
		cy = eye.y - fy * back;
		cz = eye.z - fz * back;

		float fov = mc.options.fov().get();
		try {
			double es = mc.options.fovEffectScale().get();
			double spd = p.getAttributeValue(Attributes.MOVEMENT_SPEED);
			float walk = p.getAbilities().getWalkingSpeed();
			if (walk > 0f) {
				float f = (float) ((spd / walk + 1.0) / 2.0);
				fov *= Mth.lerp((float) es, 1f, f);
			}
		} catch (Throwable ignored) {
		}
		tanHalf = (float) Math.tan(Math.toRadians(fov) / 2.0);
		aspect = (float) w / (float) h;
		sw = w;
		sh = h;
		ready = true;
		return true;
	}

	/** o = {x, y, depth}. false, если точка позади камеры. */
	public static boolean to(double x, double y, double z, float[] o) {
		if (!ready) return false;
		double dx = x - cx, dy = y - cy, dz = z - cz;
		double d = dx * fx + dy * fy + dz * fz;
		if (d < 0.05) return false;
		double sx = dx * rx + dy * ry + dz * rz;
		double sy = dx * ux + dy * uy + dz * uz;
		o[0] = (float) (sw / 2f + (sx / d) / (tanHalf * aspect) * (sw / 2f));
		o[1] = (float) (sh / 2f - (sy / d) / tanHalf * (sh / 2f));
		o[2] = (float) d;
		return true;
	}

	/** Пикселей GUI на один блок на данной глубине. */
	public static float scale(float depth) {
		return (sh / 2f) / (tanHalf * depth);
	}

	/** true, если точка дальше центра сущности (для приглушения «задних» частиц). */
	public static boolean behind(double ex, double ez, double x, double z) {
		return (x - ex) * fx + (z - ez) * fz > 0;
	}

	public static double camX() { return cx; }
	public static double camZ() { return cz; }
}
