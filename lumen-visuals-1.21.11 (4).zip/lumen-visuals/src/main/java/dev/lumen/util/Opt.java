package dev.lumen.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import net.minecraft.client.OptionInstance;

/**
 * Принудительная запись значения в настройку (в обход ограничений слайдера): нужно для яркости выше
 * максимума, FOV зума и чувствительности. Поле значения находим по типу, а не по имени.
 */
public final class Opt {
	private static Field field;
	private static boolean searched;

	private Opt() {}

	private static Field find() {
		if (!searched) {
			searched = true;
			for (Field f : OptionInstance.class.getDeclaredFields()) {
				int m = f.getModifiers();
				if (!Modifier.isStatic(m) && !Modifier.isFinal(m) && f.getType() == Object.class) {
					f.setAccessible(true);
					field = f;
					break;
				}
			}
		}
		return field;
	}

	public static void force(OptionInstance<?> o, Object v) {
		try {
			Field f = find();
			if (f != null) f.set(o, v);
		} catch (Throwable ignored) {
		}
	}
}
