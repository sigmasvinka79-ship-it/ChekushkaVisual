package dev.lumen.util;

import java.util.HashMap;
import java.util.Map;

import dev.lumen.core.Modules;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

/** Свой шрифт (Poppins + DejaVu для кириллицы) вместо пиксельного майнкрафтовского. */
public final class Fonts {
	public static final Identifier ID = Identifier.fromNamespaceAndPath("lumen", "ui");
	private static final Style STYLE = Style.EMPTY.withFont(new FontDescription.Resource(ID));
	private static final Map<String, Component> CACHE = new HashMap<>(512);

	private Fonts() {}

	public static Component of(String s) {
		Component c = CACHE.get(s);
		if (c == null) {
			if (CACHE.size() > 1500) CACHE.clear();
			c = Modules.TH_FONT.bool ? Component.literal(s).withStyle(STYLE) : Component.literal(s);
			CACHE.put(s, c);
		}
		return c;
	}

	public static void reset() {
		CACHE.clear();
	}
}
