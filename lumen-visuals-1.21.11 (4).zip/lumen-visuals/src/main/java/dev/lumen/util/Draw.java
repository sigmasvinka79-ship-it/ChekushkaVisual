package dev.lumen.util;

import dev.lumen.core.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2fStack;

/** Рисование: liquid-glass панели, скругления, свечение, текст своим шрифтом. */
public final class Draw {
	private static final int[][] INSET = new int[17][];
	private static final Identifier GLOW = Identifier.fromNamespaceAndPath("lumen", "textures/gui/glow.png");
	private static final Identifier VIGNETTE = Identifier.fromNamespaceAndPath("lumen", "textures/gui/vignette.png");

	private Draw() {}

	private static int[] inset(int r) {
		int[] a = INSET[r];
		if (a == null) {
			a = new int[r];
			for (int i = 0; i < r; i++) {
				double dy = r - i - 0.5;
				double dx = Math.sqrt(r * (double) r - dy * dy);
				a[i] = (int) Math.round(r - dx);
			}
			INSET[r] = a;
		}
		return a;
	}

	public static int a(int color, float alpha) {
		int al = Math.round(((color >>> 24) & 255) * Mth.clamp(alpha, 0f, 1f));
		return (al << 24) | (color & 0xFFFFFF);
	}

	public static int lerp(int c1, int c2, float t) {
		t = Mth.clamp(t, 0f, 1f);
		int out = 0;
		for (int s = 0; s <= 24; s += 8) {
			int x = (c1 >>> s) & 255, y = (c2 >>> s) & 255;
			out |= (Math.round(x + (y - x) * t) & 255) << s;
		}
		return out;
	}

	public static int hp(float f) {
		f = Mth.clamp(f, 0f, 1f);
		return f > 0.5f ? lerp(0xFFFACC15, 0xFF4ADE80, (f - 0.5f) * 2f) : lerp(0xFFEF4444, 0xFFFACC15, f * 2f);
	}

	public static void rounded(GuiGraphics g, float fx, float fy, float fw, float fh, int r, int c) {
		if ((c >>> 24) < 2) return;
		int x = Math.round(fx), y = Math.round(fy), w = Math.round(fw), h = Math.round(fh);
		if (w <= 0 || h <= 0) return;
		r = Math.min(16, Math.min(r, Math.min(w, h) / 2));
		if (r <= 0) {
			g.fill(x, y, x + w, y + h, c);
			return;
		}
		int[] in = inset(r);
		g.fill(x, y + r, x + w, y + h - r, c);
		for (int i = 0; i < r; i++) {
			g.fill(x + in[i], y + i, x + w - in[i], y + i + 1, c);
			g.fill(x + in[i], y + h - 1 - i, x + w - in[i], y + h - i, c);
		}
	}

	/** Контур в 1 px по скруглённому прямоугольнику. */
	public static void border(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
		if ((c >>> 24) < 2 || w < 3 || h < 3) return;
		r = Math.min(16, Math.min(r, Math.min(w, h) / 2));
		if (r <= 0) {
			g.fill(x, y, x + w, y + 1, c);
			g.fill(x, y + h - 1, x + w, y + h, c);
			g.fill(x, y + 1, x + 1, y + h - 1, c);
			g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
			return;
		}
		int[] in = inset(r);
		g.fill(x + r, y, x + w - r, y + 1, c);
		g.fill(x + r, y + h - 1, x + w - r, y + h, c);
		g.fill(x, y + r, x + 1, y + h - r, c);
		g.fill(x + w - 1, y + r, x + w, y + h - r, c);
		for (int i = 0; i < r; i++) {
			int x0 = x + in[i];
			int x1 = i == 0 ? x + r : x + Math.max(in[i] + 1, in[i - 1]);
			g.fill(x0, y + i, x1, y + i + 1, c);
			g.fill(x + w - (x1 - x), y + i, x + w - (x0 - x), y + i + 1, c);
			g.fill(x0, y + h - 1 - i, x1, y + h - i, c);
			g.fill(x + w - (x1 - x), y + h - 1 - i, x + w - (x0 - x), y + h - i, c);
		}
	}

	public static void shadow(GuiGraphics g, float x, float y, float w, float h, int r, float alpha) {
		for (int k = 4; k >= 1; k--) {
			rounded(g, x - k, y - k + 2, w + k * 2, h + k * 2, r + k, a(0xFF000000, 0.05f * alpha));
		}
	}

	/** «Жидкое стекло»: тёмная база, блик сверху, светлая кромка. */
	public static void glass(GuiGraphics g, float x, float y, float w, float h, int r, float alpha) {
		rounded(g, x, y, w, h, r, Theme.bg(alpha));
		int ix = Math.round(x), iy = Math.round(y), iw = Math.round(w), ih = Math.round(h);
		if (iw > r * 2 + 4 && ih > 8) {
			int gh = Math.max(3, Math.round(ih * 0.5f));
			g.fillGradient(ix + r, iy + 1, ix + iw - r, iy + gh, a(0xFFFFFFFF, 0.085f * alpha), a(0xFFFFFFFF, 0f));
		}
		border(g, ix, iy, iw, ih, r, a(0xFFFFFFFF, 0.13f * alpha));
		if (iw > r * 2 + 2) g.fill(ix + r, iy, ix + iw - r, iy + 1, a(0xFFFFFFFF, 0.30f * alpha));
	}

	/** Мягкий движущийся блик по стеклянной панели. */
	public static void sheen(GuiGraphics g, float x, float y, float w, float h, float alpha) {
		float time = (System.nanoTime() / 1_000_000_000f);
		float band = w * 0.30f;
		float pos = ((time * 0.10f) % 1.7f - 0.35f) * w;
		int strips = 8;
		float sw = band / strips;
		for (int i = 0; i < strips; i++) {
			float sx = x + pos + i * sw;
			float al = (float) Math.sin(Math.PI * (i + 0.5) / strips) * 0.045f * alpha;
			int x1 = Math.round(Math.max(sx, x + 5)), x2 = Math.round(Math.min(sx + sw + 1, x + w - 5));
			if (x2 > x1) g.fill(x1, Math.round(y) + 4, x2, Math.round(y + h) - 4, a(0xFFFFFFFF, al));
		}
	}

	public static void panel(GuiGraphics g, float x, float y, float w, float h, float alpha) {
		glass(g, x, y, w, h, Theme.radius(), alpha);
	}

	/** Мягкое свечение (текстура glow.png, тонируется цветом). */
	public static void glow(GuiGraphics g, float cx, float cy, float size, int color) {
		if ((color >>> 24) < 3) return;
		int s = Math.max(2, Math.round(size));
		g.blit(RenderPipelines.GUI_TEXTURED, GLOW, Math.round(cx - s / 2f), Math.round(cy - s / 2f),
			0f, 0f, s, s, 64, 64, 64, 64, color);
	}

	public static void vignette(GuiGraphics g, int w, int h, int color) {
		if ((color >>> 24) < 2) return;
		g.blit(RenderPipelines.GUI_TEXTURED, VIGNETTE, 0, 0, 0f, 0f, w, h, 256, 256, 256, 256, color);
	}

	/** Стрелка, смотрящая вверх, повёрнутая на angle радиан по часовой. */
	public static void arrow(GuiGraphics g, float cx, float cy, float size, float angle, int color) {
		Matrix3x2fStack m = g.pose();
		m.pushMatrix();
		m.translate(cx, cy);
		m.rotate(angle);
		int s = Math.round(size);
		int top = -s / 2;
		for (int i = 0; i < s; i++) {
			int hw = Math.max(1, Math.round(i * 0.55f));
			g.fill(-hw, top + i, hw, top + i + 1, color);
		}
		g.fill(-1, top + s - 3, 1, top + s + 2, a(color, 0.7f));
		m.popMatrix();
	}

	// ───────────────────────── текст ─────────────────────────

	public static int width(String s) {
		return Minecraft.getInstance().font.width(Fonts.of(s));
	}

	public static String clip(String s, int maxW) {
		if (width(s) <= maxW) return s;
		int n = s.length();
		while (n > 1 && width(s.substring(0, n) + "..") > maxW) n--;
		return s.substring(0, n) + "..";
	}

	public static void text(GuiGraphics g, String s, float x, float y, int color) {
		text(g, s, x, y, 1f, color, true);
	}

	public static void text(GuiGraphics g, String s, float x, float y, float scale, int color, boolean shadow) {
		if ((color >>> 24) < 8 || s.isEmpty()) return;
		var font = Minecraft.getInstance().font;
		var comp = Fonts.of(s);
		if (scale == 1f) {
			g.drawString(font, comp, Math.round(x), Math.round(y), color, shadow);
			return;
		}
		Matrix3x2fStack m = g.pose();
		m.pushMatrix();
		m.translate(x, y);
		m.scale(scale, scale);
		g.drawString(font, comp, 0, 0, color, shadow);
		m.popMatrix();
	}

	public static void textRight(GuiGraphics g, String s, float right, float y, float scale, int color) {
		text(g, s, right - width(s) * scale, y, scale, color, true);
	}

	public static void bar(GuiGraphics g, float x, float y, float w, float h, float frac, int color, float alpha) {
		rounded(g, x, y, w, h, 1, a(0xFFFFFFFF, 0.12f * alpha));
		float fw = w * Mth.clamp(frac, 0f, 1f);
		if (fw >= 1f) rounded(g, x, y, fw, h, 1, a(color, alpha));
	}
}
