package dev.lumen.util;

import java.util.HashMap;
import java.util.Map;

import dev.lumen.core.Modules;
import net.minecraft.client.Minecraft;

/** Русская локализация меню. Auto берёт язык игры; можно выбрать вручную в Theme → Interface. */
public final class Lang {
	private static final String DATA = """
HUD|HUD
Visuals|Визуалы
Animations|Анимации
Utility|Утилиты
Theme|Тема
Configs|Конфиги
Search|Поиск
Search...|Поиск...
HUD editor|Редактор HUD
Reset all|Сбросить всё
Snap: on|Привязка: вкл
Snap: off|Привязка: выкл
Done|Готово
Drag - move   Wheel - scale   RMB - reset element   Esc - back|ЛКМ - двигать   Колесо - размер   ПКМ - сброс элемента   Esc - назад
Enabled|Включено
Disabled|Выключено
+ Save current as new|+ Сохранить текущий как новый
creates cfgN in config/lumen|создаёт cfgN в config/lumen
preset - click to load|пресет - нажми, чтобы загрузить
saved - LMB load, RMB delete|сохранён - ЛКМ загрузить, ПКМ удалить
Watermark|Ватермарка
Name, FPS, ping and clock|Ник, FPS, пинг и время
Effects|Эффекты
Potion list with countdown timers|Список зелий с таймерами
Armor|Броня
Armor pieces with durability|Броня с прочностью
Target HUD|Таргет HUD
Info about what you look at|Информация о цели под прицелом
Keystrokes|Клавиши
WASD, mouse buttons and CPS|WASD, кнопки мыши и CPS
Info|Инфо
Coordinates, speed and direction|Координаты, скорость, направление
Item counter|Счётчик предметов
Totems, apples, pearls, fireworks|Тотемы, яблоки, жемчуг, фейерверки
ArrayList|Список функций
List of enabled modules|Список включённых функций
Combo|Комбо
Hit combo counter|Счётчик комбо ударов
Elytra HUD|Элитры HUD
Durability, speed, altitude, rockets|Прочность, скорость, высота, ракеты
Session|Сессия
Playtime, kills, deaths, combat timer|Время игры, убийства, смерти, таймер боя
Notifications|Уведомления
Toasts when modules are toggled|Всплывашки при включении функций
Target ESP|Эффекты цели
Effects around the entity you look at|Эффекты вокруг цели под прицелом
Crosshair|Прицел
Custom crosshair with hit marker|Свой прицел с хитмаркером
Particles|Частицы
Client-side hit and aura particles|Клиентские частицы удара и ауры
Damage numbers|Цифры урона
Floating damage on your target|Всплывающий урон над целью
Hit sound|Звук попадания
Sound when you hit a target|Звук при попадании по цели
Jump circles|Круги прыжка
Rings that spread when you jump|Кольца при прыжке
Zoom|Зум
Hold the zoom key, scroll to adjust|Держи клавишу зума, колесо меняет кратность
Fullbright|Фулбрайт
Max brightness (gamma)|Максимальная яркость
Atmosphere|Атмосфера
Dark purple tint and vignette|Тёмно-фиолетовая вуаль и виньетка
Cosmetics|Косметика
Cape, halo, horns and pet (only you see them)|Плащ, нимб, рога и питомец (видишь только ты)
Swing|Анимации руки
Swing animation and hand pose|Анимация удара и поза руки
GPS|GPS
Waypoint arrow, .gps x z, event auto-detect|Стрелка к метке, .gps x z, автометка ивентов
Elytra helper|Помощник элитр
Keys: swap elytra/chestplate, firework|Клавиши: смена элитры и нагрудника, фейерверк
Optimization|Оптимизация
Raises FPS without visible changes|Поднимает FPS почти без изменений картинки
Interface|Интерфейс
Theme, glass style, font|Тема, стекло, шрифт
Show FPS|Показывать FPS
Show ping|Показывать пинг
Show clock|Показывать время
Hide vanilla icons|Скрыть ванильные иконки
Icons|Иконки
Progress bar|Полоска прогресса
Time format|Формат времени
Blink below (sec)|Мигать меньше (сек)
Layout|Расположение
Show percent|Показывать проценты
Low durability warning|Предупреждать о поломке
Style|Стиль
Show armor|Показывать броню
Show distance|Показывать дистанцию
Keep visible (sec)|Держать на экране (сек)
Mouse buttons|Кнопки мыши
Space bar|Пробел
Show CPS|Показывать CPS
Coordinates|Координаты
Speed|Скорость
Direction|Направление
Totems|Тотемы
Golden apples|Золотые яблоки
Ender pearls|Жемчуг Края
Fireworks|Фейерверки
End crystals|Кристаллы Края
XP bottles|Пузырьки опыта
Hide empty|Скрывать пустые
Accent bar|Акцентная полоса
Include HUD modules|Включать HUD-функции
Duration (sec)|Длительность (сек)
Combat timer|Таймер боя
Kills and deaths|Убийства и смерти
Mode|Режим
Count|Количество
Size|Размер
Color|Цвет
Thickness|Толщина
Gap|Зазор
Dynamic gap|Динамический зазор
Outline|Обводка
Hit marker|Хитмаркер
Attack cooldown bar|Полоска перезарядки
Red on target|Красный на цели
On hit|При ударе
Hit type|Тип при ударе
Amount|Количество
Self aura|Аура вокруг себя
Aura type|Тип ауры
Kill burst|Взрыв при убийстве
Elytra trail|След за элитрой
Trail type|Тип следа
Sound|Звук
Volume|Громкость
Pitch|Тон
Zoom factor|Кратность зума
Smooth speed|Плавность
Scroll adjusts zoom|Колесо меняет зум
Lower sensitivity|Снижать чувствительность
Preset|Пресет
Tint|Вуаль
Vignette|Виньетка
Breathing pulse|Пульсация
Low HP warning|Предупреждение о низком HP
Animation|Анимация
Hand pose|Поза руки
Pose strength|Сила позы
Intensity|Интенсивность
Item scale|Размер предмета
Auto from chat events|Автометка из чата
World marker|Метка в мире
Arrive radius|Радиус прибытия
Mark death point|Метка места смерти
Chat feedback|Сообщения в чат
Glass opacity|Прозрачность стекла
Corner radius|Скругление
Custom font|Свой шрифт
Custom main menu|Своё главное меню
Language|Язык
Cape|Плащ
Halo|Нимб
Horns|Рога
Pet|Питомец
Show in first person|Показывать от первого лица
Cosmetic scale|Размер косметики
Entity shadows off|Выкл. тени существ
Clouds off|Выкл. облака
Biome blend 1|Смешивание биомов 1
Less particles|Меньше частиц
Uncapped FPS|Без лимита FPS
Adaptive quality|Адаптивное качество
Vertical|Вертикально
Horizontal|Горизонтально
Modern|Современный
Minimal|Минимальный
Seconds|Секунды
Ghosts|Призраки
Souls|Души
Orbit|Орбита
Ring|Кольцо
Spiral|Спираль
Marker|Маркер
Corners|Уголки
Saturn|Сатурн
Health|Здоровье
Rainbow|Радуга
Cross|Крест
Dot|Точка
Circle|Круг
T-Shape|Т-образный
Accent|Акцент
White|Белый
End Rod|Стержень Края
Soul Fire|Огонь душ
Soul|Душа
Flame|Пламя
Crit|Крит
Hearts|Сердца
Magic Hit|Магия
Witch|Ведьма
Sparks|Искры
Snow|Снег
Orb|Сфера
Chime|Колокольчик
Arrow|Стрела
Depressive|Депрессия
Midnight|Полночь
Crimson|Багровый
Ash|Пепел
Vanilla|Ваниль
Smooth|Плавная
Slash|Взмах
Slide|Скольжение
Block|Блок
Spin|Вращение
Poke|Тычок
Whip|Хлыст
Tap|Касание
Hammer|Молот
Wave|Волна
Dash|Рывок
Stab|Укол
Drop|Падение
Default|Обычная
Horizontal Up|Горизонт. вверх
Low|Низкая
Tilted|Наклон
Block Pose|Блок-поза
Forward|Вперёд
Reverse|Обратная
Black|Чёрный
Violet|Фиолетовый
Ocean|Океан
Sunset|Закат
Lime|Лайм
Ember|Угли
Rose|Розовый
Galaxy|Галактика
Devil|Дьявол
Ghost|Призрак
Slime|Слизень
Bat|Летучая мышь
Fire Sprite|Огонёк
Wisp|Блуждающий огонь
Auto|Авто
Off|Выкл
Accounts|Аккаунты
Add|Добавить
Save|Сохранить
Back|Назад
Edit|Изм.
Del|Удал.
Active|Активен
Original account|Оригинальный аккаунт
Click to use|Нажми, чтобы выбрать
Nickname|Ник
Nickname: 3-16 chars, A-Z 0-9 _|Ник: 3-16 символов, A-Z 0-9 _
Works on offline-mode servers only|Работает только на серверах с offline-режимом
""";

	private static final Map<String, String> RU = new HashMap<>();
	private static boolean cachedRu;
	private static long cachedAt;

	static {
		for (String line : DATA.split("\n")) {
			int i = line.indexOf('|');
			if (i > 0) RU.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
		}
	}

	private Lang() {}

	public static boolean ru() {
		long now = System.currentTimeMillis();
		if (now - cachedAt > 500) {
			cachedAt = now;
			int m = Modules.TH_LANG.mode;
			if (m == 1) {
				cachedRu = true;
			} else if (m == 2) {
				cachedRu = false;
			} else {
				String l = "";
				try {
					l = Minecraft.getInstance().getLanguageManager().getSelected();
				} catch (Throwable ignored) {
				}
				cachedRu = l != null && l.startsWith("ru");
			}
		}
		return cachedRu;
	}

	public static String t(String en) {
		if (!ru()) return en;
		String r = RU.get(en);
		return r != null ? r : en;
	}
}
