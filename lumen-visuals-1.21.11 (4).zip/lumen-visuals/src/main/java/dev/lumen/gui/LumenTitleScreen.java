package dev.lumen.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import dev.lumen.core.Theme;
import dev.lumen.feature.Accounts;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import dev.lumen.util.Lang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.util.Mth;

/**
 * Своё главное меню: только нужные кнопки (Одиночная, Сеть, Аккаунты, Настройки, Выход).
 * Наследуется от ванильного, чтобы кнопки работали как обычно, а рисуем мы всё сами.
 */
public final class LumenTitleScreen extends TitleScreen {
	private static final long START = System.nanoTime();
	private static final int BW = 210, BH = 20, GAP = 9;

	private final Anim.Timer timer = new Anim.Timer();
	/** null — это кнопка «Аккаунты». */
	private final List<AbstractWidget> slots = new ArrayList<>();
	private final float[] hov = new float[8];
	private float t;
	private int accX, accY;

	public LumenTitleScreen() {
		super(false);
	}

	@Override
	protected void init() {
		super.init();
		slots.clear();
		List<AbstractWidget> wide = new ArrayList<>();
		for (GuiEventListener c : this.children()) {
			if (c instanceof AbstractWidget aw && aw.getWidth() >= 90) wide.add(aw);
		}
		wide.sort(Comparator.<AbstractWidget>comparingInt(AbstractWidget::getY).thenComparingInt(AbstractWidget::getX));

		List<AbstractWidget> shown = new ArrayList<>(wide);
		if (wide.size() == 5) {
			// порядок ванили: Одиночная, Сеть, Realms, Настройки, Выход — Realms прячем
			AbstractWidget realms = wide.get(2);
			realms.setY(-400);
			shown.remove(realms);
		}
		int accIndex = Math.min(2, shown.size());
		shown.add(accIndex, null);

		int n = Math.min(shown.size(), hov.length);
		int total = n * BH + (n - 1) * GAP;
		int y = height / 2 - total / 2 + 34;
		for (int i = 0; i < n; i++) {
			AbstractWidget wdg = shown.get(i);
			if (wdg != null) {
				wdg.setX(width / 2 - BW / 2);
				wdg.setY(y);
				wdg.setWidth(BW);
			} else {
				accX = width / 2 - BW / 2;
				accY = y;
			}
			slots.add(wdg);
			y += BH + GAP;
		}
	}

	private int sx(AbstractWidget w) { return w == null ? accX : w.getX(); }
	private int sy(AbstractWidget w) { return w == null ? accY : w.getY(); }

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		if (e.button() == 0 && e.x() >= accX && e.x() <= accX + BW && e.y() >= accY && e.y() <= accY + BH) {
			Minecraft.getInstance().setScreen(new AccountsScreen(this));
			return true;
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		float d = timer.tick();
		Anim.dt = d;
		t = Math.min(1f, t + d / 0.9f);
		float tt = (System.nanoTime() - START) / 1_000_000_000f;

		g.fillGradient(0, 0, width, height, 0xFF06030E, 0xFF150A28);

		for (int i = 0; i < 7; i++) {
			float cx = width * (0.5f + 0.44f * Mth.sin(tt * 0.13f + i * 1.7f));
			float cy = height * (0.5f + 0.42f * Mth.sin(tt * 0.11f + i * 2.3f));
			float sz = 150f + 70f * Mth.sin(tt * 0.2f + i);
			int col = i % 2 == 0 ? Theme.accent() : Theme.accent2();
			Draw.glow(g, cx, cy, sz * 2f, Draw.a(col, 0.10f));
		}
		for (int i = 0; i < 60; i++) {
			float rx = frac(Mth.sin(i * 12.9898f) * 43758.547f);
			float ry = frac(Mth.sin(i * 78.233f) * 12345.678f);
			float sp = 4f + 10f * frac(Mth.sin(i * 3.17f) * 999.1f);
			float x = rx * width + 6f * Mth.sin(tt * 0.5f + i);
			float y = ((ry * height - tt * sp) % height + height) % height;
			float al = 0.25f + 0.45f * (0.5f + 0.5f * Mth.sin(tt * 1.6f + i * 1.3f));
			int s = (i % 5 == 0) ? 2 : 1;
			g.fill(Math.round(x), Math.round(y), Math.round(x) + s, Math.round(y) + s, Draw.a(0xFFFFFFFF, al * t));
		}
		Draw.vignette(g, width, height, Draw.a(0xFF000000, 0.75f));

		float ls = 3.4f;
		String logo = "LUMEN";
		float lw = 0;
		for (int i = 0; i < logo.length(); i++) lw += Draw.width(String.valueOf(logo.charAt(i))) * ls + 3f;
		float lx = (width - lw) / 2f;
		float ly = height / 2f - 84f + (1f - Anim.easeOut(t)) * -14f;
		Draw.glow(g, width / 2f, ly + 14, 260, Draw.a(Theme.accent(), 0.22f * t));
		for (int i = 0; i < logo.length(); i++) {
			String ch = String.valueOf(logo.charAt(i));
			float sh = 0.5f + 0.5f * Mth.sin(tt * 1.6f + i * 0.9f);
			Draw.text(g, ch, lx, ly, ls, Draw.a(Draw.lerp(Theme.accent(), Theme.accent2(), sh), t), true);
			lx += Draw.width(ch) * ls + 3f;
		}
		String sub = "V I S U A L S";
		Draw.text(g, sub, (width - Draw.width(sub) * 0.85f) / 2f, ly + 38, 0.85f, Draw.a(Theme.MUTED, t), false);

		for (int i = 0; i < slots.size(); i++) {
			AbstractWidget b = slots.get(i);
			int bx0 = sx(b), by0 = sy(b);
			boolean over = mx >= bx0 && mx <= bx0 + BW && my >= by0 && my <= by0 + BH;
			hov[i] = Anim.approach(hov[i], over ? 1f : 0f, 14f);
			float appear = Anim.smooth(Mth.clamp(t * 1.8f - i * 0.16f, 0f, 1f));
			float grow = hov[i] * 3f;
			float bx = bx0 - grow, by = by0 - grow / 2f + (1f - appear) * 10f;
			float bw = BW + grow * 2f, bh = BH + grow;
			if (hov[i] > 0.02f) Draw.glow(g, bx + bw / 2f, by + bh / 2f, bw * 1.35f, Draw.a(Theme.accent(), 0.16f * hov[i] * appear));
			Draw.glass(g, bx, by, bw, bh, 8, appear);
			String label = b == null ? Lang.t("Accounts") : b.getMessage().getString();
			int tc = Draw.a(Draw.lerp(0xFFD0D0DE, Theme.TEXT, hov[i]), appear);
			Draw.text(g, label, bx + (bw - Draw.width(label)) / 2f, by + (bh - 8) / 2f, tc);
			if (b == null) {
				String nick = Draw.clip(Accounts.currentName(), 70);
				Draw.text(g, nick, bx + bw - 8 - Draw.width(nick) * 0.75f, by + (bh - 6) / 2f, 0.75f, Draw.a(Theme.MUTED, appear), false);
			}
		}

		Draw.text(g, "Lumen Visuals", 8, height - 14, 0.8f, Draw.a(Theme.MUTED, t), false);
		String r = "Fabric 1.21.11";
		Draw.text(g, r, width - 8 - Draw.width(r) * 0.8f, height - 14, 0.8f, Draw.a(Theme.MUTED, t), false);
	}

	private static float frac(float v) {
		return v - (float) Math.floor(v);
	}
}
