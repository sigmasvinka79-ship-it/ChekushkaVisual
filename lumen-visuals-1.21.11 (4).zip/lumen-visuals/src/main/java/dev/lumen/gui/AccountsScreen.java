package dev.lumen.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

import dev.lumen.core.Theme;
import dev.lumen.feature.Accounts;
import dev.lumen.hud.Notifications;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import dev.lumen.util.Lang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/**
 * Менеджер аккаунтов: добавь ник, выбери его, измени или удали. Работает на серверах с offline-режимом.
 * Первая строка — твой оригинальный аккаунт, по ней можно вернуться обратно.
 */
public final class AccountsScreen extends Screen {
	private static final int PW = 320, PH = 250, ROW = 28;

	private record Region(float x, float y, float w, float h, IntConsumer click) {
		boolean has(double px, double py) {
			return px >= x && px <= x + w && py >= y && py <= y + h;
		}
	}

	private final Screen parent;
	private final Anim.Timer timer = new Anim.Timer();
	private final List<Region> regions = new ArrayList<>();
	private String input = "", editing = "";
	private boolean shift;
	private float t, scroll, scrollTarget, contentH;

	public AccountsScreen(Screen parent) {
		super(Component.literal("Accounts"));
		this.parent = parent;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}

	private int c(float a, int color) {
		return Draw.a(color, a);
	}

	private void submit() {
		if (!editing.isEmpty()) {
			if (Accounts.rename(editing, input)) Notifications.push("Accounts", input, Theme.GOOD);
			else Notifications.push("Accounts", Lang.t("Nickname: 3-16 chars, A-Z 0-9 _"), Theme.BAD);
			editing = "";
			input = "";
		} else if (!input.isEmpty()) {
			if (Accounts.add(input)) {
				Notifications.push("Accounts", Lang.t("Add") + ": " + input, Theme.GOOD);
				input = "";
			} else {
				Notifications.push("Accounts", Lang.t("Nickname: 3-16 chars, A-Z 0-9 _"), Theme.BAD);
			}
		}
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		float d = timer.tick();
		Anim.dt = d;
		t = Math.min(1f, t + d / 0.28f);
		float a = Anim.smooth(Mth.clamp(t * 1.6f, 0f, 1f));
		float pop = Anim.easeOutBack(t);

		g.fillGradient(0, 0, width, height, Draw.a(0xFF06030E, 0.92f * a), Draw.a(0xFF150A28, 0.92f * a));
		regions.clear();

		float x = (width - PW) / 2f, y = (height - PH) / 2f + (1f - Anim.easeOut(t)) * 14f;
		float sc = 0.9f + 0.1f * pop;
		var ps = g.pose();
		ps.pushMatrix();
		ps.translate(width / 2f, height / 2f);
		ps.scale(sc, sc);
		ps.translate(-width / 2f, -height / 2f);

		Draw.shadow(g, x, y, PW, PH, 10, a);
		Draw.glass(g, x, y, PW, PH, 10, Math.min(1f, a * 1.2f));
		Draw.sheen(g, x, y, PW, PH, a);
		Draw.text(g, Lang.t("Accounts"), x + 16, y + 13, 1.4f, c(a, Theme.TEXT), true);
		Draw.text(g, Lang.t("Works on offline-mode servers only"), x + 16, y + 31, 0.72f, c(a, Theme.MUTED), false);
		g.fill(Math.round(x) + 14, Math.round(y) + 42, Math.round(x + PW) - 14, Math.round(y) + 43, c(a, 0x16FFFFFF));

		// список
		float vy0 = y + 48, vy1 = y + PH - 60;
		float maxScroll = Math.max(0f, contentH - (vy1 - vy0));
		scrollTarget = Mth.clamp(scrollTarget, 0f, maxScroll);
		scroll = Anim.approach(scroll, scrollTarget, 16f);

		g.enableScissor(Math.round(x), Math.round(vy0), Math.round(x + PW), Math.round(vy1));
		float yy = vy0 - scroll;
		// оригинальный аккаунт
		drawRow(g, x + 14, yy, PW - 28, Lang.t("Original account") + ": " + Accounts.originalName(),
			Accounts.active.isEmpty() ? Lang.t("Active") : Lang.t("Click to use"), Accounts.active.isEmpty(), false, a, mx, my, vy0, vy1,
			b -> {
				Accounts.useOriginal();
				Notifications.push("Accounts", Accounts.originalName(), Theme.accent());
			}, null, null);
		yy += ROW + 4;
		for (String n : new ArrayList<>(Accounts.LIST)) {
			boolean act = n.equals(Accounts.active);
			drawRow(g, x + 14, yy, PW - 28, n, act ? Lang.t("Active") : Lang.t("Click to use"), act, true, a, mx, my, vy0, vy1,
				b -> {
					Accounts.use(n);
					Notifications.push("Accounts", n, Theme.accent());
				},
				b -> {
					editing = n;
					input = n;
				},
				b -> Accounts.remove(n));
			yy += ROW + 4;
		}
		contentH = yy + scroll - vy0;
		g.disableScissor();

		// строка ввода
		float iy = y + PH - 50;
		boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
		Draw.rounded(g, x + 14, iy, PW - 100, 22, 8, c(a, 0x1CFFFFFF));
		Draw.border(g, Math.round(x) + 14, Math.round(iy), PW - 100, 22, 8, c(a, Draw.a(Theme.accent(), 0.45f)));
		String shown = input.isEmpty() ? Lang.t("Nickname") : input;
		Draw.text(g, shown + (!input.isEmpty() && caret ? "|" : ""), x + 24, iy + 7, c(a, input.isEmpty() ? Theme.MUTED : Theme.TEXT));
		boolean over = mx >= x + PW - 78 && mx <= x + PW - 14 && my >= iy && my <= iy + 22;
		Draw.rounded(g, x + PW - 78, iy, 64, 22, 8, c(a, over ? Draw.a(Theme.accent(), 0.55f) : Draw.a(Theme.accent(), 0.32f)));
		String lbl = Lang.t(editing.isEmpty() ? "Add" : "Save");
		Draw.text(g, lbl, x + PW - 78 + (64 - Draw.width(lbl)) / 2f, iy + 7, c(a, Theme.TEXT));
		regions.add(new Region(x + PW - 78, iy, 64, 22, b -> submit()));
		Draw.text(g, Lang.t("Nickname: 3-16 chars, A-Z 0-9 _"), x + 16, iy + 28, 0.72f, c(a, Theme.MUTED), false);

		// назад
		boolean bo = mx >= x + 14 && mx <= x + 74 && my >= y + PH - 17 && my <= y + PH - 3;
		String back = Lang.t("Back");
		Draw.text(g, "< " + back, x + 16, y + PH - 15, 0.85f, c(a, bo ? Theme.TEXT : Theme.MUTED), true);
		regions.add(new Region(x + 14, y + PH - 17, 60, 14, b -> onClose()));

		ps.popMatrix();
	}

	private void drawRow(GuiGraphics g, float x, float y, float w, String title, String sub, boolean active, boolean editable,
		float a, int mx, int my, float vy0, float vy1, IntConsumer use, IntConsumer edit, IntConsumer del) {
		if (y + ROW < vy0 - 2 || y > vy1 + 2) return;
		boolean hov = mx >= x && mx <= x + w && my >= Math.max(y, vy0) && my <= Math.min(y + ROW, vy1);
		Draw.rounded(g, x, y, w, ROW, 8, c(a, hov ? 0x22FFFFFF : 0x12FFFFFF));
		Draw.border(g, Math.round(x), Math.round(y), Math.round(w), ROW, 8, c(a, 0x0DFFFFFF));
		if (active) {
			Draw.glow(g, x + 12, y + ROW / 2f, 24, c(a, Draw.a(Theme.accent(), 0.5f)));
			Draw.rounded(g, x + 9, y + ROW / 2f - 3, 6, 6, 3, c(a, Theme.accent()));
		}
		Draw.text(g, Draw.clip(title, (int) w - (editable ? 110 : 30)), x + 22, y + 6, c(a, Theme.TEXT));
		Draw.text(g, sub, x + 22, y + 17, 0.72f, c(a, active ? Theme.accent() : Theme.MUTED), false);

		float zoneW = editable ? w - 84 : w;
		float cy1 = Math.max(y, vy0), cy2 = Math.min(y + ROW, vy1);
		if (cy2 > cy1) regions.add(new Region(x, cy1, zoneW, cy2 - cy1, use));
		if (editable) {
			float bx = x + w - 80;
			pill(g, bx, y + 6, 36, Lang.t("Edit"), a, mx, my, vy0, vy1, edit);
			pill(g, bx + 40, y + 6, 36, Lang.t("Del"), a, mx, my, vy0, vy1, del);
		}
	}

	private void pill(GuiGraphics g, float x, float y, float w, String label, float a, int mx, int my, float vy0, float vy1, IntConsumer click) {
		boolean over = mx >= x && mx <= x + w && my >= y && my <= y + 16 && my >= vy0 && my <= vy1;
		Draw.rounded(g, x, y, w, 16, 6, c(a, over ? 0x38FFFFFF : 0x1CFFFFFF));
		Draw.text(g, label, x + (w - Draw.width(label) * 0.85f) / 2f, y + 4, 0.85f, c(a, Theme.TEXT), false);
		float cy1 = Math.max(y, vy0), cy2 = Math.min(y + 16, vy1);
		if (cy2 > cy1) regions.add(new Region(x, cy1, w, cy2 - cy1, click));
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		for (int i = regions.size() - 1; i >= 0; i--) {
			Region r = regions.get(i);
			if (r.has(e.x(), e.y())) {
				r.click().accept(e.button());
				return true;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double sx, double sy) {
		scrollTarget -= (float) sy * 26f;
		return true;
	}

	@Override
	public boolean keyReleased(KeyEvent e) {
		int k = e.key();
		if (k == GLFW.GLFW_KEY_LEFT_SHIFT || k == GLFW.GLFW_KEY_RIGHT_SHIFT) shift = false;
		return super.keyReleased(e);
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		int k = e.key();
		if (k == GLFW.GLFW_KEY_LEFT_SHIFT || k == GLFW.GLFW_KEY_RIGHT_SHIFT) {
			shift = true;
			return true;
		}
		if (k == GLFW.GLFW_KEY_ESCAPE) {
			if (!input.isEmpty() || !editing.isEmpty()) {
				input = "";
				editing = "";
				return true;
			}
			onClose();
			return true;
		}
		if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) {
			submit();
			return true;
		}
		if (k == GLFW.GLFW_KEY_BACKSPACE) {
			if (!input.isEmpty()) input = input.substring(0, input.length() - 1);
			return true;
		}
		if (input.length() < 16) {
			if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) {
				char c = (char) ((shift ? 'A' : 'a') + (k - GLFW.GLFW_KEY_A));
				input += c;
				return true;
			}
			if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) {
				input += (char) ('0' + (k - GLFW.GLFW_KEY_0));
				return true;
			}
			if (k == GLFW.GLFW_KEY_MINUS) {
				input += '_';
				return true;
			}
		}
		return super.keyPressed(e);
	}
}
