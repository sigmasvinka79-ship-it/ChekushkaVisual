package dev.lumen.feature;

import java.util.List;
import java.util.Locale;

import dev.lumen.core.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Чат-команды клиента: .gps, .cfg / .config, .help. Не отправляются на сервер. */
public final class Commands {
	private Commands() {}

	public static void msg(String text) {
		var mc = Minecraft.getInstance();
		if (mc.gui == null) return;
		mc.gui.getChat().addMessage(Component.literal("[Lumen] ").withStyle(ChatFormatting.LIGHT_PURPLE)
			.append(Component.literal(text).withStyle(ChatFormatting.WHITE)));
	}

	/** @return true, если сообщение было командой и не должно уходить на сервер. */
	public static boolean handle(String raw) {
		if (raw == null || !raw.startsWith(".") || raw.length() < 2) return false;
		String[] a = raw.substring(1).trim().split("\\s+");
		switch (a[0].toLowerCase(Locale.ROOT)) {
			case "gps" -> gps(a);
			case "cfg", "config" -> cfg(a);
			case "wp", "waypoint" -> wp(a);
			case "bind", "bnd" -> bind(a);
			case "acc", "account", "accounts" -> acc(a);
			case "hud" -> hud(a);
			case "help", "lumen" -> help();
			default -> {
				return false;
			}
		}
		return true;
	}

	private static void help() {
		msg(".gps <x> <z> — поставить метку  |  .gps off — убрать  |  .gps word <слово> — слово-триггер ивента");
		msg(".cfg list | save <имя> | load <имя> | delete <имя>  (готовые: fluger, broya)");
		msg(".wp add <имя> [x z] | go <имя> | del <имя> | list  —  точки (смерть сохраняется как «death»)");
		msg(".hud reset — вернуть HUD на стандартные места (двигать: меню → HUD editor)");
		msg(".bind add <функция> <клавиша> | del <функция> | list  (например: .bind add zoom c)");
		msg(".acc — менеджер аккаунтов; .acc add|use|del <ник>  (для серверов с offline-режимом)");
	}

	private static Double num(String s) {
		try {
			return Double.parseDouble(s.replace(",", "."));
		} catch (Exception e) {
			return null;
		}
	}

	private static void gps(String[] a) {
		if (a.length == 1) {
			if (Gps.active) {
				msg(String.format(Locale.ROOT, "Метка: %d %d, до неё %d м", Math.round(Gps.x), Math.round(Gps.z), Math.round(Gps.distance())));
			} else {
				msg("Метки нет. Пример: .gps 1200 -340");
			}
			return;
		}
		String sub = a[1].toLowerCase(Locale.ROOT);
		if (sub.equals("off") || sub.equals("clear") || sub.equals("стоп")) {
			Gps.clear();
			msg("Метка убрана.");
			return;
		}
		if (sub.equals("word") && a.length >= 3) {
			String w = a[2].toLowerCase(Locale.ROOT);
			if (!Gps.KEYWORDS.contains(w)) Gps.KEYWORDS.add(w);
			msg("Слово-триггер добавлено: " + w);
			return;
		}
		if (sub.equals("words")) {
			msg("Слова-триггеры: " + String.join(", ", Gps.KEYWORDS));
			return;
		}
		Double x = num(a[1]);
		Double z = a.length >= 4 ? num(a[3]) : (a.length >= 3 ? num(a[2]) : null);
		if (x == null || z == null) {
			msg("Формат: .gps <x> <z>");
			return;
		}
		Gps.set(x, z, "manual", false);
		msg(String.format(Locale.ROOT, "Метка поставлена: %d %d", Math.round(x), Math.round(z)));
	}

	private static void bind(String[] a) {
		if (a.length == 1 || a[1].equalsIgnoreCase("list")) {
			StringBuilder sb = new StringBuilder();
			for (var m : dev.lumen.core.Modules.ALL) {
				if (m.key != null && !m.key.isUnbound()) sb.append(m.name).append("=").append(m.key.getTranslatedKeyMessage().getString()).append("  ");
			}
			var zk = dev.lumen.visual.Zoom.KEY;
			if (zk != null && !zk.isUnbound()) sb.append("Zoom=").append(zk.getTranslatedKeyMessage().getString());
			msg(sb.length() == 0 ? "Биндов нет. Пример: .bind add zoom c" : sb.toString());
			return;
		}
		String sub = a[1].toLowerCase(Locale.ROOT);
		if (sub.equals("add") && a.length >= 4) {
			int code = Binds.parseKey(a[a.length - 1]);
			StringBuilder nm = new StringBuilder();
			for (int i = 2; i < a.length - 1; i++) nm.append(a[i]).append(' ');
			var km = Binds.find(nm.toString().trim());
			if (km == null) {
				msg("Нет такой функции: " + nm.toString().trim());
			} else if (code == -1) {
				msg("Не понял клавишу: " + a[a.length - 1] + " (буква, цифра, f1-f12, space, shift, mouse4...)");
			} else {
				Binds.set(km, code);
				msg("Бинд: " + nm.toString().trim() + " = " + km.getTranslatedKeyMessage().getString());
			}
		} else if ((sub.equals("del") || sub.equals("remove")) && a.length >= 3) {
			StringBuilder nm = new StringBuilder();
			for (int i = 2; i < a.length; i++) nm.append(a[i]).append(' ');
			var km = Binds.find(nm.toString().trim());
			if (km == null) {
				msg("Нет такой функции: " + nm.toString().trim());
			} else {
				Binds.clear(km);
				msg("Бинд снят: " + nm.toString().trim());
			}
		} else {
			msg(".bind add <функция> <клавиша> | del <функция> | list");
		}
	}

	private static void acc(String[] a) {
		var mc = Minecraft.getInstance();
		if (a.length == 1) {
			mc.execute(() -> mc.setScreen(new dev.lumen.gui.AccountsScreen(null)));
			return;
		}
		String sub = a[1].toLowerCase(Locale.ROOT);
		if (sub.equals("list")) {
			msg("Аккаунты: " + (Accounts.LIST.isEmpty() ? "—" : String.join(", ", Accounts.LIST)) + "  |  сейчас: " + Accounts.currentName());
		} else if (a.length >= 3 && sub.equals("add")) {
			msg(Accounts.add(a[2]) ? "Добавлен: " + a[2] : "Ник должен быть 3-16 символов (A-Z, 0-9, _) и не повторяться.");
		} else if (a.length >= 3 && sub.equals("use")) {
			if (Accounts.LIST.contains(a[2])) {
				Accounts.use(a[2]);
				msg("Аккаунт: " + a[2] + " (заработает при следующем подключении к серверу)");
			} else {
				msg("Нет такого аккаунта: " + a[2]);
			}
		} else if (a.length >= 3 && (sub.equals("del") || sub.equals("remove"))) {
			Accounts.remove(a[2]);
			msg("Удалён: " + a[2]);
		} else if (sub.equals("original")) {
			Accounts.useOriginal();
			msg("Вернул оригинальный аккаунт.");
		} else {
			msg(".acc [list | add <ник> | use <ник> | del <ник> | original]");
		}
	}

	private static void hud(String[] a) {
		if (a.length >= 2 && a[1].equalsIgnoreCase("reset")) {
			for (var w : dev.lumen.hud.HudRenderer.widgets()) w.reset();
			Config.save();
			msg("HUD сброшен на стандартные места.");
		} else {
			msg(".hud reset");
		}
	}

	private static void wp(String[] a) {
		var p = Minecraft.getInstance().player;
		if (a.length == 1 || a[1].equalsIgnoreCase("list")) {
			if (Waypoints.LIST.isEmpty()) {
				msg("Точек нет. Пример: .wp add база");
				return;
			}
			for (var w : Waypoints.LIST) msg(String.format(Locale.ROOT, "%s: %d %d %d", w.name(), Math.round(w.x()), Math.round(w.y()), Math.round(w.z())));
			return;
		}
		String sub = a[1].toLowerCase(Locale.ROOT);
		if (a.length < 3) {
			msg("Формат: .wp add|go|del <имя>");
			return;
		}
		String name = a[2];
		switch (sub) {
			case "add" -> {
				double x, y = p == null ? 64 : p.getY(), z;
				if (a.length >= 5 && num(a[3]) != null && num(a[4]) != null) {
					x = num(a[3]);
					z = num(a[4]);
				} else if (p != null) {
					x = p.getX();
					z = p.getZ();
				} else {
					return;
				}
				Waypoints.put(name, x, y, z);
				Config.save();
				msg(String.format(Locale.ROOT, "Точка %s: %d %d", name, Math.round(x), Math.round(z)));
			}
			case "go" -> {
				var w = Waypoints.find(name);
				if (w == null) {
					msg("Нет такой точки: " + name);
					return;
				}
				Gps.set(w.x(), w.z(), w.name(), false);
			}
			case "del", "delete", "remove" -> {
				msg(Waypoints.remove(name) ? "Удалено: " + name : "Нет такой точки: " + name);
				Config.save();
			}
			default -> msg("Формат: .wp add|go|del <имя>");
		}
	}

	private static void cfg(String[] a) {
		if (a.length == 1 || a[1].equalsIgnoreCase("list")) {
			List<String> mine = Configs.list();
			msg("Твои: " + (mine.isEmpty() ? "—" : String.join(", ", mine)) + "  |  Готовые: " + String.join(", ", Configs.PRESETS));
			return;
		}
		if (a.length < 3) {
			msg("Формат: .cfg save|load|delete <имя>");
			return;
		}
		String n = Configs.clean(a[2]);
		if (n.isEmpty()) {
			msg("Имя: латиница, цифры, - и _");
			return;
		}
		switch (a[1].toLowerCase(Locale.ROOT)) {
			case "save", "s" -> {
				if (Configs.isPreset(n)) {
					msg("Это имя занято готовым конфигом, выбери другое.");
					return;
				}
				msg(Configs.save(n) ? "Сохранено: " + n : "Не удалось сохранить.");
			}
			case "load", "l" -> {
				if (Configs.load(n)) {
					Config.save();
					msg("Загружено: " + n);
				} else {
					msg("Нет такого конфига: " + n);
				}
			}
			case "delete", "del", "remove", "rm" -> {
				if (Configs.isPreset(n)) {
					msg("Готовые конфиги удалять нельзя.");
					return;
				}
				msg(Configs.delete(n) ? "Удалено: " + n : "Нет такого конфига: " + n);
			}
			default -> msg("Формат: .cfg save|load|delete <имя>");
		}
	}
}
