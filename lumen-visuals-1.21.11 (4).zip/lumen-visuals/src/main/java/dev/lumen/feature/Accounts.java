package dev.lumen.feature;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lumen.core.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;

/**
 * Аккаунт-менеджер для серверов с offline-режимом: добавляешь ник, выбираешь его, и игра заходит под ним.
 * На лицензионных (online-mode) серверах это не работает: они проверяют сессию Mojang.
 * Настоящий аккаунт хранится как «Original» и возвращается одним кликом.
 */
public final class Accounts {
	public static final List<String> LIST = new ArrayList<>();
	/** Пусто = оригинальный аккаунт. */
	public static String active = "";

	private static User original;
	private static Field userField;
	private static boolean searched;

	private Accounts() {}

	private static Path file() {
		return Config.dir().resolve("accounts.json");
	}

	public static boolean valid(String n) {
		return n != null && n.matches("[A-Za-z0-9_]{3,16}");
	}

	private static Field find() {
		if (!searched) {
			searched = true;
			for (Field f : Minecraft.class.getDeclaredFields()) {
				if (f.getType() == User.class && !Modifier.isStatic(f.getModifiers())) {
					f.setAccessible(true);
					userField = f;
					break;
				}
			}
		}
		return userField;
	}

	private static void capture() {
		if (original == null) original = Minecraft.getInstance().getUser();
	}

	public static String originalName() {
		capture();
		return original != null ? original.getName() : "?";
	}

	public static String currentName() {
		return Minecraft.getInstance().getUser().getName();
	}

	public static void load() {
		try {
			Path f = file();
			if (!Files.exists(f)) return;
			JsonObject o = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
			LIST.clear();
			if (o.has("list")) for (JsonElement e : o.getAsJsonArray("list")) LIST.add(e.getAsString());
			active = o.has("active") ? o.get("active").getAsString() : "";
		} catch (Exception ignored) {
		}
	}

	public static void save() {
		try {
			JsonObject o = new JsonObject();
			JsonArray a = new JsonArray();
			for (String n : LIST) a.add(n);
			o.add("list", a);
			o.addProperty("active", active);
			Files.createDirectories(Config.dir());
			Files.writeString(file(), Config.GSON.toJson(o), StandardCharsets.UTF_8);
		} catch (Exception ignored) {
		}
	}

	/** При старте игры возвращаем последний выбранный аккаунт. */
	public static void applyOnStart() {
		capture();
		if (!active.isEmpty() && LIST.contains(active)) set(active);
		else active = "";
	}

	public static boolean add(String name) {
		if (!valid(name)) return false;
		for (String n : LIST) if (n.equalsIgnoreCase(name)) return false;
		LIST.add(name);
		save();
		return true;
	}

	public static boolean rename(String old, String neu) {
		if (!valid(neu)) return false;
		int i = LIST.indexOf(old);
		if (i < 0) return false;
		for (String n : LIST) if (!n.equals(old) && n.equalsIgnoreCase(neu)) return false;
		LIST.set(i, neu);
		if (active.equals(old)) set(neu);
		save();
		return true;
	}

	public static void remove(String name) {
		LIST.remove(name);
		if (active.equals(name)) useOriginal();
		save();
	}

	public static void use(String name) {
		if (!LIST.contains(name)) return;
		capture();
		set(name);
		save();
	}

	public static void useOriginal() {
		capture();
		Field f = find();
		try {
			if (f != null && original != null) f.set(Minecraft.getInstance(), original);
		} catch (Throwable ignored) {
		}
		active = "";
		save();
	}

	private static void set(String name) {
		Field f = find();
		if (f == null) return;
		try {
			UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
			f.set(Minecraft.getInstance(), new User(name, id, "0", Optional.empty(), Optional.empty()));
			active = name;
		} catch (Throwable ignored) {
		}
	}
}
