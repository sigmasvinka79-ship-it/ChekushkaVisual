package dev.lumen.feature;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.hud.Notifications;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Лёгкий помощник для элитр: по одной кнопке меняет элитру и нагрудник, по другой — фейерверк.
 * Одно нажатие = обычные клики по инвентарю, никакого авто-полёта и автоматики.
 */
public final class ElytraHelper {
	public static KeyMapping SWAP, FIREWORK;
	private static int swapBackSlot = -1;

	private ElytraHelper() {}

	private static boolean isChestplate(ItemStack s) {
		return !s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().endsWith("_chestplate");
	}

	private static void say(String t) {
		if (Modules.EL_NOTIFY.bool) Notifications.push("Elytra", t, Theme.accent());
	}

	public static void tick(Minecraft mc) {
		var p = mc.player;
		var gm = mc.gameMode;
		if (p == null || gm == null || mc.level == null) return;

		if (swapBackSlot >= 0) {
			gm.handleInventoryMouseClick(p.inventoryMenu.containerId, swapBackSlot, 40, ClickType.SWAP, p);
			swapBackSlot = -1;
		}
		if (!Modules.ELYTRA.enabled || mc.screen != null) {
			while (SWAP.consumeClick()) { }
			while (FIREWORK.consumeClick()) { }
			return;
		}
		while (SWAP.consumeClick()) swap(mc);
		while (FIREWORK.consumeClick()) firework(mc);
	}

	private static void swap(Minecraft mc) {
		var p = mc.player;
		var gm = mc.gameMode;
		boolean wearing = p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
		int slot = -1;
		for (int i = 9; i <= 44; i++) {
			ItemStack s = p.inventoryMenu.getSlot(i).getItem();
			if (wearing ? isChestplate(s) : s.is(Items.ELYTRA)) {
				slot = i;
				break;
			}
		}
		if (slot < 0) {
			say(wearing ? "No chestplate in inventory" : "No elytra in inventory");
			return;
		}
		int id = p.inventoryMenu.containerId;
		gm.handleInventoryMouseClick(id, slot, 0, ClickType.PICKUP, p);
		gm.handleInventoryMouseClick(id, 6, 0, ClickType.PICKUP, p);
		if (!p.inventoryMenu.getCarried().isEmpty()) {
			gm.handleInventoryMouseClick(id, slot, 0, ClickType.PICKUP, p);
		}
		say(wearing ? "Chestplate equipped" : "Elytra equipped");
	}

	private static void firework(Minecraft mc) {
		var p = mc.player;
		var gm = mc.gameMode;
		if (!p.isFallFlying()) {
			say("Not gliding");
			return;
		}
		if (p.getOffhandItem().is(Items.FIREWORK_ROCKET)) {
			gm.useItem(p, InteractionHand.OFF_HAND);
			return;
		}
		if (p.getMainHandItem().is(Items.FIREWORK_ROCKET)) {
			gm.useItem(p, InteractionHand.MAIN_HAND);
			return;
		}
		for (int i = 0; i < 9; i++) {
			if (p.getInventory().getItem(i).is(Items.FIREWORK_ROCKET)) {
				int slot = 36 + i;
				gm.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
				gm.useItem(p, InteractionHand.OFF_HAND);
				swapBackSlot = slot;
				return;
			}
		}
		say("No fireworks in hotbar");
	}
}
