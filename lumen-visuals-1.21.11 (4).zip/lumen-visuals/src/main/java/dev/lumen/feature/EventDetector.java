package dev.lumen.feature;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import dev.lumen.core.Modules;

/**
 * Ищет в чате сообщения про ивенты с координатами и ставит GPS-метку.
 * Формат сообщений конкретного сервера мне неизвестен, поэтому детектор эвристический:
 * ключевое слово (ивент/метеорит/...) + координаты в одном из распространённых видов.
 */
public final class EventDetector {
	private static final Pattern LABELED = Pattern.compile(
		"(?i)x\\s*[:=]?\\s*(-?\\d{1,6})(?:\\D{0,10}?y\\s*[:=]?\\s*-?\\d{1,4})?\\D{0,10}?z\\s*[:=]?\\s*(-?\\d{1,6})");
	private static final Pattern TRIPLE = Pattern.compile(
		"(?<![\\d.-])(-?\\d{1,6})\\s*[,; ]\\s*(-?\\d{1,3})\\s*[,; ]\\s*(-?\\d{1,6})(?![\\d.])");
	private static final Pattern PAIR = Pattern.compile(
		"(?<![\\d.-])(-?\\d{2,6})\\s*[,;]?\\s+(-?\\d{2,6})(?![\\d.])");

	private static long lastAuto;

	private EventDetector() {}

	public static void onMessage(String s) {
		if (s == null || !Modules.GPS.enabled || !Modules.GPS_AUTO.bool) return;
		String low = s.toLowerCase(Locale.ROOT);
		if (low.startsWith(".")) return;

		boolean kw = false;
		String found = "";
		for (String k : Gps.KEYWORDS) {
			if (low.contains(k)) {
				kw = true;
				found = k;
				break;
			}
		}
		if (!kw) return;

		double[] c = parse(s);
		if (c == null) return;

		long now = System.currentTimeMillis();
		if (now - lastAuto < 1500) return;
		lastAuto = now;
		Gps.set(c[0], c[1], found, true);
	}

	private static double[] parse(String s) {
		Matcher m = LABELED.matcher(s);
		if (m.find()) return new double[] {Double.parseDouble(m.group(1)), Double.parseDouble(m.group(2))};
		m = TRIPLE.matcher(s);
		if (m.find()) {
			int y = Integer.parseInt(m.group(2));
			if (y >= -64 && y <= 330) {
				return new double[] {Double.parseDouble(m.group(1)), Double.parseDouble(m.group(3))};
			}
		}
		m = PAIR.matcher(s);
		if (m.find()) return new double[] {Double.parseDouble(m.group(1)), Double.parseDouble(m.group(2))};
		return null;
	}
}
