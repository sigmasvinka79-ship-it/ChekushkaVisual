package dev.lumen.feature;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.lumen.core.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;

/** Именованные точки + автоматическая точка смерти. */
public final class Waypoints {
	public record Wp(String name, double x, double y, double z) {}

	public static final List<Wp> LIST = new ArrayList<>();
	private static boolean deathSaved;

	private Waypoints() {}

	public static void put(String name, double x, double y, double z) {
		LIST.removeIf(w -> w.name().equalsIgnoreCase(name));
		LIST.add(new Wp(name, x, y, z));
	}

	public static Wp find(String name) {
		for (Wp w : LIST) if (w.name().equalsIgnoreCase(name)) return w;
		return null;
	}

	public static boolean remove(String name) {
		return LIST.removeIf(w -> w.name().equalsIgnoreCase(name));
	}

	public static JsonArray toJson() {
		JsonArray a = new JsonArray();
		for (Wp w : LIST) {
			JsonObject o = new JsonObject();
			o.addProperty("name", w.name());
			o.addProperty("x", w.x());
			o.addProperty("y", w.y());
			o.addProperty("z", w.z());
			a.add(o);
		}
		return a;
	}

	public static void fromJson(JsonArray a) {
		LIST.clear();
		for (JsonElement e : a) {
			JsonObject o = e.getAsJsonObject();
			LIST.add(new Wp(o.get("name").getAsString(), o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble()));
		}
	}

	public static void tick(Minecraft mc) {
		if (mc.screen instanceof DeathScreen) {
			if (!deathSaved && mc.player != null) {
				deathSaved = true;
				double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
				put("death", x, y, z);
				if (Modules.GPS_DEATH.bool && Modules.GPS.enabled) Gps.set(x, z, "death", false);
			}
		} else {
			deathSaved = false;
		}
	}
}
