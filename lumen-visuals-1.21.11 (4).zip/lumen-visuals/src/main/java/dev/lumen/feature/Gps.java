package dev.lumen.feature;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.hud.Notifications;
import net.minecraft.client.Minecraft;

/** Текущая GPS-метка: ставится командой .gps или автоматически из чата (ивент). */
public final class Gps {
	public static boolean active;
	public static double x, z;
	public static String label = "";

	public static final List<String> KEYWORDS = new ArrayList<>(List.of(
		"ивент", "эвент", "event", "метеор", "вулкан", "аирдроп", "airdrop", "сундук", "босс", "руин", "портал"));

	private Gps() {}

	public static void set(double nx, double nz, String lbl, boolean auto) {
		x = nx;
		z = nz;
		label = lbl;
		active = true;
		Modules.GPS.enabled = true;
		String t = String.format(Locale.ROOT, "%d  %d", Math.round(nx), Math.round(nz));
		Notifications.push(auto ? "Event: " + lbl : "GPS set", t, Theme.accent());
	}

	public static void clear() {
		active = false;
	}

	public static double distance() {
		var p = Minecraft.getInstance().player;
		return p == null ? 0 : Math.hypot(p.getX() - x, p.getZ() - z);
	}

	/** Авто-сброс, когда дошёл до точки. */
	public static void tick(Minecraft mc) {
		if (active && mc.player != null && distance() <= Modules.GPS_ARRIVE.f()) {
			active = false;
			Notifications.push("GPS", "Arrived", Theme.GOOD);
		}
	}
}
