package dev.lumen.feature;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import dev.lumen.core.Config;

/** Пользовательские конфиги (.cfg) + встроенные пресеты. */
public final class Configs {
	public static final String[] PRESETS = {"fluger", "broya"};

	private Configs() {}

	public static String clean(String n) {
		String s = n.toLowerCase().replaceAll("[^a-z0-9_-]", "");
		return s.length() > 32 ? s.substring(0, 32) : s;
	}

	public static boolean isPreset(String n) {
		for (String p : PRESETS) if (p.equals(n)) return true;
		return false;
	}

	public static List<String> list() {
		List<String> out = new ArrayList<>();
		Path d = Config.dir();
		if (Files.isDirectory(d)) {
			try (Stream<Path> st = Files.list(d)) {
				st.map(p -> p.getFileName().toString())
					.filter(f -> f.endsWith(".json"))
					.map(f -> f.substring(0, f.length() - 5))
					.sorted()
					.forEach(out::add);
			} catch (Exception ignored) {
			}
		}
		return out;
	}

	public static boolean save(String name) {
		try {
			Files.createDirectories(Config.dir());
			try (Writer w = Files.newBufferedWriter(Config.dir().resolve(name + ".json"))) {
				Config.GSON.toJson(Config.toJson(), w);
			}
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean load(String name) {
		try {
			Path f = Config.dir().resolve(name + ".json");
			if (Files.exists(f)) {
				try (Reader r = Files.newBufferedReader(f)) {
					Config.fromJson(JsonParser.parseReader(r).getAsJsonObject());
				}
				return true;
			}
			if (isPreset(name)) {
				try (InputStream in = Configs.class.getResourceAsStream("/assets/lumen/presets/" + name + ".json")) {
					if (in == null) return false;
					JsonObject o = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
					Config.fromJson(o);
					return true;
				}
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	public static boolean delete(String name) {
		try {
			return Files.deleteIfExists(Config.dir().resolve(name + ".json"));
		} catch (Exception e) {
			return false;
		}
	}
}
