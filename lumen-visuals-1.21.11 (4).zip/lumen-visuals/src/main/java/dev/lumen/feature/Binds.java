package dev.lumen.feature;

import java.util.Locale;

import com.mojang.blaze3d.platform.InputConstants;
import dev.lumen.LumenClient;
import dev.lumen.core.Module;
import dev.lumen.core.Modules;
import dev.lumen.visual.Zoom;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** Команды .bind: привязка клавиш к функциям прямо из чата (поддерживает и русскую раскладку). */
public final class Binds {
	private static final String RU = "йцукенгшщзхъфывапролджэячсмитьбю";
	private static final String EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,.";

	private Binds() {}

	/** @return GLFW-код клавиши или -1; mouse-кнопки возвращаются как -(100 + индекс). */
	public static int parseKey(String raw) {
		String s = raw.toLowerCase(Locale.ROOT).trim();
		if (s.isEmpty()) return -1;
		if (s.length() == 1) {
			int ri = RU.indexOf(s.charAt(0));
			char c = ri >= 0 ? EN.charAt(ri) : s.charAt(0);
			if (c >= 'a' && c <= 'z') return GLFW.GLFW_KEY_A + (c - 'a');
			if (c >= '0' && c <= '9') return GLFW.GLFW_KEY_0 + (c - '0');
			return switch (c) {
				case '-' -> GLFW.GLFW_KEY_MINUS;
				case '=' -> GLFW.GLFW_KEY_EQUAL;
				case '[' -> GLFW.GLFW_KEY_LEFT_BRACKET;
				case ']' -> GLFW.GLFW_KEY_RIGHT_BRACKET;
				case ';' -> GLFW.GLFW_KEY_SEMICOLON;
				case '\'' -> GLFW.GLFW_KEY_APOSTROPHE;
				case ',' -> GLFW.GLFW_KEY_COMMA;
				case '.' -> GLFW.GLFW_KEY_PERIOD;
				case '/' -> GLFW.GLFW_KEY_SLASH;
				default -> -1;
			};
		}
		if (s.matches("f([1-9]|1[0-2])")) return GLFW.GLFW_KEY_F1 + Integer.parseInt(s.substring(1)) - 1;
		if (s.matches("mouse[3-5]")) return -(100 + Integer.parseInt(s.substring(5)) - 1);
		return switch (s) {
			case "space", "пробел" -> GLFW.GLFW_KEY_SPACE;
			case "tab" -> GLFW.GLFW_KEY_TAB;
			case "enter" -> GLFW.GLFW_KEY_ENTER;
			case "lshift", "shift" -> GLFW.GLFW_KEY_LEFT_SHIFT;
			case "rshift" -> GLFW.GLFW_KEY_RIGHT_SHIFT;
			case "lctrl", "ctrl" -> GLFW.GLFW_KEY_LEFT_CONTROL;
			case "rctrl" -> GLFW.GLFW_KEY_RIGHT_CONTROL;
			case "lalt", "alt" -> GLFW.GLFW_KEY_LEFT_ALT;
			case "ralt" -> GLFW.GLFW_KEY_RIGHT_ALT;
			case "caps" -> GLFW.GLFW_KEY_CAPS_LOCK;
			case "up" -> GLFW.GLFW_KEY_UP;
			case "down" -> GLFW.GLFW_KEY_DOWN;
			case "left" -> GLFW.GLFW_KEY_LEFT;
			case "right" -> GLFW.GLFW_KEY_RIGHT;
			case "insert" -> GLFW.GLFW_KEY_INSERT;
			case "home" -> GLFW.GLFW_KEY_HOME;
			case "end" -> GLFW.GLFW_KEY_END;
			default -> -1;
		};
	}

	private static String slug(String s) {
		return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "");
	}

	/** Ищет клавишу по имени: zoom, menu, elytraswap, elytrafirework или название функции. */
	public static KeyMapping find(String name) {
		String q = slug(name);
		if (q.equals("zoom") || q.equals("зум")) return Zoom.KEY;
		if (q.equals("menu") || q.equals("меню")) return LumenClient.OPEN_MENU;
		if (q.equals("elytraswap") || q.equals("swap")) return ElytraHelper.SWAP;
		if (q.equals("elytrafirework") || q.equals("firework")) return ElytraHelper.FIREWORK;
		Module best = null;
		for (Module m : Modules.ALL) {
			if (m.key == null) continue;
			String ms = slug(m.name);
			if (ms.equals(q)) return m.key;
			if (best == null && ms.startsWith(q)) best = m;
		}
		return best == null ? null : best.key;
	}

	public static void set(KeyMapping km, int code) {
		InputConstants.Key key = code <= -100
			? InputConstants.Type.MOUSE.getOrCreate(-code - 100)
			: InputConstants.Type.KEYSYM.getOrCreate(code);
		km.setKey(key);
		KeyMapping.resetMapping();
		Minecraft.getInstance().options.save();
	}

	public static void clear(KeyMapping km) {
		km.setKey(InputConstants.UNKNOWN);
		KeyMapping.resetMapping();
		Minecraft.getInstance().options.save();
	}
}
