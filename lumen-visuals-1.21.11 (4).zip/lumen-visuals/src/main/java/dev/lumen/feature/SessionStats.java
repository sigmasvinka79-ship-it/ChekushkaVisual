package dev.lumen.feature;

import dev.lumen.hud.TargetTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.util.Util;

/** Статистика сессии: время, убийства, смерти, таймер боя (15 с после удара или урона). */
public final class SessionStats {
	public static long start = Util.getMillis();
	public static int kills, deaths;
	public static long lastCombat;
	private static long seenKill;
	private static boolean deathCounted;
	private static int prevHurt;
	private static Object level;

	private SessionStats() {}

	public static void tick(Minecraft mc) {
		var p = mc.player;
		if (p == null || mc.level == null) return;
		if (level != mc.level) {
			level = mc.level;
			start = Util.getMillis();
			kills = 0;
			deaths = 0;
			lastCombat = 0;
		}
		long now = Util.getMillis();
		if (TargetTracker.lastKill != seenKill) {
			seenKill = TargetTracker.lastKill;
			kills++;
			lastCombat = now;
		}
		if (TargetTracker.lastHit > lastCombat) lastCombat = TargetTracker.lastHit;
		if (p.hurtTime > prevHurt) lastCombat = now;
		prevHurt = p.hurtTime;

		if (mc.screen instanceof DeathScreen) {
			if (!deathCounted) {
				deathCounted = true;
				deaths++;
			}
		} else {
			deathCounted = false;
		}
	}

	/** Секунд до конца боя или -1, если боя нет. */
	public static int combatLeft() {
		if (lastCombat == 0) return -1;
		long left = 15000 - (Util.getMillis() - lastCombat);
		return left > 0 ? (int) ((left + 999) / 1000) : -1;
	}
}
