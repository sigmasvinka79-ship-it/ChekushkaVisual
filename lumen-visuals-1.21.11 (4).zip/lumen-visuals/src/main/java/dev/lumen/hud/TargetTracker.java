package dev.lumen.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Отслеживает существо под прицелом (только ванильный hitResult), считает попадания,
 * комбо и убийства.
 */
public final class TargetTracker {
	public static LivingEntity entity;
	public static long lastSeen, lastHit, lastKill, comboTime;
	public static int combo;
	private static LivingEntity prev, killed;
	private static int prevHurt;

	private TargetTracker() {}

	public static void update(Minecraft mc) {
		long now = Util.getMillis();
		if (mc.hitResult instanceof EntityHitResult ehr
			&& ehr.getEntity() instanceof LivingEntity le
			&& le != mc.player && le.isAlive()) {
			entity = le;
			lastSeen = now;
		}
		if (combo > 0 && now - comboTime > 3000) combo = 0;

		LivingEntity e = entity;
		if (e == null) return;
		if (e == prev && e.hurtTime > prevHurt && mc.player != null && mc.player.swinging) {
			lastHit = now;
			combo = (now - comboTime < 3000) ? combo + 1 : 1;
			comboTime = now;
		}
		if (!e.isAlive() && e != killed && now - lastHit < 2500 && lastHit > 0) {
			killed = e;
			lastKill = now;
		}
		prev = e;
		prevHurt = e.hurtTime;
	}
}
