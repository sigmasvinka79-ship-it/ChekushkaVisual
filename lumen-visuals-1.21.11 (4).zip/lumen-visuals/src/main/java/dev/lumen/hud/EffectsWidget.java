package dev.lumen.hud;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Список эффектов: иконка, название, уровень, таймер до конца и полоска прогресса. */
public final class EffectsWidget extends HudWidget {
	private static final int ROW_H = 26, GAP = 3;
	private static final String[] ROMAN = {"", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

	private static final class Row {
		String key, name = "", time = "";
		Identifier sprite;
		int color, dur, lastDur, max = 1, nameW, amp = -1, lastSecs = -2, lastFmt = -1;
		boolean good, inf, alive;
		float vis, y = -1f, bar = 1f;
	}

	private final Map<String, Row> rows = new HashMap<>();
	private final List<Row> list = new ArrayList<>();

	public EffectsWidget() {
		super(Modules.EFFECTS, 0.008f, 0.13f);
	}

	private void feed(Holder<MobEffect> h, int amp, int dur, boolean inf) {
		MobEffect e = h.value();
		Identifier id = BuiltInRegistries.MOB_EFFECT.getKey(e);
		if (id == null) return;
		String key = id.toString();
		Row r = rows.get(key);
		if (r == null) {
			r = new Row();
			r.key = key;
			r.sprite = Identifier.fromNamespaceAndPath(id.getNamespace(), "mob_effect/" + id.getPath());
			r.color = 0xFF000000 | e.getColor();
			r.good = e.isBeneficial();
			r.lastDur = dur;
			r.max = Math.max(1, dur);
			rows.put(key, r);
		}
		if (r.amp != amp) {
			r.amp = amp;
			r.name = e.getDisplayName().getString() + (amp > 0 ? " " + (amp + 1 < ROMAN.length ? ROMAN[amp + 1] : Integer.toString(amp + 1)) : "");
			r.nameW = Draw.width(r.name);
		}
		if (dur > r.lastDur + 5) r.max = dur;
		r.max = Math.max(r.max, dur);
		r.lastDur = dur;
		r.dur = dur;
		r.inf = inf;
		r.alive = true;
	}

	private static String two(int v) {
		return v < 10 ? "0" + v : Integer.toString(v);
	}

	private static String format(int secs, int mode) {
		if (mode == 1) return secs + "s";
		if (secs >= 3600) return (secs / 3600) + ":" + two((secs / 60) % 60) + ":" + two(secs % 60);
		return (secs / 60) + ":" + two(secs % 60);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		for (Row r : rows.values()) r.alive = false;

		boolean any = false;
		for (MobEffectInstance i : mc.player.getActiveEffects()) {
			feed(i.getEffect(), i.getAmplifier(), i.getDuration(), i.isInfiniteDuration());
			any = true;
		}
		if (!any && HudRenderer.editing()) {
			feed(MobEffects.SPEED, 1, 1800, false);
			feed(MobEffects.STRENGTH, 0, 140, false);
			feed(MobEffects.REGENERATION, 0, 4200, false);
		}

		list.clear();
		Iterator<Row> it = rows.values().iterator();
		while (it.hasNext()) {
			Row r = it.next();
			r.vis = Anim.approach(r.vis, r.alive ? 1f : 0f, 12f);
			if (!r.alive && r.vis < 0.02f) {
				it.remove();
				continue;
			}
			list.add(r);
		}
		if (list.isEmpty()) {
			w = 0;
			h = 0;
			return;
		}
		list.sort((p, q) -> p.good != q.good ? (p.good ? -1 : 1) : p.key.compareTo(q.key));

		boolean icons = Modules.EF_ICONS.bool, bar = Modules.EF_BAR.bool;
		int fmt = Modules.EF_FORMAT.mode;
		int warn = Modules.EF_WARN.i();
		int maxName = 0;
		for (Row r : list) maxName = Math.max(maxName, r.nameW);
		float W = Math.max(108f, (icons ? 32f : 10f) + maxName + 40f);
		w = W;
		h = list.size() * (ROW_H + GAP) - GAP;

		long now = Util.getMillis();
		for (int i = 0; i < list.size(); i++) {
			Row r = list.get(i);
			float ty = i * (ROW_H + GAP);
			r.y = r.y < 0f ? ty : Anim.approach(r.y, ty, 14f);
			float ra = a * r.vis;
			float rx = x + (1f - r.vis) * -12f;
			float ry = y + r.y;

			Draw.panel(g, rx, ry, W, ROW_H, ra);

			float tx = rx + 9;
			if (icons) {
				if (ra > 0.35f) {
					g.blitSprite(RenderPipelines.GUI_TEXTURED, r.sprite, Math.round(rx + 6), Math.round(ry + 4), 18, 18);
				}
				tx = rx + 30;
			}
			Draw.text(g, r.name, tx, ry + (bar ? 5 : 9), Draw.a(r.good ? Theme.TEXT : 0xFFFFC9C9, ra));

			int secs = r.inf ? -1 : (r.dur + 19) / 20;
			if (secs != r.lastSecs || fmt != r.lastFmt) {
				r.lastSecs = secs;
				r.lastFmt = fmt;
				r.time = r.inf ? "inf" : format(secs, fmt);
			}
			boolean blink = !r.inf && warn > 0 && secs <= warn;
			int tc = Theme.MUTED;
			float ta = ra;
			if (blink) {
				tc = Theme.BAD;
				ta = ra * (0.6f + 0.4f * Mth.sin(now / 110f));
			}
			Draw.text(g, r.time, rx + W - 8 - Draw.width(r.time), ry + (bar ? 5 : 9), Draw.a(tc, ta));

			if (bar) {
				float frac = r.inf ? 1f : Mth.clamp(r.dur / (float) r.max, 0f, 1f);
				r.bar = Anim.approach(r.bar, frac, 10f);
				Draw.bar(g, tx, ry + ROW_H - 7, W - (tx - rx) - 8, 3, r.bar, Draw.lerp(r.color, 0xFFFFFFFF, 0.2f), ra);
			}
		}
	}
}
