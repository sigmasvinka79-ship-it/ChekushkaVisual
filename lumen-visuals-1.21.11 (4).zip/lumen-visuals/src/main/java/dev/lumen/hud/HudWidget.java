package dev.lumen.hud;

import dev.lumen.core.Config;
import dev.lumen.core.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Базовый перетаскиваемый HUD-элемент. Позиция — доли экрана, плюс масштаб. */
public abstract class HudWidget {
	public final Module module;
	public final float defX, defY;
	public float fx, fy, scale = 1f;
	/** Последние координаты и размер (w, h — без учёта scale). */
	public float px, py, w, h;

	protected HudWidget(Module module, float defX, float defY) {
		this.module = module;
		this.defX = defX;
		this.defY = defY;
		float[] p = Config.POS.get(module.name);
		this.fx = p != null ? p[0] : defX;
		this.fy = p != null ? p[1] : defY;
		if (p != null && p.length > 2) this.scale = Mth.clamp(p[2], 0.5f, 2f);
	}

	public float bw() { return w * scale; }
	public float bh() { return h * scale; }

	/** Считает px/py по последним размерам; вызывается до отрисовки. */
	public final void layout(int sw, int sh) {
		px = Mth.clamp(fx * sw, 0f, Math.max(0f, sw - bw()));
		py = Mth.clamp(fy * sh, 0f, Math.max(0f, sh - bh()));
	}

	public final void draw(GuiGraphics g, float pt, int sw, int sh, float alpha) {
		render(g, px, py, pt, sw, sh, alpha);
	}

	protected abstract void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a);

	public boolean contains(double mx, double my) {
		return w > 0 && mx >= px - 3 && mx <= px + bw() + 3 && my >= py - 3 && my <= py + bh() + 3;
	}

	public void moveTo(float nx, float ny, int sw, int sh) {
		fx = nx / sw;
		fy = ny / sh;
	}

	public void reset() {
		fx = defX;
		fy = defY;
		scale = 1f;
	}
}
