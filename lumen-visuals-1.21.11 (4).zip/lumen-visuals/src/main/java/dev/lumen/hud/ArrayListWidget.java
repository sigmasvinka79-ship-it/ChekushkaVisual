package dev.lumen.hud;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dev.lumen.core.Category;
import dev.lumen.core.Module;
import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import dev.lumen.util.Lang;
import net.minecraft.client.gui.GuiGraphics;

/** Список включённых функций справа: выезжает, плавно перестраивается, цвет перетекает по времени. */
public final class ArrayListWidget extends HudWidget {
	private static final float ROW = 14f;
	private final Map<Module, Float> ys = new HashMap<>();
	private final List<Module> rows = new ArrayList<>();

	public ArrayListWidget() {
		super(Modules.ARRAY, 0.862f, 0.012f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		int maxAll = 0;
		rows.clear();
		for (Module m : Modules.ALL) {
			if (!m.toggleable || m == Modules.ARRAY) continue;
			if (m.category == Category.HUD && !Modules.AL_HUD.bool) continue;
			maxAll = Math.max(maxAll, Draw.width(Lang.t(m.name)));
			if (m.vis > 0.03f) rows.add(m);
		}
		rows.sort((p, q) -> Integer.compare(Draw.width(Lang.t(q.name)), Draw.width(Lang.t(p.name))));

		w = maxAll + 16;
		h = Math.max(ROW, rows.size() * ROW);
		boolean bar = Modules.AL_BAR.bool;
		float time = System.nanoTime() / 1.0e9f;

		for (int i = 0; i < rows.size(); i++) {
			Module m = rows.get(i);
			String name = Lang.t(m.name);
			float ty = i * ROW;
			Float cur = ys.get(m);
			float yy = cur == null ? ty : Anim.approach(cur, ty, 14f);
			ys.put(m, yy);

			float vis = m.enabled ? m.vis : m.vis * m.vis;
			float rw = Draw.width(name) + 12;
			float rx = x + w - rw + (1f - vis) * (rw + 8);
			float al = a * vis;
			float f = 0.5f + 0.5f * (float) Math.sin(time * 1.4f + i * 0.55f);
			int col = Draw.lerp(Theme.accent(), Theme.accent2(), f);

			Draw.rounded(g, rx, y + yy, rw, ROW - 1, 2, Theme.bg(al));
			if (bar) g.fill(Math.round(rx + rw) - 2, Math.round(y + yy) + 1, Math.round(rx + rw), Math.round(y + yy + ROW - 1) - 1, Draw.a(col, al));
			Draw.text(g, name, rx + 5, y + yy + 3, Draw.a(Draw.lerp(Theme.TEXT, col, 0.35f), al));
		}
	}
}
