package dev.lumen.hud;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Draw;
import dev.lumen.util.Stats;
import net.minecraft.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;

public final class WatermarkWidget extends HudWidget {
	private static final String[] LOGO = {"L", "U", "M", "E", "N"};
	private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm");
	private static final float PAD = 8f, SEP = 10f;

	private long stamp;
	private String time = "";
	private int ping;
	private final String[] parts = new String[4];

	public WatermarkWidget() {
		super(Modules.WATERMARK, 0.008f, 0.012f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		long now = Util.getMillis();
		if (now - stamp > 1000) {
			stamp = now;
			time = LocalTime.now().format(FMT);
			var conn = mc.getConnection();
			PlayerInfo info = conn == null ? null : conn.getPlayerInfo(mc.player.getUUID());
			ping = info == null ? 0 : info.getLatency();
		}

		int n = 0;
		parts[n++] = mc.getUser().getName();
		if (Modules.WM_FPS.bool) parts[n++] = Stats.fps + " fps";
		if (Modules.WM_PING.bool) parts[n++] = ping + " ms";
		if (Modules.WM_TIME.bool) parts[n++] = time;

		float total = PAD + Draw.width("LUMEN");
		for (int i = 0; i < n; i++) total += SEP + Draw.width(parts[i]);
		total += PAD;
		w = total;
		h = 17f;

		Draw.panel(g, x, y, w, h, a);

		float cx = x + PAD;
		for (int i = 0; i < LOGO.length; i++) {
			float shimmer = 0.5f + 0.5f * (float) Math.sin(System.nanoTime() / 1.0e9 * 1.6 + i * 0.9);
			int col = Draw.lerp(Theme.accent(), Theme.accent2(), shimmer);
			Draw.text(g, LOGO[i], cx, y + 5, Draw.a(col, a));
			cx += Draw.width(LOGO[i]);
		}
		for (int i = 0; i < n; i++) {
			int lx = Math.round(cx + SEP / 2f);
			g.fill(lx, Math.round(y) + 4, lx + 1, Math.round(y) + 13, Draw.a(0xFFFFFFFF, 0.18f * a));
			Draw.text(g, parts[i], cx + SEP, y + 5, Draw.a(i == 0 ? Theme.TEXT : Theme.MUTED, a));
			cx += SEP + Draw.width(parts[i]);
		}
	}
}
