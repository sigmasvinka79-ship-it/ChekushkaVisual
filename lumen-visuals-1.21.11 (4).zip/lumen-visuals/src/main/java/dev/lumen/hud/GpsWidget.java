package dev.lumen.hud;

import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.feature.Gps;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Стрелка к GPS-метке: показывает направление, координаты и расстояние. */
public final class GpsWidget extends HudWidget {
	private float shown, ang;

	public GpsWidget() {
		super(Modules.GPS, 0.40f, 0.075f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		var p = mc.player;
		boolean demo = !Gps.active && HudRenderer.editing();
		shown = Anim.approach(shown, (Gps.active || demo) ? 1f : 0f, 12f);
		if (shown < 0.02f) {
			w = 0;
			h = 0;
			return;
		}
		float al = a * shown;

		double tx = demo ? p.getX() + 120 : Gps.x;
		double tz = demo ? p.getZ() - 80 : Gps.z;
		double dx = tx - p.getX(), dz = tz - p.getZ();
		double dist = Math.hypot(dx, dz);
		double target = Math.toDegrees(Math.atan2(-dx, dz));
		float rel = Mth.wrapDegrees((float) (target - Mth.lerp(pt, p.yRotO, p.getYRot())));
		float rad = (float) Math.toRadians(rel);
		// плавный поворот по кратчайшему пути
		float diff = Mth.wrapDegrees((float) Math.toDegrees(rad - ang));
		ang += (float) Math.toRadians(diff) * Math.min(1f, Anim.dt * 14f);

		String title = demo ? "Preview" : (Gps.label.isEmpty() ? "GPS" : Gps.label);
		String coords = String.format(Locale.ROOT, "%d  %d", Math.round(tx), Math.round(tz));
		String d = String.format(Locale.ROOT, "%dm", Math.round(dist));

		float tw = Math.max(Math.max(Draw.width(coords), Draw.width(d) * 1.0f), Draw.width(title) * 0.8f);
		w = 40 + tw + 12;
		h = 36;
		Draw.panel(g, x, y, w, h, al);

		float cx = x + 20, cy = y + h / 2f;
		Draw.glow(g, cx, cy, 34, Draw.a(Theme.accent(), al * 0.35f));
		Draw.arrow(g, cx, cy, 16, ang, Draw.a(Theme.accent(), al));

		Draw.text(g, Draw.clip(title, 120), x + 40, y + 5, 0.8f, Draw.a(Theme.MUTED, al), false);
		Draw.text(g, coords, x + 40, y + 14, Draw.a(Theme.TEXT, al));
		Draw.text(g, d, x + 40, y + 24, 0.85f, Draw.a(Draw.lerp(Theme.accent(), Theme.accent2(), 0.5f), al), false);
	}
}
