package dev.lumen.hud;

import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/** Target HUD: голова, ник, анимированная полоса здоровья со «шлейфом» урона. */
public final class TargetWidget extends HudWidget {
	private float shown, hp, trail;
	private LivingEntity last;
	private String name = "";

	private String clipSrc = "", clipOut = "";
	private int clipW = -1;
	private long hpKey = Long.MIN_VALUE, rightKey = Long.MIN_VALUE;
	private String hpText = "", rightText = "";

	public TargetWidget() {
		super(Modules.TARGET, 0.53f, 0.56f);
	}

	private String clip(String s, int maxW) {
		if (maxW != clipW || !s.equals(clipSrc)) {
			clipSrc = s;
			clipW = maxW;
			clipOut = Draw.clip(s, maxW);
		}
		return clipOut;
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		boolean edit = HudRenderer.editing();
		LivingEntity t = TargetTracker.entity;

		boolean active = t != null && t.isAlive()
			&& Util.getMillis() - TargetTracker.lastSeen < (long) (Modules.TG_LINGER.f() * 1000f);
		boolean demo = !active && edit;

		shown = Anim.approach(shown, (active || demo) ? 1f : 0f, 14f);
		if (shown < 0.02f) {
			w = 0;
			h = 0;
			return;
		}
		float al = a * shown;

		if (t != null && t != last) {
			last = t;
			name = t.getDisplayName().getString();
			hp = trail = t.getHealth();
		}

		String nm;
		float rhp, rmax, ab, dist;
		int armor, hurt;
		AbstractClientPlayer skin;
		if (demo) {
			nm = "Steve";
			rhp = 14f;
			rmax = 20f;
			ab = 0f;
			armor = 12;
			dist = 3.2f;
			hurt = 0;
			skin = mc.player;
		} else {
			if (last == null) {
				w = 0;
				h = 0;
				return;
			}
			nm = name;
			rhp = last.getHealth();
			rmax = Math.max(1f, last.getMaxHealth());
			ab = last.getAbsorptionAmount();
			armor = last.getArmorValue();
			dist = mc.player.distanceTo(last);
			hurt = last.hurtTime;
			skin = last instanceof AbstractClientPlayer p ? p : null;
		}

		hp = Anim.approach(hp, rhp, 12f);
		trail = trail < hp ? hp : Anim.approach(trail, hp, 3f);
		float frac = Mth.clamp(hp / rmax, 0f, 1f);
		float tfrac = Mth.clamp(trail / rmax, 0f, 1f);

		long hk = ((long) Math.round(rhp * 10f) << 32) | ((long) Math.round(rmax) << 8) | Math.min(255, (int) ab);
		if (hk != hpKey) {
			hpKey = hk;
			hpText = String.format(Locale.ROOT, "%.1f/%.0f", rhp, rmax) + (ab > 0f ? " +" + (int) ab : "");
		}
		boolean showArmor = Modules.TG_ARMOR.bool && armor > 0;
		boolean showDist = Modules.TG_DIST.bool;
		long rk = ((long) Math.round(dist * 10f) << 16) | ((long) armor << 2) | (showArmor ? 1 : 0) | (showDist ? 2 : 0);
		if (rk != rightKey) {
			rightKey = rk;
			StringBuilder sb = new StringBuilder();
			if (showArmor) sb.append("AR ").append(armor);
			if (showArmor && showDist) sb.append("  ");
			if (showDist) sb.append(String.format(Locale.ROOT, "%.1fm", dist));
			rightText = sb.toString();
		}

		int hpCol = Draw.hp(frac);

		if (Modules.TG_STYLE.mode == 0) {
			w = 150f;
			h = 44f;
			Draw.shadow(g, x, y, w, h, Theme.radius(), al * 0.6f);
			Draw.panel(g, x, y, w, h, al);

			int hx = Math.round(x) + 7, hy = Math.round(y) + 7;
			if (skin != null) {
				if (al > 0.4f) PlayerFaceRenderer.draw(g, skin.getSkin(), hx, hy, 30);
			} else {
				int hue = Math.abs(nm.hashCode()) % 360;
				Draw.rounded(g, hx, hy, 30, 30, 4, Draw.a(0xFF000000 | Mth.hsvToRgb(hue / 360f, 0.45f, 0.65f), al));
				String ch = nm.isEmpty() ? "?" : nm.substring(0, 1).toUpperCase(Locale.ROOT);
				Draw.text(g, ch, hx + 15 - Draw.width(ch) * 1.5f / 2f, hy + 11, 1.5f, Draw.a(0xFFFFFFFF, al), true);
			}
			if (hurt > 0) {
				Draw.rounded(g, hx, hy, 30, 30, 2, Draw.a(0xFFFF2A2A, 0.5f * Mth.clamp(hurt / 10f, 0f, 1f) * al));
			}

			float bx = x + 44, bw = w - 52;
			Draw.text(g, clip(nm, (int) bw), bx, y + 7, Draw.a(Theme.TEXT, al));
			Draw.rounded(g, bx, y + 19, bw, 6, 2, Draw.a(0xFFFFFFFF, 0.10f * al));
			Draw.rounded(g, bx, y + 19, Math.max(2f, bw * tfrac), 6, 2, Draw.a(0xFFFFFFFF, 0.30f * al));
			Draw.rounded(g, bx, y + 19, Math.max(2f, bw * frac), 6, 2, Draw.a(hpCol, al));
			g.fill(Math.round(bx) + 1, Math.round(y) + 19, Math.round(bx + Math.max(2f, bw * frac)) - 1, Math.round(y) + 20, Draw.a(0xFFFFFFFF, 0.25f * al));

			Draw.text(g, hpText, bx, y + 30, 0.75f, Draw.a(Theme.MUTED, al), false);
			Draw.textRight(g, rightText, x + w - 7, y + 30, 0.75f, Draw.a(Theme.MUTED, al));
		} else {
			w = 120f;
			h = 27f;
			Draw.panel(g, x, y, w, h, al);
			Draw.text(g, clip(nm, 70), x + 7, y + 5, Draw.a(Theme.TEXT, al));
			Draw.textRight(g, hpText, x + w - 7, y + 6, 0.75f, Draw.a(Theme.MUTED, al));
			float bw = w - 14;
			Draw.rounded(g, x + 7, y + 17, bw, 4, 1, Draw.a(0xFFFFFFFF, 0.10f * al));
			Draw.rounded(g, x + 7, y + 17, Math.max(2f, bw * tfrac), 4, 1, Draw.a(0xFFFFFFFF, 0.30f * al));
			Draw.rounded(g, x + 7, y + 17, Math.max(2f, bw * frac), 4, 1, Draw.a(hpCol, al));
		}
	}
}
