package dev.lumen.hud;

import java.util.ArrayDeque;
import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.util.Util;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** WASD + мышь + пробел. CPS считается по нажатиям, пока ты играешь. */
public final class KeystrokesWidget extends HudWidget {
	private static final int K = 22, G = 2;

	private final float[] press = new float[7];
	private final ArrayDeque<Long> lc = new ArrayDeque<>(), rc = new ArrayDeque<>();
	private boolean lDown, rDown;

	public KeystrokesWidget() {
		super(Modules.KEYS, 0.008f, 0.45f);
	}

	private static String label(KeyMapping k) {
		String s = k.getTranslatedKeyMessage().getString();
		if (s.length() > 3) s = s.substring(0, 3);
		return s.toUpperCase(Locale.ROOT);
	}

	private void key(GuiGraphics g, int idx, boolean down, float x, float y, float kw, float kh, String label, String sub, float a) {
		press[idx] = Anim.approach(press[idx], down ? 1f : 0f, 22f);
		float t = press[idx];
		int bg = Draw.lerp(Theme.bg(a), Draw.a(Theme.accent(), 0.9f * a), t);
		Draw.rounded(g, x, y, kw, kh, Theme.radius(), bg);
		int tc = Draw.lerp(Theme.TEXT, 0xFF0B0E13, t * 0.85f);
		float ty = sub == null ? y + (kh - 8) / 2f + 0.5f : y + 5;
		Draw.text(g, label, x + (kw - Draw.width(label)) / 2f, ty, Draw.a(tc, a));
		if (sub != null) {
			Draw.text(g, sub, x + (kw - Draw.width(sub) * 0.7f) / 2f, y + 15, 0.7f, Draw.a(Draw.lerp(Theme.MUTED, 0xFF0B0E13, t * 0.8f), a), false);
		}
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		var o = mc.options;
		long now = Util.getMillis();

		boolean l = o.keyAttack.isDown(), r = o.keyUse.isDown();
		if (l && !lDown) lc.addLast(now);
		if (r && !rDown) rc.addLast(now);
		lDown = l;
		rDown = r;
		while (!lc.isEmpty() && now - lc.peekFirst() > 1000) lc.pollFirst();
		while (!rc.isEmpty() && now - rc.peekFirst() > 1000) rc.pollFirst();

		float W = K * 3 + G * 2;
		float cy = 0;
		key(g, 0, o.keyUp.isDown(), x + K + G, y + cy, K, K, label(o.keyUp), null, a);
		cy += K + G;
		key(g, 1, o.keyLeft.isDown(), x, y + cy, K, K, label(o.keyLeft), null, a);
		key(g, 2, o.keyDown.isDown(), x + K + G, y + cy, K, K, label(o.keyDown), null, a);
		key(g, 3, o.keyRight.isDown(), x + (K + G) * 2, y + cy, K, K, label(o.keyRight), null, a);
		cy += K + G;

		if (Modules.KS_MOUSE.bool) {
			boolean cps = Modules.KS_CPS.bool;
			float bh = cps ? 25 : 18;
			float bw = (W - G) / 2f;
			key(g, 4, l, x, y + cy, bw, bh, "LMB", cps ? lc.size() + " CPS" : null, a);
			key(g, 5, r, x + bw + G, y + cy, bw, bh, "RMB", cps ? rc.size() + " CPS" : null, a);
			cy += bh + G;
		}
		if (Modules.KS_SPACE.bool) {
			key(g, 6, o.keyJump.isDown(), x, y + cy, W, 12, "", null, a);
			float p = press[6];
			Draw.rounded(g, x + W / 2f - 9, y + cy + 5, 18, 2, 1, Draw.a(Draw.lerp(Theme.MUTED, 0xFF0B0E13, p), a));
			cy += 12 + G;
		}
		w = W;
		h = cy - G;
	}
}
