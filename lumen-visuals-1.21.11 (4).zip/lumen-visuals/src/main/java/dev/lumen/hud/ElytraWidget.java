package dev.lumen.hud;

import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Элитры: прочность, скорость, высота, фейерверки. Показывается, пока элитра надета. */
public final class ElytraWidget extends HudWidget {
	private ItemStack icon;
	private long lastGt = -1;
	private int rockets;
	private String spd = "", alt = "", rk = "";

	public ElytraWidget() {
		super(Modules.ELYTRA_HUD, 0.68f, 0.80f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		Minecraft mc = Minecraft.getInstance();
		var p = mc.player;
		ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
		boolean wear = chest.is(Items.ELYTRA);
		if (!wear && !HudRenderer.editing()) {
			w = 0;
			h = 0;
			return;
		}
		if (icon == null) icon = new ItemStack(Items.ELYTRA);

		long gt = mc.level.getGameTime();
		if (gt != lastGt) {
			lastGt = gt;
			rockets = 0;
			var inv = p.getInventory();
			for (int i = 0; i < inv.getContainerSize(); i++) {
				ItemStack s = inv.getItem(i);
				if (s.is(Items.FIREWORK_ROCKET)) rockets += s.getCount();
			}
			spd = String.format(Locale.ROOT, "%.1f b/s", p.getDeltaMovement().length() * 20.0);
			alt = Integer.toString(Mth.floor(p.getY()));
			rk = Integer.toString(rockets);
		}

		float frac = 1f;
		if (wear && chest.isDamageableItem()) frac = 1f - (float) chest.getDamageValue() / Math.max(1, chest.getMaxDamage());
		int col = Draw.hp(frac);

		w = 104;
		h = 44;
		Draw.panel(g, x, y, w, h, a);
		if (a > 0.5f) g.renderItem(icon, Math.round(x) + 6, Math.round(y) + 6);
		Draw.bar(g, x + 6, y + 27, 18, 3, frac, col, a);
		Draw.text(g, Math.round(frac * 100f) + "%", x + 4, y + 33, 0.7f, Draw.a(col, a), false);

		Draw.text(g, "SPD", x + 32, y + 6, 0.72f, Draw.a(Theme.MUTED, a), false);
		Draw.text(g, spd, x + 54, y + 5, Draw.a(Theme.TEXT, a));
		Draw.text(g, "ALT", x + 32, y + 18, 0.72f, Draw.a(Theme.MUTED, a), false);
		Draw.text(g, alt, x + 54, y + 17, Draw.a(Theme.TEXT, a));
		Draw.text(g, "RKT", x + 32, y + 30, 0.72f, Draw.a(Theme.MUTED, a), false);
		Draw.text(g, rk, x + 54, y + 29, Draw.a(rockets == 0 ? Theme.BAD : Theme.TEXT, a));
	}
}
