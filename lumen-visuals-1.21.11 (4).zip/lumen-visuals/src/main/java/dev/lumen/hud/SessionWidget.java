package dev.lumen.hud;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.feature.SessionStats;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Util;

/** Время сессии, убийства/смерти и таймер боя (15 секунд после удара или урона). */
public final class SessionWidget extends HudWidget {
	private long lastSec = -1;
	private String time = "0:00";

	public SessionWidget() {
		super(Modules.SESSION, 0.865f, 0.78f);
	}

	private static String two(long v) {
		return v < 10 ? "0" + v : Long.toString(v);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		long sec = (Util.getMillis() - SessionStats.start) / 1000;
		if (sec != lastSec) {
			lastSec = sec;
			time = sec >= 3600 ? (sec / 3600) + ":" + two((sec / 60) % 60) + ":" + two(sec % 60) : (sec / 60) + ":" + two(sec % 60);
		}
		int rows = 1 + (Modules.SE_KD.bool ? 1 : 0) + (Modules.SE_COMBAT.bool ? 1 : 0);
		w = 84;
		h = rows * 12 + 8;
		Draw.panel(g, x, y, w, h, a);

		float cy = y + 5;
		row(g, x, cy, "TIME", time, Theme.TEXT, a);
		cy += 12;
		if (Modules.SE_KD.bool) {
			row(g, x, cy, "K / D", SessionStats.kills + " / " + SessionStats.deaths, Theme.TEXT, a);
			cy += 12;
		}
		if (Modules.SE_COMBAT.bool) {
			int left = SessionStats.combatLeft();
			row(g, x, cy, "COMBAT", left < 0 ? "-" : left + "s", left < 0 ? Theme.MUTED : Theme.BAD, a);
		}
	}

	private static void row(GuiGraphics g, float x, float y, String label, String value, int col, float a) {
		Draw.text(g, label, x + 7, y + 1, 0.72f, Draw.a(Theme.MUTED, a), false);
		Draw.textRight(g, value, x + 84 - 7, y, 1f, Draw.a(col, a));
	}
}
