package dev.lumen.anim;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.lumen.core.Modules;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Анимации взмаха и позы руки в первом лице. Полностью клиентские: меняется только матрица
 * отрисовки предмета в руке. Поза проверяется на видимость: если клинок уходит за экран,
 * сила позы автоматически уменьшается, так что предмет не пропадает из кадра.
 */
public final class SwingAnimations {
	private SwingAnimations() {}

	private interface Ops {
		void t(float x, float y, float z);
		void rx(float d);
		void ry(float d);
		void rz(float d);
	}

	private static final class PoseOps implements Ops {
		private final PoseStack p;

		PoseOps(PoseStack p) { this.p = p; }

		public void t(float x, float y, float z) { p.translate(x, y, z); }
		public void rx(float d) { p.mulPose(Axis.XP.rotationDegrees(d)); }
		public void ry(float d) { p.mulPose(Axis.YP.rotationDegrees(d)); }
		public void rz(float d) { p.mulPose(Axis.ZP.rotationDegrees(d)); }
	}

	private static final class MatOps implements Ops {
		private final Matrix4f m;

		MatOps(Matrix4f m) { this.m = m; }

		public void t(float x, float y, float z) { m.translate(x, y, z); }
		public void rx(float d) { m.rotateX((float) Math.toRadians(d)); }
		public void ry(float d) { m.rotateY((float) Math.toRadians(d)); }
		public void rz(float d) { m.rotateZ((float) Math.toRadians(d)); }
	}

	/** @return true, если ванильное преобразование взмаха нужно отменить. */
	public static boolean apply(PoseStack p, HumanoidArm arm, float swing) {
		if (!Modules.SWING.enabled) return false;
		int mode = Modules.SW_MODE.mode;
		if (mode == 0) return false;
		if (swing <= 0f) return true;

		Ops o = new PoseOps(p);
		float k = Modules.SW_POWER.f();
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		float w = Mth.sin(swing * Mth.PI);
		float s = Mth.sin(Mth.sqrt(swing) * Mth.PI);
		float e = swing * swing * (3f - 2f * swing);

		switch (mode) {
			case 1 -> { // Smooth
				o.ry(side * (45f - 8f * s * k));
				o.rz(side * s * -14f * k);
				o.rx(s * -62f * k);
				o.ry(side * -45f);
			}
			case 2 -> { // Slash
				o.ry(side * 45f);
				o.rz(side * -70f * w * k);
				o.rx(-18f * w * k);
				o.ry(side * (-45f + 38f * w * k));
			}
			case 3 -> { // Slide
				o.t(side * 0.06f * w * k, -0.12f * w * k, -0.65f * w * k);
				o.rx(-12f * w * k);
			}
			case 4 -> { // Block
				o.t(side * -0.12f * w * k, 0.08f * w * k, 0f);
				o.ry(side * 28f * w * k);
				o.rz(side * -22f * w * k);
				o.rx((-52f * w - 26f * s) * k);
			}
			case 5 -> { // Spin
				o.rx(-25f * w * k);
				o.rz(side * 360f * e);
			}
			case 6 -> { // Poke
				o.t(0f, 0.02f * w * k, -0.85f * w * k);
				o.rx(-6f * w * k);
				o.ry(side * 8f * w * k);
			}
			case 7 -> { // Whip
				float u = Mth.sin(swing * swing * Mth.PI);
				o.ry(side * 45f);
				o.rx(-105f * u * k);
				o.rz(side * -24f * u * k);
				o.ry(side * -45f);
			}
			case 8 -> { // Tap
				o.t(0f, -0.14f * w * k, -0.22f * w * k);
				o.rx(-24f * w * k);
			}
			case 9 -> { // Hammer
				float a;
				if (swing < 0.4f) {
					a = -80f * Mth.sin(swing / 0.4f * Mth.HALF_PI);
				} else {
					float r = (swing - 0.4f) / 0.6f;
					a = -80f * (1f - Mth.sin(r * Mth.HALF_PI)) + 22f * Mth.sin(r * Mth.PI);
				}
				o.t(0f, 0.12f * w * k, 0f);
				o.rx(a * k);
			}
			case 10 -> { // Wave: волной из стороны в сторону
				o.rz(side * Mth.sin(swing * Mth.TWO_PI) * 24f * k);
				o.rx(-34f * w * k);
			}
			case 11 -> { // Dash: быстрый рывок по диагонали
				o.t(side * -0.08f * w * k, -0.04f * w * k, -0.5f * w * k);
				o.ry(side * -20f * w * k);
				o.rx(-10f * w * k);
			}
			case 12 -> { // Stab: укол вперёд-вниз
				o.t(0f, 0.08f * w * k, -0.6f * w * k);
				o.rx(-46f * s * k);
			}
			case 13 -> { // Drop: сверху вниз
				o.t(0f, 0.3f * w * (1f - swing) * k, 0f);
				o.rx((-95f * s + 40f * w * w) * k);
			}
			default -> {
				return false;
			}
		}
		return true;
	}

	/** Поза руки одной настройкой. Вызывается после стандартного подъёма предмета, до взмаха. */
	private static void pose(Ops o, int pose, int side, float k) {
		switch (pose) {
			case 1 -> { // Horizontal: клинок поперёк экрана
				o.t(side * -0.14f * k, 0.26f * k, 0f);
				o.rz(side * 80f * k);
				o.ry(side * -10f * k);
			}
			case 2 -> { // Horizontal Up: поперёк и приподнят
				o.t(side * -0.12f * k, 0.30f * k, 0f);
				o.rz(side * 72f * k);
				o.rx(-20f * k);
			}
			case 3 -> { // Vertical
				o.t(0f, 0.06f * k, 0f);
				o.rx(-14f * k);
				o.rz(side * -4f * k);
			}
			case 4 -> { // Low
				o.t(side * 0.04f * k, -0.10f * k, 0.04f * k);
				o.rx(14f * k);
			}
			case 5 -> { // Tilted
				o.t(side * -0.04f * k, 0.08f * k, 0f);
				o.rz(side * -35f * k);
				o.rx(-12f * k);
			}
			case 6 -> { // Block Pose (как блок мечом в 1.8)
				o.t(side * -0.20f * k, 0.22f * k, 0.06f * k);
				o.rx(-38f * k);
				o.ry(side * 28f * k);
				o.rz(side * 28f * k);
			}
			case 7 -> { // Forward: клинок вперёд-вверх
				o.t(0f, 0.10f * k, 0.02f * k);
				o.rx(-48f * k);
			}
			case 8 -> { // Reverse: обратный хват
				o.t(side * -0.06f * k, 0.36f * k, 0f);
				o.rz(side * 140f * k);
			}
			default -> {
			}
		}
	}

	private static boolean visible(Matrix4f m, float tanH, float aspect) {
		Vector3f v = new Vector3f();
		float[] ys = {0.20f, 0.50f};
		for (float y : ys) {
			v.set(0f, y, 0f);
			m.transformPosition(v);
			if (v.z > -0.15f) return false;
			float inv = -1f / v.z;
			if (Math.abs(v.x * inv) > tanH * aspect * 0.9f || Math.abs(v.y * inv) > tanH * 0.88f) return false;
		}
		return true;
	}

	// Кэш «разрешённой силы позы»: считается один раз для покоя, а не каждый кадр,
	// поэтому поза держится ровно и не дёргается во время взмаха (баг «фиксируется не до конца»).
	private static int cPose = -1, cSide;
	private static float cK, cResult;

	private static float poseStrength(int pose, int side, float k) {
		if (pose == cPose && side == cSide && k == cK) return cResult;
		float tanH = (float) Math.tan(Math.toRadians(70.0) / 2.0);
		float asp = 16f / 9f;
		float s = 1f, res = 0f;
		for (int i = 0; i < 12; i++) {
			Matrix4f m = new Matrix4f().translate(side * 0.56f, -0.52f, -0.72f);
			pose(new MatOps(m), pose, side, k * s);
			if (visible(m, tanH, asp)) {
				res = s;
				break;
			}
			s *= 0.8f;
		}
		cPose = pose;
		cSide = side;
		cK = k;
		cResult = res;
		return res;
	}

	public static void applyOffset(PoseStack p, HumanoidArm arm) {
		if (!Modules.SWING.enabled) return;
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		int pose = Modules.SW_POSE.mode;

		if (pose != 0) {
			float k = Modules.SW_POSE_AMT.f();
			float s = poseStrength(pose, side, k);
			if (s > 0f) pose(new PoseOps(p), pose, side, k * s);
		}

		float sc = Modules.SW_SCALE.f();
		if (sc != 1f) p.scale(sc, sc, sc);
	}
}
