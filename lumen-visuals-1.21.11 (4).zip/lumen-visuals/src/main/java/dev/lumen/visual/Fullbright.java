package dev.lumen.visual;

import dev.lumen.core.Modules;
import dev.lumen.util.Opt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

/** Fullbright через настройку яркости (gamma) — как слайдер «Яркость», только выше предела. */
public final class Fullbright {
	private static boolean active;
	private static double saved = 1.0;

	private Fullbright() {}

	public static void tick(Minecraft mc) {
		try {
			if (mc.options == null) return;
			OptionInstance<Double> g = mc.options.gamma();
			if (Modules.FULLBRIGHT.enabled) {
				if (!active) {
					saved = g.get();
					active = true;
				}
				Opt.force(g, 16.0D);
			} else if (active) {
				Opt.force(g, saved);
				active = false;
			}
		} catch (Throwable ignored) {
		}
	}

	public static void restore(Minecraft mc) {
		try {
			if (active) {
				Opt.force(mc.options.gamma(), saved);
				active = false;
			}
		} catch (Throwable ignored) {
		}
	}
}
