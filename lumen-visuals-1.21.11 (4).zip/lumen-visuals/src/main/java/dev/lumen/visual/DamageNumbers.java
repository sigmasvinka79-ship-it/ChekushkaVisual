package dev.lumen.visual;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.hud.TargetTracker;
import dev.lumen.util.Draw;
import dev.lumen.util.Proj;
import net.minecraft.util.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/** Всплывающие цифры урона над целью (считаются по изменению её здоровья). */
public final class DamageNumbers {
	private static final class N {
		double x, y, z;
		String text;
		long born;
		float dx;
	}

	private static final List<N> LIST = new ArrayList<>();
	private static final float[] P = new float[3];
	private static LivingEntity watch;
	private static float lastHp;

	private DamageNumbers() {}

	public static void render(GuiGraphics g) {
		long now = Util.getMillis();
		LivingEntity e = TargetTracker.entity;
		if (e != null) {
			float hp = e.getHealth() + e.getAbsorptionAmount();
			if (e != watch) {
				watch = e;
				lastHp = hp;
			} else {
				float diff = lastHp - hp;
				if (Modules.DAMAGE.enabled && diff >= 0.5f) {
					N n = new N();
					n.x = e.getX();
					n.y = e.getY() + e.getBbHeight() + 0.1;
					n.z = e.getZ();
					n.text = String.format(Locale.ROOT, "-%.1f", diff);
					n.born = now;
					n.dx = (float) (Math.random() - 0.5) * 24f;
					LIST.add(n);
					if (LIST.size() > 12) LIST.remove(0);
				}
				lastHp = hp;
			}
		}
		if (!Modules.DAMAGE.enabled || !Proj.ready) {
			LIST.removeIf(q -> now - q.born > 1000);
			return;
		}
		LIST.removeIf(q -> now - q.born > 1000);
		float sc = Modules.DM_SIZE.f();
		for (N n : LIST) {
			float age = (now - n.born) / 1000f;
			if (!Proj.to(n.x, n.y + age * 0.7, n.z, P)) continue;
			float a = 1f - Mth.clamp((age - 0.45f) / 0.55f, 0f, 1f);
			float pop = age < 0.12f ? 0.6f + (age / 0.12f) * 0.6f : 1.2f - Math.min(0.2f, (age - 0.12f) * 0.5f);
			float s = sc * pop;
			float tw = Draw.width(n.text) * s;
			Draw.text(g, n.text, P[0] - tw / 2f + n.dx * age, P[1] - age * 14f, s, Draw.a(Theme.BAD, a), true);
		}
	}
}
