package dev.lumen.visual;

import java.util.concurrent.ThreadLocalRandom;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.hud.TargetTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;

/** Клиентские частицы (видишь только ты, на сервер ничего не уходит). */
public final class ParticleFx {
	private static long seenHit, seenKill;

	private ParticleFx() {}

	private static ParticleOptions type(int i) {
		return switch (i) {
			case 0 -> ParticleTypes.END_ROD;
			case 1 -> ParticleTypes.SOUL_FIRE_FLAME;
			case 2 -> ParticleTypes.SOUL;
			case 3 -> ParticleTypes.FLAME;
			case 4 -> ParticleTypes.CRIT;
			case 5 -> ParticleTypes.HEART;
			case 6 -> ParticleTypes.ENCHANTED_HIT;
			case 7 -> ParticleTypes.WITCH;
			case 8 -> ParticleTypes.ELECTRIC_SPARK;
			default -> ParticleTypes.SNOWFLAKE;
		};
	}

	public static void tick(Minecraft mc) {
		if (mc.level == null || mc.player == null) return;
		var rnd = ThreadLocalRandom.current();
		var e = TargetTracker.entity;

		if (TargetTracker.lastHit != seenHit) {
			seenHit = TargetTracker.lastHit;
			if (Modules.PARTICLES.enabled && Modules.PA_HIT.bool && e != null) {
				ParticleOptions opt = type(Modules.PA_TYPE.mode);
				int n = Modules.PA_AMOUNT.i();
				for (int i = 0; i < n; i++) {
					double x = e.getX() + (rnd.nextDouble() - 0.5) * e.getBbWidth();
					double y = e.getY() + rnd.nextDouble() * e.getBbHeight();
					double z = e.getZ() + (rnd.nextDouble() - 0.5) * e.getBbWidth();
					mc.level.addParticle(opt, x, y, z,
						(rnd.nextDouble() - 0.5) * 0.35, rnd.nextDouble() * 0.28, (rnd.nextDouble() - 0.5) * 0.35);
				}
			}
		}

		if (TargetTracker.lastKill != seenKill) {
			seenKill = TargetTracker.lastKill;
			if (Modules.PARTICLES.enabled && Modules.PA_KILL.bool && e != null) {
				for (int i = 0; i < 36; i++) {
					double a = rnd.nextDouble() * Math.PI * 2;
					double r = rnd.nextDouble() * 0.5;
					mc.level.addParticle(ParticleTypes.SOUL, e.getX() + Math.cos(a) * r, e.getY() + rnd.nextDouble() * e.getBbHeight(),
						e.getZ() + Math.sin(a) * r, Math.cos(a) * 0.05, 0.05 + rnd.nextDouble() * 0.12, Math.sin(a) * 0.05);
				}
				Atmosphere.flash(Theme.accent());
			}
		}

		var p = mc.player;
		if (Modules.PARTICLES.enabled && Modules.PA_AURA.bool && !mc.options.getCameraType().isFirstPerson()) {
			ParticleOptions opt = type(Modules.PA_AURA_TYPE.mode);
			for (int i = 0; i < 2; i++) {
				double a = rnd.nextDouble() * Math.PI * 2;
				double r = 0.5 + rnd.nextDouble() * 0.5;
				mc.level.addParticle(opt, p.getX() + Math.cos(a) * r, p.getY() + rnd.nextDouble() * p.getBbHeight(),
					p.getZ() + Math.sin(a) * r, 0, 0.02 + rnd.nextDouble() * 0.03, 0);
			}
		}

		if (Modules.PARTICLES.enabled && Modules.PA_TRAIL.bool && p.isFallFlying()) {
			ParticleOptions opt = type(Modules.PA_TRAIL_TYPE.mode);
			for (int i = 0; i < 2; i++) {
				mc.level.addParticle(opt, p.getX() + (rnd.nextDouble() - 0.5) * 0.4, p.getY() + 0.2 + rnd.nextDouble() * 0.4,
					p.getZ() + (rnd.nextDouble() - 0.5) * 0.4, 0, 0, 0);
			}
		}
	}
}
