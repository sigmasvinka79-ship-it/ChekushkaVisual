package dev.lumen.visual;

import java.util.Locale;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.feature.Gps;
import dev.lumen.util.Draw;
import dev.lumen.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Метка GPS в мире: ромб + дистанция. Если метка за спиной/за экраном — прижимается к краю. */
public final class GpsOverlay {
	private static final float[] P = new float[3];

	private GpsOverlay() {}

	public static void render(GuiGraphics g, int sw, int sh) {
		if (!Modules.GPS.enabled || !Modules.GPS_MARKER.bool || !Gps.active || !Proj.ready) return;
		var p = Minecraft.getInstance().player;
		if (p == null) return;

		double ty = p.getEyeY();
		boolean vis = Proj.to(Gps.x, ty, Gps.z, P);
		float x = P[0], y = P[1];
		boolean edge = !vis || x < 12 || x > sw - 12 || y < 12 || y > sh - 12;
		if (edge) {
			// направление на метку относительно центра экрана
			double yaw = Math.toRadians(p.getYRot());
			double dx = Gps.x - p.getX(), dz = Gps.z - p.getZ();
			double target = Math.atan2(-dx, dz);
			float rel = (float) Mth.wrapDegrees(Math.toDegrees(target - yaw));
			double r = Math.toRadians(rel);
			float cx = sw / 2f, cy = sh / 2f;
			x = Mth.clamp(cx + (float) Math.sin(r) * cx * 0.85f, 14, sw - 14);
			y = Mth.clamp(cy - (float) Math.cos(r) * cy * 0.7f, 14, sh - 14);
			if (Math.abs(rel) > 90f) {
				x = rel > 0 ? sw - 14 : 14;
			}
		}

		int col = Theme.accent();
		Draw.glow(g, x, y, 34, Draw.a(col, 0.45f));
		g.fill(Math.round(x) - 3, Math.round(y) - 3, Math.round(x) + 3, Math.round(y) + 3, Draw.a(col, 0.95f));
		g.fill(Math.round(x) - 1, Math.round(y) - 1, Math.round(x) + 1, Math.round(y) + 1, 0xFFFFFFFF);
		String d = String.format(Locale.ROOT, "%dm", Math.round(Gps.distance()));
		Draw.text(g, d, x - Draw.width(d) * 0.85f / 2f, y + 7, 0.85f, Draw.a(Theme.TEXT, 0.95f), true);
	}
}
