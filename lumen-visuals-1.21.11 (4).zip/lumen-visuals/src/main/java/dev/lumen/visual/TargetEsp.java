package dev.lumen.visual;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.feature.Optimization;
import dev.lumen.hud.TargetTracker;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import dev.lumen.util.Proj;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Matrix3x2fStack;

/**
 * Target ESP: эффекты вокруг существа, на которое ты СЕЙЧАС смотришь (ванильный прицел).
 * Цвета — из темы клиента, здоровья или радуга. Рисуется поверх кадра в экранных координатах.
 */
public final class TargetEsp {
	private static final float[] P = new float[3];
	private static float shown;
	private static double ex, ey, ez;
	private static float ew, eh;

	private TargetEsp() {}

	private static void orb(GuiGraphics g, double x, double y, double z, float worldSize, int color, float alpha) {
		if (alpha < 0.02f || !Proj.to(x, y, z, P)) return;
		float px = Math.min(worldSize * Proj.scale(P[2]), 80f);
		if (px < 1.2f) return;
		if (Proj.behind(ex, ez, x, z)) alpha *= 0.55f;
		if (!Optimization.low()) Draw.glow(g, P[0], P[1], px * 2.8f, Draw.a(color, alpha * 0.30f));
		Draw.glow(g, P[0], P[1], px * 1.15f, Draw.a(Draw.lerp(color, 0xFFFFFFFF, 0.55f), alpha));
	}

	public static void render(GuiGraphics g, float pt) {
		LivingEntity e = TargetTracker.entity;
		boolean active = Modules.ESP.enabled && Proj.ready && e != null && e.isAlive()
			&& Util.getMillis() - TargetTracker.lastSeen < (long) (Modules.ESP_HOLD.f() * 1000f);
		shown = Anim.approach(shown, active ? 1f : 0f, 9f);
		if (shown < 0.02f || e == null) return;

		ex = Mth.lerp(pt, e.xo, e.getX());
		ey = Mth.lerp(pt, e.yo, e.getY());
		ez = Mth.lerp(pt, e.zo, e.getZ());
		ew = e.getBbWidth();
		eh = e.getBbHeight();

		float speed = Modules.ESP_SPEED.f();
		float size = Modules.ESP_SIZE.f();
		float t = (Util.getMillis() % 1_000_000L) / 1000f * speed;
		int n = Modules.ESP_COUNT.i();
		int c1 = Theme.accent(), c2 = Theme.accent2();
		switch (Modules.ESP_COLOR.mode) {
			case 1 -> {
				float f = Mth.clamp(e.getHealth() / Math.max(1f, e.getMaxHealth()), 0f, 1f);
				c1 = Draw.hp(f);
				c2 = Draw.lerp(c1, 0xFFFFFFFF, 0.35f);
			}
			case 2 -> {
				float hue = (Util.getMillis() % 6000L) / 6000f;
				c1 = 0xFF000000 | Mth.hsvToRgb(hue, 0.6f, 1f);
				c2 = 0xFF000000 | Mth.hsvToRgb((hue + 0.3f) % 1f, 0.6f, 1f);
			}
			default -> {
			}
		}
		float a = shown;

		switch (Modules.ESP_MODE.mode) {
			case 0 -> ghosts(g, t, n, size, c1, c2, a);
			case 1 -> souls(g, t, n, size, c1, c2, a);
			case 2 -> orbit(g, t, n, size, c1, c2, a);
			case 3 -> ring(g, t, size, c1, c2, a);
			case 4 -> spiral(g, t, size, c1, c2, a);
			case 5 -> marker(g, t, size, c1, c2, a);
			case 6 -> corners(g, size, c1, a);
			case 7 -> halo(g, t, size, c1, c2, a);
			default -> saturn(g, t, size, c1, c2, a);
		}
	}

	private static void ghosts(GuiGraphics g, float t, int n, float size, int c1, int c2, float a) {
		final int trail = Optimization.low() ? 6 : 11;
		for (int i = 0; i < n; i++) {
			int col = Draw.lerp(c1, c2, i / (float) Math.max(1, n - 1));
			for (int k = trail - 1; k >= 0; k--) {
				float tt = t - k * 0.05f;
				float ang = tt * 2.3f + i * Mth.TWO_PI / n;
				float r = ew * 0.5f + 0.5f + 0.12f * Mth.sin(tt * 1.7f + i);
				float y = eh * (0.22f + 0.6f * (0.5f + 0.5f * Mth.sin(tt * 1.35f + i * 2.1f)));
				float f = 1f - k / (float) trail;
				orb(g, ex + Mth.cos(ang) * r, ey + y, ez + Mth.sin(ang) * r,
					0.16f * size * (0.35f + 0.65f * f), col, a * f * f);
			}
		}
	}

	private static void souls(GuiGraphics g, float t, int n, float size, int c1, int c2, float a) {
		int total = n * 4;
		for (int i = 0; i < total; i++) {
			float u = (t * 0.32f + i / (float) total) % 1f;
			float ang = i * 2.4f + u * 3.2f;
			float r = ew * 0.5f + 0.15f + 0.18f * Mth.sin(u * 7f + i);
			float fade = Mth.sin(u * Mth.PI);
			int col = Draw.lerp(c1, c2, (i % 5) / 4f);
			orb(g, ex + Mth.cos(ang) * r, ey + u * eh * 1.25f, ez + Mth.sin(ang) * r,
				0.13f * size * (1.1f - 0.5f * u), col, a * fade);
		}
	}

	private static void orbit(GuiGraphics g, float t, int n, float size, int c1, int c2, float a) {
		int total = Math.max(4, n * 2);
		for (int i = 0; i < total; i++) {
			for (int k = 0; k < 5; k++) {
				float tt = t - k * 0.06f;
				float ang = tt * 2.0f + i * Mth.TWO_PI / total;
				float r = ew * 0.5f + 0.45f;
				float y = eh * (0.55f + 0.08f * Mth.sin(tt * 3f + i));
				float f = 1f - k / 5f;
				orb(g, ex + Mth.cos(ang) * r, ey + y, ez + Mth.sin(ang) * r,
					0.1f * size * f, Draw.lerp(c1, c2, i / (float) total), a * f);
			}
		}
	}

	private static void ring(GuiGraphics g, float t, float size, int c1, int c2, float a) {
		int pts = 28;
		float base = ew * 0.5f + 0.35f;
		for (int i = 0; i < pts; i++) {
			float ang = i * Mth.TWO_PI / pts + t * 0.6f;
			float r = base + 0.08f * Mth.sin(t * 2f + i);
			orb(g, ex + Mth.cos(ang) * r, ey + 0.03, ez + Mth.sin(ang) * r, 0.07f * size, c1, a * 0.9f);
		}
		float k = (t * 0.45f) % 1f;
		float y = k * eh * 1.1f;
		float fade = Mth.sin(k * Mth.PI);
		for (int i = 0; i < pts; i++) {
			float ang = i * Mth.TWO_PI / pts - t;
			orb(g, ex + Mth.cos(ang) * (base - 0.1f), ey + y, ez + Mth.sin(ang) * (base - 0.1f), 0.06f * size, c2, a * fade);
		}
	}

	private static void spiral(GuiGraphics g, float t, float size, int c1, int c2, float a) {
		int pts = 16;
		for (int s = 0; s < 2; s++) {
			for (int i = 0; i < pts; i++) {
				float f = i / (float) (pts - 1);
				float ang = t * 2.8f + f * 8f + s * Mth.PI;
				float r = ew * 0.5f + 0.4f;
				orb(g, ex + Mth.cos(ang) * r, ey + f * eh * 1.05f, ez + Mth.sin(ang) * r,
					0.085f * size, Draw.lerp(c1, c2, f), a * (0.35f + 0.65f * f));
			}
		}
	}

	private static void marker(GuiGraphics g, float t, float size, int c1, int c2, float a) {
		if (!Proj.to(ex, ey + eh + 0.45 + 0.06 * Mth.sin(t * 2f), ez, P)) return;
		float px = Math.min(0.2f * size * Proj.scale(P[2]), 40f);
		if (px < 2f) return;
		Draw.glow(g, P[0], P[1], px * 4f, Draw.a(c1, a * 0.35f));
		Matrix3x2fStack m = g.pose();
		m.pushMatrix();
		m.translate(P[0], P[1]);
		m.scale(Math.max(0.12f, Math.abs(Mth.cos(t * 2.2f))), 1f);
		m.rotate(Mth.PI / 4f);
		int s = Math.max(2, Math.round(px));
		g.fill(-s, -s, s, s, Draw.a(c1, a * 0.9f));
		int in = Math.max(1, s / 2);
		g.fill(-in, -in, in, in, Draw.a(Draw.lerp(c2, 0xFFFFFFFF, 0.6f), a));
		m.popMatrix();
	}

	private static void corners(GuiGraphics g, float size, int c1, float a) {
		float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
		double hw = ew / 2.0;
		for (int i = 0; i < 8; i++) {
			double px = ex + ((i & 1) == 0 ? -hw : hw);
			double py = ey + ((i & 2) == 0 ? 0 : eh);
			double pz = ez + ((i & 4) == 0 ? -hw : hw);
			if (!Proj.to(px, py, pz, P)) return;
			minX = Math.min(minX, P[0]);
			maxX = Math.max(maxX, P[0]);
			minY = Math.min(minY, P[1]);
			maxY = Math.max(maxY, P[1]);
		}
		int x1 = Math.round(minX) - 3, y1 = Math.round(minY) - 3, x2 = Math.round(maxX) + 3, y2 = Math.round(maxY) + 3;
		int len = Math.max(4, Math.round(Math.min(x2 - x1, y2 - y1) * 0.28f * size));
		int col = Draw.a(c1, a);
		int sh = Draw.a(0xFF000000, a * 0.5f);
		for (int pass = 0; pass < 2; pass++) {
			int o = pass == 0 ? 1 : 0;
			int c = pass == 0 ? sh : col;
			g.fill(x1 - o, y1 - o, x1 + len, y1 + 1 + o, c);
			g.fill(x1 - o, y1 - o, x1 + 1 + o, y1 + len, c);
			g.fill(x2 - len, y1 - o, x2 + o, y1 + 1 + o, c);
			g.fill(x2 - 1 - o, y1 - o, x2 + o, y1 + len, c);
			g.fill(x1 - o, y2 - 1 - o, x1 + len, y2 + o, c);
			g.fill(x1 - o, y2 - len, x1 + 1 + o, y2 + o, c);
			g.fill(x2 - len, y2 - 1 - o, x2 + o, y2 + o, c);
			g.fill(x2 - 1 - o, y2 - len, x2 + o, y2 + o, c);
		}
	}

	// ── Halo: светящееся кольцо над головой ──
	private static void halo(GuiGraphics g, float t, float size, int c1, int c2, float a) {
		int pts = 22;
		float y = eh + 0.22f + 0.04f * Mth.sin(t * 2f);
		for (int i = 0; i < pts; i++) {
			float ang = i * Mth.TWO_PI / pts + t * 1.2f;
			float f = 0.5f + 0.5f * Mth.sin(ang * 2f - t * 3f);
			orb(g, ex + Mth.cos(ang) * 0.34f, ey + y, ez + Mth.sin(ang) * 0.34f,
				0.07f * size, Draw.lerp(c1, c2, f), a * (0.55f + 0.45f * f));
		}
	}

	// ── Saturn: наклонное кольцо на уровне груди + шарик на орбите ──
	private static void saturn(GuiGraphics g, float t, float size, int c1, int c2, float a) {
		int pts = 30;
		float tilt = 0.45f;
		float r = ew * 0.5f + 0.75f;
		float y0 = eh * 0.55f;
		for (int i = 0; i < pts; i++) {
			float ang = i * Mth.TWO_PI / pts + t * 0.7f;
			orb(g, ex + Mth.cos(ang) * r, ey + y0 + Mth.sin(ang) * r * Mth.sin(tilt), ez + Mth.sin(ang) * r * Mth.cos(tilt),
				0.06f * size, Draw.lerp(c1, c2, i / (float) pts), a * 0.85f);
		}
		float ang = t * 2.4f;
		orb(g, ex + Mth.cos(ang) * r, ey + y0 + Mth.sin(ang) * r * Mth.sin(tilt), ez + Mth.sin(ang) * r * Mth.cos(tilt),
			0.17f * size, c2, a);
	}
}
