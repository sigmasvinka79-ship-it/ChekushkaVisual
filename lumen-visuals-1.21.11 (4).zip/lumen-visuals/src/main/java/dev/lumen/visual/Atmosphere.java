package dev.lumen.visual;

import dev.lumen.core.Modules;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

/** Депрессивная атмосфера: фиолетовая вуаль, виньетка, красная пульсация при низком HP, вспышки. */
public final class Atmosphere {
	private static final int[][] PRESETS = {
		{0x2B1050, 0x08001A},
		{0x0B1F4A, 0x00040F},
		{0x4A0B18, 0x120004},
		{0x26262E, 0x050507}
	};
	private static float shown, flash;
	private static int flashColor = 0xFFFFFFFF;

	private Atmosphere() {}

	public static void flash(int color) {
		flash = 1f;
		flashColor = color;
	}

	public static void render(GuiGraphics g, DeltaTracker dt) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) return;
		int w = g.guiWidth(), h = g.guiHeight();
		float time = (Util.getMillis() % 100000L) / 1000f;

		shown += ((Modules.ATMOSPHERE.enabled ? 1f : 0f) - shown) * 0.08f;
		if (shown >= 0.01f) {
			float pulse = Modules.AT_PULSE.bool ? 0.88f + 0.12f * Mth.sin(time * 0.9f) : 1f;
			int[] pr = PRESETS[Modules.AT_PRESET.mode];
			float tint = Modules.AT_TINT.f() * shown * pulse;
			if (tint > 0.004f) g.fill(0, 0, w, h, Draw.a(0xFF000000 | pr[0], tint));
			float vig = Modules.AT_VIGN.f() * shown * pulse;
			if (vig > 0.01f) Draw.vignette(g, w, h, Draw.a(0xFF000000 | pr[1], vig));
		}

		if (Modules.AT_LOWHP.bool && mc.player.isAlive()) {
			float hp = mc.player.getHealth();
			if (hp <= 6f) {
				float k = Mth.clamp((7f - hp) / 6f, 0f, 1f);
				float pulse = 0.5f + 0.5f * Mth.sin(time * (4f + 4f * k));
				Draw.vignette(g, w, h, Draw.a(0xFFB00018, 0.30f * k + 0.25f * k * pulse));
			}
		}

		if (flash > 0.01f) {
			Draw.vignette(g, w, h, Draw.a(0xFF000000 | (flashColor & 0xFFFFFF), flash * 0.55f));
			flash = Math.max(0f, flash - Anim.dt * 2.2f);
		}
	}
}
