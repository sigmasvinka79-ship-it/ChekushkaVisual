package dev.lumen.visual;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import dev.lumen.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import org.joml.Matrix3x2fStack;

/**
 * Косметика (видишь только ты, от третьего лица): плащ, нимб, рога, питомец.
 * Рисуется поверх кадра по экранным координатам, без правок моделей игры.
 */
public final class Cosmetics {
	private static final float[] P = new float[3];
	private static final float[][] Q = new float[4][2];
	private static final int[][] CAPES = {
		{0, 0},
		{0xFFC81E3A, 0xFF4A0814},
		{0xFF9B6BFF, 0xFF2A1060},
		{0xFF22336B, 0xFF05080F},
		{0xFF7C3AED, 0xFF0B0B2E},
		{0, 0}
	};
	private static final String[][] SPRITES = {
		null,
		{"..aaaa..", ".aaaaaa.", "aaeaaeaa", "aaaaaaaa", "aaaaaaaa", "aaaaaaaa", "aa.aa.aa", "a..a..a."},
		{"........", "..bbbb..", ".baaaab.", "baeaaeab", "baaaaaab", "baaaaaab", ".bbbbbb.", "........"},
		{"b......b", "bb....bb", "bbb..bbb", "bbbrrbbb", ".bbaabb.", "..baab..", "...aa...", "........"},
		{"...b....", "..bab...", "..baab..", ".baaaab.", ".baooab.", "baooooab", "baooooab", ".bbbbbb."}
	};
	private static final String[] BAT_DOWN = {"........", "........", ".bb..bb.", "bbbrrbbb", "bbbaabbb", ".bbaabb.", "..baab..", "...aa..."};

	private static double petX, petY, petZ;
	private static boolean petInit;

	private Cosmetics() {}

	private static void orb(GuiGraphics g, double x, double y, double z, float worldSize, int color, float alpha) {
		if (alpha < 0.02f || !Proj.to(x, y, z, P)) return;
		float px = Math.min(worldSize * Proj.scale(P[2]), 60f);
		if (px < 1f) return;
		Draw.glow(g, P[0], P[1], px * 2.6f, Draw.a(color, alpha * 0.30f));
		Draw.glow(g, P[0], P[1], px * 1.1f, Draw.a(Draw.lerp(color, 0xFFFFFFFF, 0.5f), alpha));
	}

	public static void render(GuiGraphics g, float pt, int sw, int sh) {
		Minecraft mc = Minecraft.getInstance();
		var p = mc.player;
		if (p == null || !Modules.COSMETICS.enabled || !Proj.ready) return;
		boolean first = mc.options.getCameraType().isFirstPerson();
		if (first && !Modules.CO_FIRST.bool) return;

		double x = Mth.lerp(pt, p.xo, p.getX());
		double y = Mth.lerp(pt, p.yo, p.getY());
		double z = Mth.lerp(pt, p.zo, p.getZ());
		double bodyYaw = Math.toRadians(Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot));
		double headYaw = Math.toRadians(Mth.rotLerp(pt, p.yHeadRotO, p.yHeadRot));
		float t = (Util.getMillis() % 1_000_000L) / 1000f;
		float sc = Modules.CO_SCALE.f();
		boolean sneak = p.isCrouching();
		float eye = sneak ? 1.27f : p.getEyeHeight();

		int cape = Modules.CO_CAPE.mode;
		if (cape > 0 && !first) cape(g, p, x, y, z, bodyYaw, t, cape, sneak);
		if (Modules.CO_HALO.bool) halo(g, x, y + eye + 0.38 * sc, z, t, sc);
		int horns = Modules.CO_HORNS.mode;
		if (horns > 0) horns(g, x, y + eye, z, headYaw, horns, sc);
		int pet = Modules.CO_PET.mode;
		if (pet > 0) pet(g, x, y, z, t, pet, sc);
	}

	// ───────────────────────── плащ ─────────────────────────

	private static void cape(GuiGraphics g, net.minecraft.client.player.LocalPlayer p, double x, double y, double z,
		double yaw, float t, int style, boolean sneak) {
		double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // вперёд
		double rx = -Math.cos(yaw), rz = -Math.sin(yaw);  // вправо
		double dx = p.getX() - p.xo, dz = p.getZ() - p.zo;
		double fwd = dx * fx + dz * fz, lat = dx * rx + dz * rz;
		float sway = (float) Mth.clamp(fwd * 5.0, 0.0, 0.55) + 0.06f + 0.03f * Mth.sin(t * 2.2f);
		float side = (float) Mth.clamp(lat * 4.0, -0.25, 0.25);
		float wave = 0.025f * Mth.sin(t * 5f) * (float) Math.min(1.0, Math.abs(fwd) * 10 + 0.2);

		double topY = y + (sneak ? 1.18 : 1.43);
		double midY = y + (sneak ? 0.82 : 0.98);
		double botY = y + (sneak ? 0.42 : 0.52);
		double back0 = 0.15, back1 = 0.15 + sway * 0.45 + wave, back2 = 0.15 + sway;

		// две секции: верх и низ (даёт изгиб)
		double[][] rows = {
			{topY, back0, 0.0, 0.31},
			{midY, back1, -side * 0.5, 0.32},
			{botY, back2, -side, 0.34}
		};
		float[][] pts = new float[6][2];
		boolean ok = true;
		for (int i = 0; i < 3 && ok; i++) {
			double bx = x - fx * rows[i][1] + rx * rows[i][2];
			double bz = z - fz * rows[i][1] + rz * rows[i][2];
			double half = rows[i][3];
			if (!Proj.to(bx - rx * half, rows[i][0], bz - rz * half, P)) { ok = false; break; }
			pts[i * 2][0] = P[0];
			pts[i * 2][1] = P[1];
			if (!Proj.to(bx + rx * half, rows[i][0], bz + rz * half, P)) { ok = false; break; }
			pts[i * 2 + 1][0] = P[0];
			pts[i * 2 + 1][1] = P[1];
		}
		if (!ok) return;

		float top = Math.min(pts[0][1], pts[1][1]), bot = Math.max(pts[4][1], pts[5][1]);
		int[] cols = CAPES[style];
		for (int seg = 0; seg < 2; seg++) {
			Q[0] = pts[seg * 2];
			Q[1] = pts[seg * 2 + 1];
			Q[2] = pts[seg * 2 + 3];
			Q[3] = pts[seg * 2 + 2];
			fillQuad(g, Q, top, bot, cols, style, t);
		}

		if (style == 4) {
			// звёзды на галактическом плаще
			for (int i = 0; i < 9; i++) {
				float u = frac(Mth.sin(i * 12.9898f) * 43758.547f), v = frac(Mth.sin(i * 78.233f) * 12345.678f);
				float tw = 0.4f + 0.6f * (0.5f + 0.5f * Mth.sin(t * 2f + i));
				float lx = Mth.lerp(u, Mth.lerp(v, pts[0][0], pts[4][0]), Mth.lerp(v, pts[1][0], pts[5][0]));
				float ly = Mth.lerp(v, (pts[0][1] + pts[1][1]) / 2f, (pts[4][1] + pts[5][1]) / 2f);
				Draw.glow(g, lx, ly, 7f, Draw.a(0xFFFFFFFF, tw * 0.9f));
			}
		}
	}

	private static float frac(float v) {
		return v - (float) Math.floor(v);
	}

	/** Заливка выпуклого четырёхугольника горизонтальными полосами с вертикальным градиентом. */
	private static void fillQuad(GuiGraphics g, float[][] q, float gTop, float gBot, int[] cols, int style, float t) {
		float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
		for (float[] v : q) {
			minY = Math.min(minY, v[1]);
			maxY = Math.max(maxY, v[1]);
		}
		int y0 = Math.max(0, (int) Math.floor(minY)), y1 = Math.min(g.guiHeight(), (int) Math.ceil(maxY));
		if (y1 - y0 > 600) return;
		float span = Math.max(1f, gBot - gTop);
		for (int yy = y0; yy < y1; yy++) {
			float yc = yy + 0.5f, xmin = Float.MAX_VALUE, xmax = -Float.MAX_VALUE;
			for (int i = 0; i < 4; i++) {
				float[] a = q[i], b = q[(i + 1) % 4];
				float lo = Math.min(a[1], b[1]), hi = Math.max(a[1], b[1]);
				if (yc >= lo && yc < hi) {
					float xx = a[0] + (yc - a[1]) / (b[1] - a[1]) * (b[0] - a[0]);
					xmin = Math.min(xmin, xx);
					xmax = Math.max(xmax, xx);
				}
			}
			if (xmax - xmin < 1f) continue;
			float u = Mth.clamp((yc - gTop) / span, 0f, 1f);
			int col = style == 5
				? 0xFF000000 | Mth.hsvToRgb(((t * 0.15f + u * 0.5f) % 1f), 0.65f, 0.95f)
				: Draw.lerp(cols[0], cols[1], u);
			int ix1 = Math.round(xmin), ix2 = Math.round(xmax);
			g.fill(ix1, yy, ix2, yy + 1, 0xFF000000 | (col & 0xFFFFFF));
			g.fill(ix1, yy, ix1 + 1, yy + 1, Draw.a(0xFFFFFFFF, 0.28f));
			g.fill(ix2 - 1, yy, ix2, yy + 1, Draw.a(0xFF000000, 0.35f));
		}
	}

	// ───────────────────────── нимб ─────────────────────────

	private static void halo(GuiGraphics g, double x, double y, double z, float t, float sc) {
		int pts = 22;
		int c1 = Theme.accent(), c2 = Theme.accent2();
		double yy = y + 0.03 * Mth.sin(t * 2f);
		for (int i = 0; i < pts; i++) {
			float ang = i * Mth.TWO_PI / pts + t * 1.1f;
			float f = 0.5f + 0.5f * Mth.sin(ang * 2f - t * 3f);
			orb(g, x + Mth.cos(ang) * 0.27 * sc, yy, z + Mth.sin(ang) * 0.27 * sc, 0.06f * sc,
				Draw.lerp(c1, c2, f), 0.55f + 0.45f * f);
		}
	}

	// ───────────────────────── рога ─────────────────────────

	private static void horns(GuiGraphics g, double x, double y, double z, double headYaw, int style, float sc) {
		double fx = -Math.sin(headYaw), fz = Math.cos(headYaw);
		double rx = -Math.cos(headYaw), rz = -Math.sin(headYaw);
		int baseCol = style == 2 ? 0xFFE0243A : Theme.accent();
		int tipCol = style == 2 ? 0xFF5A0A14 : Theme.accent2();
		for (int s = -1; s <= 1; s += 2) {
			for (int i = 0; i <= 9; i++) {
				float u = i / 9f;
				double lateral = s * (0.17 + 0.14 * Math.sin(u * Math.PI * 0.5)) * sc;
				double up = (0.18 + 0.44 * u) * sc;
				double lean = (0.02 - 0.07 * u) * sc;
				orb(g, x + rx * lateral + fx * lean, y + up, z + rz * lateral + fz * lean,
					(0.085f - 0.055f * u) * sc, Draw.lerp(baseCol, tipCol, u), 0.95f);
			}
		}
	}

	// ───────────────────────── питомец ─────────────────────────

	private static void pet(GuiGraphics g, double x, double y, double z, float t, int kind, float sc) {
		double a = t * 0.9;
		double tx = x + Math.cos(a) * 1.15, ty = y + 1.55 + 0.14 * Math.sin(t * 2.4), tz = z + Math.sin(a) * 1.15;
		if (!petInit) {
			petX = tx;
			petY = ty;
			petZ = tz;
			petInit = true;
		}
		double k = 1.0 - Math.exp(-6.0 * Anim.dt);
		petX += (tx - petX) * k;
		petY += (ty - petY) * k;
		petZ += (tz - petZ) * k;

		if (kind == 5) {
			int c1 = Theme.accent(), c2 = Theme.accent2();
			for (int i = 6; i >= 0; i--) {
				float tt = t - i * 0.045f;
				double ax = x + Math.cos(tt * 0.9) * 1.15, ay = y + 1.55 + 0.14 * Math.sin(tt * 2.4), az = z + Math.sin(tt * 0.9) * 1.15;
				double px = i == 0 ? petX : ax + (petX - tx), py = i == 0 ? petY : ay + (petY - ty), pz = i == 0 ? petZ : az + (petZ - tz);
				float f = 1f - i / 7f;
				orb(g, px, py, pz, 0.2f * sc * (0.4f + 0.6f * f), Draw.lerp(c1, c2, i / 6f), f);
			}
			return;
		}

		if (!Proj.to(petX, petY, petZ, P)) return;
		float px = 0.5f * sc * Proj.scale(P[2]);
		if (px < 4f) return;
		float s = Math.min(px, 120f) / 8f;
		String[] rows = kind == 3 ? (((int) (t * 4f)) % 2 == 0 ? SPRITES[3] : BAT_DOWN) : SPRITES[kind];
		int a1, b1, e1 = 0xFF1A1A2E, o1 = 0xFFFFD84D, r1 = 0xFFFF4466;
		switch (kind) {
			case 1 -> { a1 = 0xFFEDEDF7; b1 = 0xFFB5B5D0; }
			case 2 -> { a1 = 0xFF6FD66F; b1 = 0xFF2F8F3A; }
			case 3 -> { a1 = 0xFF3B2A5E; b1 = 0xFF1A1030; }
			default -> { a1 = 0xFFFF7A1A; b1 = 0xFFC2410C; }
		}
		Draw.glow(g, P[0], P[1], px * 2.2f, Draw.a(a1, 0.22f));
		Matrix3x2fStack m = g.pose();
		m.pushMatrix();
		m.translate(P[0], P[1] + 1.5f * Mth.sin(t * 3f) * s * 0.3f);
		m.scale(s, s);
		boolean blink = ((int) (t * 1.5f)) % 7 == 0 && (t * 1.5f) % 1f < 0.12f;
		for (int ry = 0; ry < 8; ry++) {
			for (int rx = 0; rx < 8; rx++) {
				char c = rows[ry].charAt(rx);
				if (c == '.') continue;
				int col = switch (c) {
					case 'a' -> a1;
					case 'b' -> b1;
					case 'e' -> blink ? a1 : e1;
					case 'o' -> o1;
					case 'r' -> r1;
					default -> a1;
				};
				g.fill(rx - 4, ry - 4, rx - 3, ry - 3, col);
			}
		}
		m.popMatrix();
	}
}
