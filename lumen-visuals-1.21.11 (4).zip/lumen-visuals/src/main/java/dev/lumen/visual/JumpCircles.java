package dev.lumen.visual;

import java.util.ArrayList;
import java.util.List;

import dev.lumen.core.Modules;
import dev.lumen.core.Theme;
import dev.lumen.util.Draw;
import dev.lumen.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

/** Кольца, расходящиеся от места прыжка. */
public final class JumpCircles {
	private static final class R {
		double x, y, z;
		long born;
	}

	private static final List<R> LIST = new ArrayList<>();
	private static final float[] P = new float[3];
	private static boolean wasGround = true;

	private JumpCircles() {}

	public static void tick(Minecraft mc) {
		var p = mc.player;
		if (p == null) return;
		boolean ground = p.onGround();
		if (wasGround && !ground && p.getDeltaMovement().y > 0.2 && Modules.JUMP.enabled) {
			R r = new R();
			r.x = p.getX();
			r.y = p.getY() + 0.02;
			r.z = p.getZ();
			r.born = Util.getMillis();
			LIST.add(r);
			if (LIST.size() > 6) LIST.remove(0);
		}
		wasGround = ground;
	}

	public static void render(GuiGraphics g) {
		long now = Util.getMillis();
		LIST.removeIf(r -> now - r.born > 1000);
		if (!Modules.JUMP.enabled || !Proj.ready) return;
		float size = Modules.JC_SIZE.f();
		int c1 = Theme.accent(), c2 = Theme.accent2();
		for (R r : LIST) {
			float age = (now - r.born) / 1000f;
			float rad = (0.25f + age * 2.6f) * size;
			float al = 1f - age;
			int pts = 26;
			for (int i = 0; i < pts; i++) {
				float ang = i * Mth.TWO_PI / pts + age * 2f;
				if (!Proj.to(r.x + Mth.cos(ang) * rad, r.y, r.z + Mth.sin(ang) * rad, P)) continue;
				float px = Math.min(0.07f * Proj.scale(P[2]) * (1.2f - age * 0.6f), 40f);
				if (px < 1.2f) continue;
				int col = Draw.lerp(c1, c2, i / (float) pts);
				Draw.glow(g, P[0], P[1], px * 2.6f, Draw.a(col, al * 0.3f));
				Draw.glow(g, P[0], P[1], px * 1.1f, Draw.a(Draw.lerp(col, 0xFFFFFFFF, 0.5f), al * 0.9f));
			}
		}
	}
}
