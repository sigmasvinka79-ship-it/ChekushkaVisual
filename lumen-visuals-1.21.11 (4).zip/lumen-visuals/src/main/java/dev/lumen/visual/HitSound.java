package dev.lumen.visual;

import dev.lumen.core.Modules;
import dev.lumen.hud.TargetTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

public final class HitSound {
	private static long seen;

	private HitSound() {}

	public static void tick(Minecraft mc) {
		if (TargetTracker.lastHit == seen) return;
		seen = TargetTracker.lastHit;
		if (!Modules.HITSOUND.enabled || mc.level == null) return;
		SoundEvent s = switch (Modules.HS_SOUND.mode) {
			case 0 -> SoundEvents.EXPERIENCE_ORB_PICKUP;
			case 1 -> SoundEvents.AMETHYST_BLOCK_CHIME;
			default -> SoundEvents.ARROW_HIT_PLAYER;
		};
		mc.getSoundManager().play(SimpleSoundInstance.forUI(s, Modules.HS_PITCH.f(), Modules.HS_VOL.f()));
	}
}
