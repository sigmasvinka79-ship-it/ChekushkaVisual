package dev.lumen.visual;

import dev.lumen.core.Modules;
import dev.lumen.util.Opt;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

/**
 * Плавный зум (как в Zoomify): держишь клавишу, колесо меняет кратность, чувствительность
 * мыши снижается. FOV обновляется каждый кадр. Клавиша: C или .bind add zoom <клавиша>.
 */
public final class Zoom {
	public static KeyMapping KEY;
	private static boolean zoomed;
	private static int baseFov = 70;
	private static double baseSens = 0.5;
	private static float factor = 4f, curFov = 70f;
	private static long lastFrame;

	private Zoom() {}

	private static boolean want(Minecraft mc) {
		return Modules.ZOOM.enabled && mc.screen == null && KEY != null && KEY.isDown();
	}

	/** Колесо мыши. true — событие съедено (хотбар не переключается). */
	public static boolean onScroll(double dy) {
		var mc = Minecraft.getInstance();
		if (!Modules.ZOOM_SCROLL.bool || !want(mc)) return false;
		factor = Mth.clamp(factor * (float) Math.pow(1.18, dy), 1.3f, 16f);
		return true;
	}

	/** Каждый кадр (вызывается из отрисовки HUD). */
	public static void frame(Minecraft mc, float dt) {
		lastFrame = System.nanoTime();
		update(mc, dt);
	}

	/** Запасной вариант, если HUD скрыт (F1). */
	public static void tick(Minecraft mc) {
		if (System.nanoTime() - lastFrame > 150_000_000L) update(mc, 0.05f);
	}

	private static void update(Minecraft mc, float dt) {
		if (mc.options == null) return;
		var fovOpt = mc.options.fov();
		boolean want = want(mc);
		if (want && !zoomed) {
			zoomed = true;
			baseFov = fovOpt.get();
			baseSens = mc.options.sensitivity().get();
			factor = Modules.ZOOM_FACTOR.f();
			curFov = baseFov;
		}
		if (!zoomed) return;

		float target = want ? baseFov / factor : baseFov;
		float k = Modules.ZOOM_SMOOTH.f();
		curFov += (target - curFov) * (1f - (float) Math.exp(-k * dt));
		int fov = Math.max(2, Math.round(curFov));
		Opt.force(fovOpt, Integer.valueOf(fov));
		if (Modules.ZOOM_SENS.bool) {
			Opt.force(mc.options.sensitivity(), Double.valueOf(baseSens * Math.max(0.2, fov / (double) baseFov)));
		}
		if (!want && Math.abs(curFov - baseFov) < 0.7f) {
			Opt.force(fovOpt, Integer.valueOf(baseFov));
			Opt.force(mc.options.sensitivity(), Double.valueOf(baseSens));
			zoomed = false;
		}
	}

	public static void restore(Minecraft mc) {
		if (!zoomed || mc.options == null) return;
		Opt.force(mc.options.fov(), Integer.valueOf(baseFov));
		Opt.force(mc.options.sensitivity(), Double.valueOf(baseSens));
		zoomed = false;
	}
}
