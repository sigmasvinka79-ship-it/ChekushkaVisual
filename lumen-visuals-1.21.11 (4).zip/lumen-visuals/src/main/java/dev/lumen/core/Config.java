package dev.lumen.core;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import dev.lumen.feature.Waypoints;
import dev.lumen.hud.HudRenderer;
import dev.lumen.hud.HudWidget;
import dev.lumen.util.Fonts;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Config {
	private static final Logger LOG = LoggerFactory.getLogger("lumen");
	public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	/** Позиции HUD-элементов (доли экрана). */
	public static final Map<String, float[]> POS = new HashMap<>();
	/** Версия раскладки HUD: старые позиции (до редактора) игнорируются. */
	public static final int LAYOUT = 2;

	private Config() {}

	public static Path dir() {
		return FabricLoader.getInstance().getConfigDir().resolve("lumen");
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("lumen.json");
	}

	public static JsonObject toJson() {
		JsonObject root = new JsonObject();
		JsonObject mods = new JsonObject();
		for (Module m : Modules.ALL) {
			JsonObject o = new JsonObject();
			o.addProperty("enabled", m.enabled);
			JsonObject so = new JsonObject();
			for (Setting s : m.settings) {
				switch (s.type) {
					case BOOL -> so.addProperty(s.id, s.bool);
					case NUM -> so.addProperty(s.id, s.num);
					case MODE -> so.addProperty(s.id, s.mode);
				}
			}
			o.add("settings", so);
			mods.add(m.name, o);
		}
		root.add("modules", mods);

		JsonObject po = new JsonObject();
		for (HudWidget w : HudRenderer.widgets()) {
			JsonArray a = new JsonArray();
			a.add(w.fx);
			a.add(w.fy);
			a.add(w.scale);
			po.add(w.module.name, a);
		}
		root.add("pos", po);
		root.addProperty("layout", LAYOUT);
		root.add("waypoints", Waypoints.toJson());
		return root;
	}

	public static void fromJson(JsonObject root) {
		JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
		for (Module m : Modules.ALL) {
			if (!mods.has(m.name)) continue;
			JsonObject o = mods.getAsJsonObject(m.name);
			if (o.has("enabled") && m.toggleable) {
				m.enabled = o.get("enabled").getAsBoolean();
				m.guiToggle = m.enabled ? 1f : 0f;
			}
			if (!o.has("settings")) continue;
			JsonObject so = o.getAsJsonObject("settings");
			for (Setting s : m.settings) {
				if (!so.has(s.id)) continue;
				switch (s.type) {
					case BOOL -> { s.bool = so.get(s.id).getAsBoolean(); s.anim = s.bool ? 1f : 0f; }
					case NUM -> s.setNum(so.get(s.id).getAsDouble());
					case MODE -> s.setMode(so.get(s.id).getAsInt());
				}
			}
		}
		int layout = root.has("layout") ? root.get("layout").getAsInt() : 0;
		if (root.has("pos") && layout >= LAYOUT) {
			JsonObject po = root.getAsJsonObject("pos");
			for (String k : po.keySet()) {
				JsonArray a = po.getAsJsonArray(k);
				POS.put(k, new float[] {a.get(0).getAsFloat(), a.get(1).getAsFloat(), a.size() > 2 ? a.get(2).getAsFloat() : 1f});
			}
			for (HudWidget w : HudRenderer.widgets()) {
				float[] p = POS.get(w.module.name);
				if (p != null) {
					w.fx = p[0];
					w.fy = p[1];
					w.scale = p.length > 2 ? p[2] : 1f;
				}
			}
		}
		if (root.has("waypoints")) Waypoints.fromJson(root.getAsJsonArray("waypoints"));
		Fonts.reset();
	}

	public static void load() {
		Path f = file();
		if (!Files.exists(f)) return;
		try (Reader r = Files.newBufferedReader(f)) {
			fromJson(JsonParser.parseReader(r).getAsJsonObject());
		} catch (Exception e) {
			LOG.warn("Could not read lumen.json, using defaults", e);
		}
	}

	public static void save() {
		try (Writer wr = Files.newBufferedWriter(file())) {
			GSON.toJson(toJson(), wr);
		} catch (Exception e) {
			LOG.warn("Could not save lumen.json", e);
		}
	}
}
