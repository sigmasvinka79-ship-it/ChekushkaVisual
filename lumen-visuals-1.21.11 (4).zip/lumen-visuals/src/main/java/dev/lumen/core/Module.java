package dev.lumen.core;

import java.util.ArrayList;
import java.util.List;

import dev.lumen.hud.Notifications;
import net.minecraft.client.KeyMapping;

public final class Module {
	public final String name, desc;
	public final Category category;
	public final boolean toggleable;
	public boolean enabled;
	public final List<Setting> settings = new ArrayList<>();

	/** Анимации: 0..1 */
	public float vis, guiToggle, guiExpand;
	public boolean expanded;
	/** Клавиша переключения (назначается в Управлении). */
	public KeyMapping key;

	public Module(String name, String desc, Category category, boolean enabled, boolean toggleable) {
		this.name = name;
		this.desc = desc;
		this.category = category;
		this.enabled = enabled;
		this.toggleable = toggleable;
		this.guiToggle = enabled ? 1f : 0f;
	}

	public Setting add(Setting s) {
		settings.add(s);
		return s;
	}

	public void toggle() {
		if (!toggleable) return;
		enabled = !enabled;
		Notifications.push(name, enabled);
	}
}
