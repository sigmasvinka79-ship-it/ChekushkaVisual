package dev.lumen.core;

/** Названия типов частиц для настроек (сами частицы — в dev.lumen.visual.ParticleFx). */
public final class ParticleNames {
	public static final String[] NAMES = {"End Rod", "Soul Fire", "Soul", "Flame", "Crit", "Hearts", "Magic Hit", "Witch", "Sparks", "Snow"};

	private ParticleNames() {}
}
