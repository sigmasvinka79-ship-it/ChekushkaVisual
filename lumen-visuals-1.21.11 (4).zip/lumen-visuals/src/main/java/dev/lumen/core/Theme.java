package dev.lumen.core;

import net.minecraft.util.Mth;

public final class Theme {
	public static final String[] NAMES = {"Black", "Violet", "Ocean", "Sunset", "Lime", "Ember", "Rose"};
	/** {accent, accent2, база панели RGB}. */
	private static final int[][] PRESETS = {
		{0xFFEDEDF5, 0xFF9E98BC, 0x07080B},
		{0xFFA78BFA, 0xFFE879F9, 0x0D0818},
		{0xFF22D3EE, 0xFF3B82F6, 0x060B14},
		{0xFFFB7185, 0xFFFB923C, 0x120709},
		{0xFFA3E635, 0xFF22C55E, 0x080D07},
		{0xFFF59E0B, 0xFFEF4444, 0x110A06},
		{0xFFF472B6, 0xFFC084FC, 0x12070F}
	};

	public static final int TEXT = 0xFFF4F4F8;
	public static final int MUTED = 0xFF9A9AAE;
	public static final int GOOD = 0xFF4ADE80;
	public static final int WARN = 0xFFFBBF24;
	public static final int BAD = 0xFFF87171;

	private Theme() {}

	public static int accent() { return PRESETS[Modules.TH_ACCENT.mode][0]; }
	public static int accent2() { return PRESETS[Modules.TH_ACCENT.mode][1]; }
	public static int radius() { return Modules.TH_RADIUS.i(); }

	public static int bg(float alpha) {
		int a = Mth.clamp(Math.round(Modules.TH_OPACITY.f() * 255f * alpha), 0, 255);
		return (a << 24) | PRESETS[Modules.TH_ACCENT.mode][2];
	}
}
