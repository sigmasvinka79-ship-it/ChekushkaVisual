package dev.lumen.core;

public enum Category {
	HUD("HUD"),
	VISUALS("Visuals"),
	ANIMATIONS("Animations"),
	UTILITY("Utility"),
	THEME("Theme"),
	CONFIGS("Configs");

	public final String label;

	Category(String label) {
		this.label = label;
	}
}
