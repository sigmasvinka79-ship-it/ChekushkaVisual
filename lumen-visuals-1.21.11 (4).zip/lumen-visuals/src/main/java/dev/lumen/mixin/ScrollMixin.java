package dev.lumen.mixin;

import dev.lumen.visual.Zoom;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Колесо мыши во время зума меняет кратность вместо переключения хотбара. */
@Mixin(MouseHandler.class)
public abstract class ScrollMixin {

	@Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
	private void lumen$scroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
		if (yOffset != 0.0 && Zoom.onScroll(yOffset)) ci.cancel();
	}
}
