package dev.lumen.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lumen.anim.SwingAnimations;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.world.entity.HumanoidArm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Два маленьких хука на приватные методы, сигнатуры которых не менялись с 1.17:
 * applyItemArmAttackTransform (поворот при взмахе) и applyItemArmTransform (позиция при подъёме).
 */
@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {

	@Inject(method = "applyItemArmAttackTransform", at = @At("HEAD"), cancellable = true)
	private void lumen$swing(PoseStack poseStack, HumanoidArm arm, float swingProgress, CallbackInfo ci) {
		if (SwingAnimations.apply(poseStack, arm, swingProgress)) ci.cancel();
	}

	@Inject(method = "applyItemArmTransform", at = @At("TAIL"))
	private void lumen$offset(PoseStack poseStack, HumanoidArm arm, float equipProgress, CallbackInfo ci) {
		SwingAnimations.applyOffset(poseStack, arm);
	}
}
