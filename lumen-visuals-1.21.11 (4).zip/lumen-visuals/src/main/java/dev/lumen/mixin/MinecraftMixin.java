package dev.lumen.mixin;

import dev.lumen.core.Modules;
import dev.lumen.gui.LumenTitleScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Подменяет ванильное главное меню на своё (если включено в Theme → Interface). */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

	@ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true, require = 0)
	private Screen lumen$title(Screen screen) {
		if (screen != null && screen.getClass() == TitleScreen.class && Modules.TH_TITLE.bool) {
			return new LumenTitleScreen();
		}
		return screen;
	}
}
