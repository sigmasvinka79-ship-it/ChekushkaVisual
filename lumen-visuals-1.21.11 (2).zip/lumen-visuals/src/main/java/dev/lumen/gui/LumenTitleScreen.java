package dev.lumen.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import dev.lumen.core.Theme;
import dev.lumen.util.Anim;
import dev.lumen.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.util.Mth;

/**
 * Своё главное меню. Наследуется от ванильного, чтобы кнопки (Одиночная игра, Сетевая игра,
 * Настройки, Выход) работали как обычно, но рисуем мы всё сами: тёмно-фиолетовый фон,
 * плавающие огни и стеклянные кнопки.
 */
public final class LumenTitleScreen extends TitleScreen {
	private static final long START = System.nanoTime();

	private final Anim.Timer timer = new Anim.Timer();
	private final List<AbstractWidget> btns = new ArrayList<>();
	private final float[] hov = new float[8];
	private float t;

	public LumenTitleScreen() {
		super(false);
	}

	@Override
	protected void init() {
		super.init();
		btns.clear();
		List<AbstractWidget> wide = new ArrayList<>();
		for (GuiEventListener c : this.children()) {
			if (c instanceof AbstractWidget aw && aw.getWidth() >= 90) wide.add(aw);
		}
		wide.sort(Comparator.<AbstractWidget>comparingInt(AbstractWidget::getY).thenComparingInt(AbstractWidget::getX));

		List<AbstractWidget> shown = new ArrayList<>(wide);
		if (wide.size() == 5) {
			// порядок ванили: Одиночная, Сеть, Realms, Настройки, Выход — Realms прячем
			AbstractWidget realms = wide.get(2);
			realms.setY(-400);
			shown.remove(realms);
		}
		int n = Math.min(shown.size(), hov.length);
		int bw = 210, bh = 20, gap = 9;
		int total = n * bh + (n - 1) * gap;
		int y = height / 2 - total / 2 + 34;
		for (int i = 0; i < n; i++) {
			AbstractWidget wdg = shown.get(i);
			wdg.setX(width / 2 - bw / 2);
			wdg.setY(y);
			wdg.setWidth(bw);
			btns.add(wdg);
			y += bh + gap;
		}
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		float d = timer.tick();
		Anim.dt = d;
		t = Math.min(1f, t + d / 0.9f);
		float tt = (System.nanoTime() - START) / 1_000_000_000f;

		g.fillGradient(0, 0, width, height, 0xFF06030E, 0xFF150A28);

		// плавающие огни
		for (int i = 0; i < 7; i++) {
			float cx = width * (0.5f + 0.44f * Mth.sin(tt * 0.13f + i * 1.7f));
			float cy = height * (0.5f + 0.42f * Mth.sin(tt * 0.11f + i * 2.3f));
			float sz = 150f + 70f * Mth.sin(tt * 0.2f + i);
			int col = i % 2 == 0 ? Theme.accent() : Theme.accent2();
			Draw.glow(g, cx, cy, sz * 2f, Draw.a(col, 0.10f));
		}
		// мерцающие точки, плывут вверх
		for (int i = 0; i < 60; i++) {
			float rx = frac(Mth.sin(i * 12.9898f) * 43758.547f);
			float ry = frac(Mth.sin(i * 78.233f) * 12345.678f);
			float sp = 4f + 10f * frac(Mth.sin(i * 3.17f) * 999.1f);
			float x = rx * width + 6f * Mth.sin(tt * 0.5f + i);
			float y = ((ry * height - tt * sp) % height + height) % height;
			float al = 0.25f + 0.45f * (0.5f + 0.5f * Mth.sin(tt * 1.6f + i * 1.3f));
			int s = (i % 5 == 0) ? 2 : 1;
			g.fill(Math.round(x), Math.round(y), Math.round(x) + s, Math.round(y) + s, Draw.a(0xFFFFFFFF, al * t));
		}
		Draw.vignette(g, width, height, Draw.a(0xFF000000, 0.75f));

		// логотип
		float ls = 3.4f;
		String logo = "LUMEN";
		float lw = 0;
		for (int i = 0; i < logo.length(); i++) lw += Draw.width(String.valueOf(logo.charAt(i))) * ls + 3f;
		float lx = (width - lw) / 2f;
		float ly = height / 2f - 78f + (1f - Anim.easeOut(t)) * -14f;
		Draw.glow(g, width / 2f, ly + 14, 260, Draw.a(Theme.accent(), 0.22f * t));
		for (int i = 0; i < logo.length(); i++) {
			String ch = String.valueOf(logo.charAt(i));
			Draw.text(g, ch, lx, ly, ls, Draw.a(Draw.lerp(Theme.accent(), Theme.accent2(), i / 4f), t), true);
			lx += Draw.width(ch) * ls + 3f;
		}
		String sub = "V I S U A L S";
		Draw.text(g, sub, (width - Draw.width(sub) * 0.85f) / 2f, ly + 38, 0.85f, Draw.a(Theme.MUTED, t), false);

		// кнопки
		for (int i = 0; i < btns.size(); i++) {
			AbstractWidget b = btns.get(i);
			boolean over = mx >= b.getX() && mx <= b.getX() + b.getWidth() && my >= b.getY() && my <= b.getY() + b.getHeight();
			hov[i] = Anim.approach(hov[i], over ? 1f : 0f, 14f);
			float appear = Anim.smooth(Mth.clamp(t * 1.8f - i * 0.18f, 0f, 1f));
			float grow = hov[i] * 3f;
			float bx = b.getX() - grow, by = b.getY() - grow / 2f + (1f - appear) * 10f;
			float bw = b.getWidth() + grow * 2f, bh = b.getHeight() + grow;
			if (hov[i] > 0.02f) Draw.glow(g, bx + bw / 2f, by + bh / 2f, bw * 1.35f, Draw.a(Theme.accent(), 0.16f * hov[i] * appear));
			Draw.glass(g, bx, by, bw, bh, 8, appear);
			String label = b.getMessage().getString();
			Draw.text(g, label, bx + (bw - Draw.width(label)) / 2f, by + (bh - 8) / 2f,
				Draw.a(Draw.lerp(0xFFD0D0DE, Theme.TEXT, hov[i]), appear));
		}

		Draw.text(g, "Lumen Visuals", 8, height - 14, 0.8f, Draw.a(Theme.MUTED, t), false);
		String r = "Fabric 1.21.11";
		Draw.text(g, r, width - 8 - Draw.width(r) * 0.8f, height - 14, 0.8f, Draw.a(Theme.MUTED, t), false);
	}

	private static float frac(float v) {
		return v - (float) Math.floor(v);
	}
}
