package dev.lumen;

import java.util.Locale;

import com.mojang.blaze3d.platform.InputConstants;
import dev.lumen.core.Config;
import dev.lumen.core.Module;
import dev.lumen.core.Modules;
import dev.lumen.feature.Commands;
import dev.lumen.feature.ElytraHelper;
import dev.lumen.feature.EventDetector;
import dev.lumen.feature.Gps;
import dev.lumen.feature.Waypoints;
import dev.lumen.gui.MenuScreen;
import dev.lumen.hud.HudRenderer;
import dev.lumen.visual.Fullbright;
import dev.lumen.visual.HitSound;
import dev.lumen.visual.JumpCircles;
import dev.lumen.visual.ParticleFx;
import dev.lumen.visual.Zoom;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class LumenClient implements ClientModInitializer {
	public static final String ID = "lumen";
	public static KeyMapping OPEN_MENU;

	public static String slug(String name) {
		return name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
	}

	private static KeyMapping key(String id, int code, KeyMapping.Category cat) {
		return KeyBindingHelper.registerKeyBinding(new KeyMapping(id, InputConstants.Type.KEYSYM, code, cat));
	}

	@Override
	public void onInitializeClient() {
		Config.load();

		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));
		OPEN_MENU = key("key.lumen.open_menu", GLFW.GLFW_KEY_RIGHT_SHIFT, category);
		ElytraHelper.SWAP = key("key.lumen.elytra_swap", GLFW.GLFW_KEY_UNKNOWN, category);
		ElytraHelper.FIREWORK = key("key.lumen.elytra_firework", GLFW.GLFW_KEY_UNKNOWN, category);
		Zoom.KEY = key("key.lumen.zoom", GLFW.GLFW_KEY_C, category);
		// отдельная (по умолчанию не назначенная) клавиша на каждый модуль — настраивается в Управлении
		for (Module m : Modules.ALL) {
			if (m.toggleable) m.key = key("key.lumen.mod." + slug(m.name), GLFW.GLFW_KEY_UNKNOWN, category);
		}

		HudRenderer.init();

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (OPEN_MENU.consumeClick()) {
				if (mc.level != null && mc.screen == null) mc.setScreen(new MenuScreen());
			}
			for (Module m : Modules.ALL) {
				if (m.key == null) continue;
				while (m.key.consumeClick()) {
					if (mc.screen == null && mc.level != null) m.toggle();
				}
			}
			ElytraHelper.tick(mc);
			Fullbright.tick(mc);
			ParticleFx.tick(mc);
			HitSound.tick(mc);
			Gps.tick(mc);
			Waypoints.tick(mc);
			Zoom.tick(mc);
			JumpCircles.tick(mc);
		});

		// Команды клиента (.gps, .cfg, .wp, .hud) не уходят на сервер
		ClientSendMessageEvents.ALLOW_CHAT.register(message -> !Commands.handle(message));

		// Авто-метка на ивенты из чата
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
			if (!overlay) EventDetector.onMessage(message.getString());
		});
		ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, timestamp) ->
			EventDetector.onMessage(message.getString()));

		ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
			Fullbright.restore(mc);
			Zoom.restore(mc);
			Config.save();
		});
	}
}
