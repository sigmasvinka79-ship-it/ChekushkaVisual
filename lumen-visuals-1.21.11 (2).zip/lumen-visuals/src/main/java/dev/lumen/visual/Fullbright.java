package dev.lumen.visual;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import dev.lumen.core.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

/**
 * Fullbright через настройку яркости (gamma) — как слайдер «Яркость», только выше предела.
 * Поле значения ищем рефлексией по типу, чтобы не зависеть от обфусцированных имён.
 */
public final class Fullbright {
	private static Field field;
	private static boolean searched, active;
	private static double saved = 1.0;

	private Fullbright() {}

	private static Field find() {
		if (!searched) {
			searched = true;
			for (Field f : OptionInstance.class.getDeclaredFields()) {
				int m = f.getModifiers();
				if (!Modifier.isStatic(m) && !Modifier.isFinal(m) && f.getType() == Object.class) {
					f.setAccessible(true);
					field = f;
					break;
				}
			}
		}
		return field;
	}

	public static void tick(Minecraft mc) {
		try {
			Field f = find();
			if (f == null || mc.options == null) return;
			OptionInstance<Double> g = mc.options.gamma();
			if (Modules.FULLBRIGHT.enabled) {
				if (!active) {
					saved = g.get();
					active = true;
				}
				f.set(g, 16.0D);
			} else if (active) {
				f.set(g, saved);
				active = false;
			}
		} catch (Throwable ignored) {
		}
	}

	/** Вернуть обычную яркость (перед выходом, чтобы options.txt не испортился). */
	public static void restore(Minecraft mc) {
		try {
			if (active && field != null) {
				field.set(mc.options.gamma(), saved);
				active = false;
			}
		} catch (Throwable ignored) {
		}
	}
}
