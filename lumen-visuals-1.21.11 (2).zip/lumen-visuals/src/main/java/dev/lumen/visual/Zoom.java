package dev.lumen.visual;

import dev.lumen.core.Modules;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/** Зум по зажатой клавише (меняет настройку FOV и плавно возвращает обратно). */
public final class Zoom {
	public static KeyMapping KEY;
	private static int saved = 70;
	private static boolean zoomed;

	private Zoom() {}

	public static void tick(Minecraft mc) {
		var opt = mc.options.fov();
		boolean want = Modules.ZOOM.enabled && mc.screen == null && KEY != null && KEY.isDown();
		int cur = opt.get();
		if (want) {
			if (!zoomed) {
				saved = cur;
				zoomed = true;
			}
			int target = Modules.ZOOM_FOV.i();
			if (cur > target) opt.set(Math.max(target, cur - Math.max(2, (cur - target) / 3)));
		} else if (zoomed) {
			if (cur < saved) {
				opt.set(Math.min(saved, cur + Math.max(2, (saved - cur) / 3)));
			} else {
				zoomed = false;
			}
		}
	}

	public static void restore(Minecraft mc) {
		if (zoomed) {
			mc.options.fov().set(saved);
			zoomed = false;
		}
	}
}
