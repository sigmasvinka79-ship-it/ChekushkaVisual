package dev.lumen.feature;

import dev.lumen.core.Modules;
import dev.lumen.util.Stats;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.ParticleStatus;

/**
 * Optimization: ставит «дешёвые» настройки, которые почти не меняют картинку (тени существ, облака,
 * смешивание биомов), по желанию уменьшает частицы и снимает лимит FPS. Исходные значения
 * запоминаются и возвращаются при выключении. Плюс адаптивное качество эффектов мода при низком FPS.
 */
public final class Optimization {
	private static boolean saved, applied;
	private static boolean sShadows, sVsync;
	private static CloudStatus sClouds;
	private static int sBiome, sFps;
	private static ParticleStatus sParticles;

	private Optimization() {}

	/** true, когда эффектам мода стоит упростить отрисовку. */
	public static boolean low() {
		return Modules.OPTIMIZATION.enabled && Modules.OP_ADAPT.bool && Stats.fps > 0 && Stats.fps < 50;
	}

	private static <T> void put(OptionInstance<T> o, T v) {
		if (!o.get().equals(v)) o.set(v);
	}

	private static void save(Minecraft mc) {
		var o = mc.options;
		sShadows = o.entityShadows().get();
		sClouds = o.cloudStatus().get();
		sBiome = o.biomeBlendRadius().get();
		sParticles = o.particles().get();
		sVsync = o.enableVsync().get();
		sFps = o.framerateLimit().get();
		saved = true;
	}

	public static void tick(Minecraft mc) {
		if (mc.options == null) return;
		try {
			var o = mc.options;
			if (Modules.OPTIMIZATION.enabled) {
				if (!saved) save(mc);
				applied = true;
				put(o.entityShadows(), Modules.OP_SHADOWS.bool ? Boolean.FALSE : sShadows);
				put(o.cloudStatus(), Modules.OP_CLOUDS.bool ? CloudStatus.OFF : sClouds);
				put(o.biomeBlendRadius(), Modules.OP_BIOME.bool ? Integer.valueOf(Math.min(1, sBiome)) : sBiome);
				put(o.particles(), Modules.OP_PARTICLES.bool ? ParticleStatus.DECREASED : sParticles);
				put(o.enableVsync(), Modules.OP_UNCAP.bool ? Boolean.FALSE : sVsync);
				put(o.framerateLimit(), Modules.OP_UNCAP.bool ? Integer.valueOf(260) : sFps);
			} else if (applied) {
				restore(mc);
			}
		} catch (Throwable ignored) {
		}
	}

	public static void restore(Minecraft mc) {
		if (!applied || !saved || mc.options == null) return;
		try {
			var o = mc.options;
			put(o.entityShadows(), sShadows);
			put(o.cloudStatus(), sClouds);
			put(o.biomeBlendRadius(), sBiome);
			put(o.particles(), sParticles);
			put(o.enableVsync(), sVsync);
			put(o.framerateLimit(), sFps);
		} catch (Throwable ignored) {
		}
		applied = false;
		saved = false;
	}
}
