#!/usr/bin/env python3
"""
Nexora Social Server: профили, коды дружбы, заявки в друзья и статус «в сети».
Только стандартная библиотека Python 3.8+ (SQLite внутри). Запуск:  python nexora_server.py
Порт берётся из переменной PORT (по умолчанию 8080). База: nexora.db рядом с файлом.
Это простой прототип: без HTTPS (ставь за прокси/хостингом с HTTPS) и без защиты от злоупотреблений.
"""
import json, os, re, secrets, sqlite3, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nexora.db")
ONLINE_WINDOW = 75  # секунд: столько после последнего сигнала считаем игрока «в сети»
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
NAME_RE = re.compile(r"^[A-Za-z0-9_]{3,16}$")

_lock = threading.Lock()
_db = sqlite3.connect(DB_PATH, check_same_thread=False)
_db.row_factory = sqlite3.Row
_db.executescript("""
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE COLLATE NOCASE, code TEXT UNIQUE,
  token TEXT UNIQUE, bio TEXT DEFAULT '', status TEXT DEFAULT '', color INTEGER DEFAULT 0,
  appear_offline INTEGER DEFAULT 0, show_server INTEGER DEFAULT 1,
  state TEXT DEFAULT 'menu', server TEXT DEFAULT '', last_seen REAL DEFAULT 0, created REAL);
CREATE TABLE IF NOT EXISTS requests(frm INTEGER, tou INTEGER, created REAL, PRIMARY KEY(frm, tou));
CREATE TABLE IF NOT EXISTS friends(a INTEGER, b INTEGER, PRIMARY KEY(a, b));
""")


def new_code():
    while True:
        code = "NX-" + "".join(secrets.choice(CODE_ALPHABET) for _ in range(8))
        if not _db.execute("SELECT 1 FROM users WHERE code=?", (code,)).fetchone():
            return code


def user_by_token(token):
    return _db.execute("SELECT * FROM users WHERE token=?", (token,)).fetchone() if token else None


def find_user(target):
    target = (target or "").strip()
    return _db.execute("SELECT * FROM users WHERE username=? OR code=?", (target, target.upper())).fetchone()


def public_view(u, viewer_is_friend):
    now = time.time()
    online = (now - (u["last_seen"] or 0)) < ONLINE_WINDOW and not u["appear_offline"]
    where = None
    if online:
        if u["state"] == "server":
            where = (u["server"] or "Server") if u["show_server"] else "Multiplayer"
        elif u["state"] == "single":
            where = "Singleplayer"
        else:
            where = "Menu"
    return {"username": u["username"], "code": u["code"], "bio": u["bio"], "status": u["status"],
            "color": u["color"], "online": bool(online), "where": where,
            "last_seen": int(u["last_seen"] or 0) if not u["appear_offline"] else 0}


def friend_ids(uid):
    rows = _db.execute("SELECT b FROM friends WHERE a=?", (uid,)).fetchall()
    return [r["b"] for r in rows]


def me_payload(u):
    friends = []
    for fid in friend_ids(u["id"]):
        f = _db.execute("SELECT * FROM users WHERE id=?", (fid,)).fetchone()
        if f:
            friends.append(public_view(f, True))
    inc = [r["username"] for r in _db.execute(
        "SELECT u.username FROM requests r JOIN users u ON u.id=r.frm WHERE r.tou=?", (u["id"],))]
    out = [r["username"] for r in _db.execute(
        "SELECT u.username FROM requests r JOIN users u ON u.id=r.tou WHERE r.frm=?", (u["id"],))]
    return {"username": u["username"], "code": u["code"], "bio": u["bio"], "status": u["status"],
            "color": u["color"], "appear_offline": bool(u["appear_offline"]), "show_server": bool(u["show_server"]),
            "friends": friends, "incoming": inc, "outgoing": out}


def clip(v, n):
    return str(v or "")[:n]


class Handler(BaseHTTPRequestHandler):
    server_version = "NexoraSocial/1.0"

    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length", "0"))
            return json.loads(self.rfile.read(min(n, 20000)) or b"{}")
        except Exception:
            return {}

    def do_GET(self):
        if urlparse(self.path).path == "/api/ping":
            return self._send(200, {"ok": True, "name": "nexora-social"})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        path = urlparse(self.path).path
        body = self._body()
        with _lock:
            try:
                self._route(path, body)
            except Exception as e:  # не роняем сервер из-за одного запроса
                self._send(500, {"error": "server error: %s" % e})

    def _route(self, path, b):
        if path == "/api/register":
            name = clip(b.get("username"), 16).strip()
            if not NAME_RE.match(name):
                return self._send(400, {"error": "username must be 3-16 chars: A-Z a-z 0-9 _"})
            if _db.execute("SELECT 1 FROM users WHERE username=?", (name,)).fetchone():
                return self._send(409, {"error": "username is taken"})
            token = secrets.token_hex(24)
            code = new_code()
            _db.execute("INSERT INTO users(username, code, token, created) VALUES(?,?,?,?)", (name, code, token, time.time()))
            _db.commit()
            return self._send(200, {"token": token, "username": name, "code": code})

        u = user_by_token(self.headers.get("X-Token", ""))
        if not u:
            return self._send(401, {"error": "unauthorized"})

        if path == "/api/me":
            return self._send(200, me_payload(u))

        if path == "/api/profile":
            _db.execute("UPDATE users SET bio=?, status=?, color=?, appear_offline=?, show_server=? WHERE id=?", (
                clip(b.get("bio"), 120), clip(b.get("status"), 40), int(b.get("color", 0)) % 8,
                1 if b.get("appear_offline") else 0, 1 if b.get("show_server", True) else 0, u["id"]))
            _db.commit()
            return self._send(200, {"ok": True})

        if path == "/api/presence":
            state = b.get("state") if b.get("state") in ("menu", "single", "server") else "menu"
            _db.execute("UPDATE users SET state=?, server=?, last_seen=? WHERE id=?",
                        (state, clip(b.get("server"), 64), time.time(), u["id"]))
            _db.commit()
            return self._send(200, {"ok": True})

        if path == "/api/friend/request":
            t = find_user(b.get("target"))
            if not t:
                return self._send(404, {"error": "user not found"})
            if t["id"] == u["id"]:
                return self._send(400, {"error": "that is you"})
            if t["id"] in friend_ids(u["id"]):
                return self._send(409, {"error": "already friends"})
            # встречная заявка = сразу дружба
            if _db.execute("SELECT 1 FROM requests WHERE frm=? AND tou=?", (t["id"], u["id"])).fetchone():
                _db.execute("DELETE FROM requests WHERE frm=? AND tou=?", (t["id"], u["id"]))
                _db.execute("INSERT OR IGNORE INTO friends VALUES(?,?)", (u["id"], t["id"]))
                _db.execute("INSERT OR IGNORE INTO friends VALUES(?,?)", (t["id"], u["id"]))
                _db.commit()
                return self._send(200, {"ok": True, "friends": True})
            _db.execute("INSERT OR IGNORE INTO requests VALUES(?,?,?)", (u["id"], t["id"], time.time()))
            _db.commit()
            return self._send(200, {"ok": True, "friends": False})

        if path == "/api/friend/respond":
            f = find_user(b.get("from"))
            if not f or not _db.execute("SELECT 1 FROM requests WHERE frm=? AND tou=?", (f["id"], u["id"])).fetchone():
                return self._send(404, {"error": "no such request"})
            _db.execute("DELETE FROM requests WHERE frm=? AND tou=?", (f["id"], u["id"]))
            if b.get("accept"):
                _db.execute("INSERT OR IGNORE INTO friends VALUES(?,?)", (u["id"], f["id"]))
                _db.execute("INSERT OR IGNORE INTO friends VALUES(?,?)", (f["id"], u["id"]))
            _db.commit()
            return self._send(200, {"ok": True})

        if path == "/api/friend/remove":
            f = find_user(b.get("username"))
            if f:
                _db.execute("DELETE FROM friends WHERE (a=? AND b=?) OR (a=? AND b=?)", (u["id"], f["id"], f["id"], u["id"]))
                _db.commit()
            return self._send(200, {"ok": True})

        if path == "/api/user":
            t = find_user(b.get("target"))
            if not t:
                return self._send(404, {"error": "user not found"})
            return self._send(200, public_view(t, t["id"] in friend_ids(u["id"])))

        self._send(404, {"error": "not found"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    print("Nexora Social Server on port", port)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
