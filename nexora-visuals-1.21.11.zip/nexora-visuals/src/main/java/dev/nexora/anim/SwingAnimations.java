package dev.nexora.anim;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.nexora.core.Modules;
import dev.nexora.feature.License;
import dev.nexora.util.Anim;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Анимации взмаха и позы руки в первом лице. Только клиент: меняется матрица предмета в руке.
 * Все анимации плавно приходят в нулевое положение до конца взмаха (без «подскока» в конце),
 * а поза проверяется на видимость: клинок не выходит за кадр.
 */
public final class SwingAnimations {
	private SwingAnimations() {}

	private interface Ops {
		void t(float x, float y, float z);
		void rx(float d);
		void ry(float d);
		void rz(float d);
	}

	private static final class PoseOps implements Ops {
		private final PoseStack p;

		PoseOps(PoseStack p) { this.p = p; }

		public void t(float x, float y, float z) { p.translate(x, y, z); }
		public void rx(float d) { p.mulPose(Axis.XP.rotationDegrees(d)); }
		public void ry(float d) { p.mulPose(Axis.YP.rotationDegrees(d)); }
		public void rz(float d) { p.mulPose(Axis.ZP.rotationDegrees(d)); }
	}

	private static final class MatOps implements Ops {
		private final Matrix4f m;

		MatOps(Matrix4f m) { this.m = m; }

		public void t(float x, float y, float z) { m.translate(x, y, z); }
		public void rx(float d) { m.rotateX((float) Math.toRadians(d)); }
		public void ry(float d) { m.rotateY((float) Math.toRadians(d)); }
		public void rz(float d) { m.rotateZ((float) Math.toRadians(d)); }
	}

	/** @return true, если ванильное преобразование взмаха нужно отменить. */
	public static boolean apply(PoseStack p, HumanoidArm arm, float swing) {
		if (!License.active() || !Modules.SWING.enabled) return false;
		int mode = Modules.SW_MODE.mode;
		if (mode == 0) return false;
		if (swing <= 0f) return true;

		Ops o = new PoseOps(p);
		float k = Modules.SW_POWER.f();
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		// «колокола» возводятся в квадрат: к концу взмаха значение ≈ 0, нет рывка в последнем кадре
		float w0 = Mth.sin(swing * Mth.PI), w = w0 * w0;
		float s0 = Mth.sin(Mth.sqrt(swing) * Mth.PI), s = s0 * s0;

		switch (mode) {
			case 1 -> { // Smooth
				o.ry(side * (45f - 8f * s * k));
				o.rz(side * s * -14f * k);
				o.rx(s * -62f * k);
				o.ry(side * -45f);
			}
			case 2 -> { // Slash
				o.ry(side * 45f);
				o.rz(side * -70f * w * k);
				o.rx(-18f * w * k);
				o.ry(side * (-45f + 38f * w * k));
			}
			case 3 -> { // Slide
				o.t(side * 0.06f * w * k, -0.12f * w * k, -0.65f * w * k);
				o.rx(-12f * w * k);
			}
			case 4 -> { // Block
				o.t(side * -0.12f * w * k, 0.08f * w * k, 0f);
				o.ry(side * 28f * w * k);
				o.rz(side * -22f * w * k);
				o.rx((-52f * w - 26f * s) * k);
			}
			case 5 -> { // Spin: полный оборот к 90% взмаха
				float sp = Anim.smooth(Mth.clamp(swing / 0.9f, 0f, 1f));
				o.rx(-25f * w * k);
				o.rz(side * 360f * sp);
			}
			case 6 -> { // Poke
				o.t(0f, 0.02f * w * k, -0.85f * w * k);
				o.rx(-6f * w * k);
				o.ry(side * 8f * w * k);
			}
			case 7 -> { // Wave
				float env = 1f - Anim.smooth(Mth.clamp((swing - 0.7f) / 0.3f, 0f, 1f));
				o.rz(side * Mth.sin(swing * Mth.TWO_PI) * 24f * env * k);
				o.rx(-34f * w * k);
			}
			case 8 -> { // Drop
				o.t(0f, 0.3f * w * (1f - swing) * k, 0f);
				o.rx((-95f * s + 40f * w * w) * k);
			}
			default -> {
				return false;
			}
		}
		return true;
	}

	/** Поза руки: 0 Default, 1 Horizontal, 2 Low, 3 Tilted, 4 Block Pose, 5 Forward. */
	private static void pose(Ops o, int pose, int side, float k) {
		switch (pose) {
			case 1 -> { // Horizontal: клинок поперёк экрана
				o.t(side * -0.14f * k, 0.26f * k, 0f);
				o.rz(side * 80f * k);
				o.ry(side * -10f * k);
			}
			case 2 -> { // Low
				o.t(side * 0.04f * k, -0.10f * k, 0.04f * k);
				o.rx(14f * k);
			}
			case 3 -> { // Tilted
				o.t(side * -0.04f * k, 0.08f * k, 0f);
				o.rz(side * -35f * k);
				o.rx(-12f * k);
			}
			case 4 -> { // Block Pose
				o.t(side * -0.20f * k, 0.22f * k, 0.06f * k);
				o.rx(-38f * k);
				o.ry(side * 28f * k);
				o.rz(side * 28f * k);
			}
			case 5 -> { // Forward
				o.t(0f, 0.10f * k, 0.02f * k);
				o.rx(-48f * k);
			}
			default -> {
			}
		}
	}

	private static boolean visible(Matrix4f m, float tanH, float aspect) {
		Vector3f v = new Vector3f();
		float[] ys = {0.20f, 0.50f};
		for (float y : ys) {
			v.set(0f, y, 0f);
			m.transformPosition(v);
			if (v.z > -0.15f) return false;
			float inv = -1f / v.z;
			if (Math.abs(v.x * inv) > tanH * aspect * 0.9f || Math.abs(v.y * inv) > tanH * 0.88f) return false;
		}
		return true;
	}

	// Разрешённая сила позы считается один раз (для покоя), поэтому поза держится ровно.
	private static int cPose = -1, cSide;
	private static float cK, cResult;

	private static float poseStrength(int pose, int side, float k) {
		if (pose == cPose && side == cSide && k == cK) return cResult;
		float tanH = (float) Math.tan(Math.toRadians(70.0) / 2.0);
		float s = 1f, res = 0f;
		for (int i = 0; i < 12; i++) {
			Matrix4f m = new Matrix4f().translate(side * 0.56f, -0.52f, -0.72f);
			pose(new MatOps(m), pose, side, k * s);
			if (visible(m, tanH, 16f / 9f)) {
				res = s;
				break;
			}
			s *= 0.8f;
		}
		cPose = pose;
		cSide = side;
		cK = k;
		cResult = res;
		return res;
	}

	public static void applyOffset(PoseStack p, HumanoidArm arm) {
		if (!License.active() || !Modules.SWING.enabled) return;
		int side = arm == HumanoidArm.RIGHT ? 1 : -1;
		int pose = Modules.SW_POSE.mode;
		if (pose != 0) {
			float k = Modules.SW_POWER.f();
			float s = poseStrength(pose, side, k);
			if (s > 0f) pose(new PoseOps(p), pose, side, k * s);
		}
		float sc = Modules.SW_SCALE.f();
		if (sc != 1f) p.scale(sc, sc, sc);
	}
}
