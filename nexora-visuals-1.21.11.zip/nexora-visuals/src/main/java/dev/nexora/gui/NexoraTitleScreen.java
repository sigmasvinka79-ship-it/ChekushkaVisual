package dev.nexora.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import dev.nexora.core.Theme;
import dev.nexora.feature.License;
import dev.nexora.feature.Social;
import dev.nexora.util.Anim;
import dev.nexora.util.Draw;
import dev.nexora.util.Lang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.util.Mth;

/**
 * Главное меню Nexora: тёмное стекло, мягкое переливающееся сияние, крупная надпись и четыре кнопки.
 * Сверху справа — профиль и аккаунты, внизу — ввод ключа (пока мод не активирован).
 * Наследуется от ванильного экрана, чтобы кнопки (Одиночная, Сеть, Настройки, Выход) работали как обычно.
 */
public final class NexoraTitleScreen extends TitleScreen {
	private static final long START = System.nanoTime();
	private static final int BW = 190, BH = 20, GAP = 8;
	private static final int[] COLORS = {0xFF4C8DFF, 0xFF38F2B2, 0xFFA78BFA, 0xFFFB7185, 0xFFF59E0B, 0xFFE879F9, 0xFF7FD6FF, 0xFFE5E7EB};

	private final Anim.Timer timer = new Anim.Timer();
	private final List<AbstractWidget> slots = new ArrayList<>();
	private final float[] hov = new float[8];
	private final float[] chip = new float[4], acc = new float[4], key = new float[4];
	private float t, chipHov, accHov, keyHov;

	public NexoraTitleScreen() {
		super(false);
	}

	@Override
	protected void init() {
		super.init();
		slots.clear();
		List<AbstractWidget> wide = new ArrayList<>();
		for (GuiEventListener c : this.children()) {
			if (c instanceof AbstractWidget aw && aw.getWidth() >= 90) wide.add(aw);
		}
		wide.sort(Comparator.<AbstractWidget>comparingInt(AbstractWidget::getY).thenComparingInt(AbstractWidget::getX));
		List<AbstractWidget> shown = new ArrayList<>(wide);
		if (wide.size() == 5) {
			// порядок ванили: Одиночная, Сеть, Realms, Настройки, Выход. Realms прячем.
			AbstractWidget realms = wide.get(2);
			realms.setY(-400);
			shown.remove(realms);
		}
		int n = Math.min(shown.size(), hov.length);
		int total = n * BH + (n - 1) * GAP;
		int y = height / 2 - total / 2 + 40;
		for (int i = 0; i < n; i++) {
			AbstractWidget w = shown.get(i);
			w.setX(width / 2 - BW / 2);
			w.setY(y);
			w.setWidth(BW);
			slots.add(w);
			y += BH + GAP;
		}
	}

	private static boolean in(double mx, double my, float[] r) {
		return mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3];
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		var mc = Minecraft.getInstance();
		if (e.button() == 0) {
			if (in(e.x(), e.y(), chip)) {
				mc.setScreen(new SocialScreen(this));
				return true;
			}
			if (in(e.x(), e.y(), acc)) {
				mc.setScreen(new AccountsScreen(this));
				return true;
			}
			if (!License.active() && in(e.x(), e.y(), key)) {
				mc.setScreen(new ActivationScreen(this));
				return true;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	private void pillAt(GuiGraphics g, float[] r, float x, float y, float w, float h, float hover, String label, float a, boolean accentFill) {
		r[0] = x;
		r[1] = y;
		r[2] = w;
		r[3] = h;
		Draw.glass(g, x, y, w, h, Math.min(8, (int) (h / 2)), a);
		if (accentFill) Draw.rounded(g, x + 1, y + 1, w - 2, h - 2, Math.min(8, (int) (h / 2)), Draw.a(Theme.accent(), (0.22f + 0.2f * hover) * a));
		Draw.text(g, label, x + (w - Draw.width(label) * 0.85f) / 2f, y + (h - 7) / 2f, 0.85f,
			Draw.a(Draw.lerp(0xFFD0D6E4, Theme.TEXT, hover), a), false);
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		float d = timer.tick();
		Anim.dt = d;
		t = Math.min(1f, t + d / 1.0f);
		float tt = (System.nanoTime() - START) / 1_000_000_000f;
		float a = Anim.smooth(t);
		int c1 = Theme.accent(), c2 = Theme.accent2();

		g.fillGradient(0, 0, width, height, 0xFF03050B, 0xFF0A1226);

		// сияние: большие мягкие пятна, медленно плывут
		for (int i = 0; i < 4; i++) {
			float cx = width * (0.5f + 0.40f * Mth.sin(tt * 0.09f + i * 1.9f));
			float cy = height * (0.5f + 0.36f * Mth.sin(tt * 0.07f + i * 2.6f));
			float sz = (240f + 90f * Mth.sin(tt * 0.15f + i)) * Math.max(1f, width / 480f);
			Draw.glow(g, cx, cy, sz * 2f, Draw.a(i % 2 == 0 ? c1 : c2, 0.13f));
		}
		// световые полосы
		for (int i = 0; i < 2; i++) {
			float cy = height * (0.35f + 0.3f * i) + 14f * Mth.sin(tt * 0.3f + i * 3f);
			float cx = width * (0.5f + 0.2f * Mth.sin(tt * 0.12f + i));
			Draw.glowRect(g, cx, cy, width * 1.3f, 26f, Draw.a(c1, 0.09f));
		}
		// звёзды
		for (int i = 0; i < 46; i++) {
			float rx = frac(Mth.sin(i * 12.9898f) * 43758.547f);
			float ry = frac(Mth.sin(i * 78.233f) * 12345.678f);
			float sp = 3f + 8f * frac(Mth.sin(i * 3.17f) * 999.1f);
			float x = rx * width + 5f * Mth.sin(tt * 0.5f + i);
			float y = ((ry * height - tt * sp) % height + height) % height;
			float al = 0.2f + 0.4f * (0.5f + 0.5f * Mth.sin(tt * 1.5f + i * 1.3f));
			g.fill(Math.round(x), Math.round(y), Math.round(x) + 1, Math.round(y) + 1, Draw.a(0xFFFFFFFF, al * a));
		}
		Draw.vignette(g, width, height, Draw.a(0xFF000000, 0.7f));

		// надпись
		float ls = 4.4f, gap = 5f;
		String logo = "NEXORA";
		float lw = 0;
		for (int i = 0; i < logo.length(); i++) lw += Draw.width(String.valueOf(logo.charAt(i))) * ls + gap;
		lw -= gap;
		float lx = (width - lw) / 2f;
		float ly = height / 2f - 86f + (1f - Anim.easeOut(t)) * -16f;
		Draw.glow(g, width / 2f, ly + 16, 360, Draw.a(c1, 0.20f * a));
		for (int i = 0; i < logo.length(); i++) {
			String ch = String.valueOf(logo.charAt(i));
			float sh = 0.5f + 0.5f * Mth.sin(tt * 1.4f - i * 0.7f);
			Draw.text(g, ch, lx, ly, ls, Draw.a(Draw.lerp(c1, c2, sh), a), true);
			lx += Draw.width(ch) * ls + gap;
		}
		int lineW = 150;
		float lyy = ly + 46;
		for (int i = 0; i < lineW; i++) {
			float f = i / (float) lineW;
			float edge = Mth.sin(f * Mth.PI);
			g.fill(Math.round(width / 2f) - lineW / 2 + i, Math.round(lyy), Math.round(width / 2f) - lineW / 2 + i + 1, Math.round(lyy) + 1,
				Draw.a(Draw.lerp(c1, c2, f), 0.8f * edge * a));
		}
		String sub = "V I S U A L S";
		Draw.text(g, sub, (width - Draw.width(sub) * 0.8f) / 2f, lyy + 8, 0.8f, Draw.a(Theme.MUTED, a), false);

		// кнопки
		for (int i = 0; i < slots.size(); i++) {
			AbstractWidget b = slots.get(i);
			boolean over = mx >= b.getX() && mx <= b.getX() + BW && my >= b.getY() && my <= b.getY() + BH;
			hov[i] = Anim.approach(hov[i], over ? 1f : 0f, 14f);
			float appear = Anim.smooth(Mth.clamp(t * 1.8f - i * 0.16f, 0f, 1f));
			float grow = hov[i] * 4f;
			float bx = b.getX() - grow, by = b.getY() + (1f - appear) * 10f;
			float bw = BW + grow * 2f;
			if (hov[i] > 0.02f) Draw.glow(g, bx + bw / 2f, by + BH / 2f, bw * 1.4f, Draw.a(c1, 0.20f * hov[i] * appear));
			Draw.glass(g, bx, by, bw, BH, 8, appear);
			if (hov[i] > 0.02f) {
				g.fill(Math.round(bx) + 6, Math.round(by) + 5, Math.round(bx) + 8, Math.round(by) + BH - 5, Draw.a(c1, hov[i] * appear));
			}
			String label = b.getMessage().getString();
			Draw.text(g, label, bx + (bw - Draw.width(label)) / 2f, by + (BH - 8) / 2f,
				Draw.a(Draw.lerp(0xFFD0D6E4, Theme.TEXT, hov[i]), appear));
		}

		// профиль (справа вверху) и аккаунты
		String pname = Social.registered() ? Social.username : Lang.t("Profile");
		float pw = Draw.width(pname) * 0.9f + 38;
		float px = width - pw - 10, py = 10;
		boolean chipOver = in(mx, my, chip);
		chipHov = Anim.approach(chipHov, chipOver ? 1f : 0f, 14f);
		chip[0] = px;
		chip[1] = py;
		chip[2] = pw;
		chip[3] = 24;
		Draw.glass(g, px, py, pw, 24, 10, a);
		int avc = COLORS[Social.color % COLORS.length];
		Draw.rounded(g, px + 5, py + 4, 16, 16, 8, Draw.a(avc, a));
		boolean on = Social.registered() && Social.configured();
		Draw.rounded(g, px + 17, py + 15, 6, 6, 3, Draw.a(on ? Theme.GOOD : 0xFF5B6475, a));
		Draw.text(g, pname, px + 28, py + 8, 0.9f, Draw.a(Draw.lerp(0xFFD0D6E4, Theme.TEXT, chipHov), a), false);

		boolean accOver = in(mx, my, acc);
		accHov = Anim.approach(accHov, accOver ? 1f : 0f, 14f);
		pillAt(g, acc, px - 82, py, 74, 24, accHov, Lang.t("Accounts"), a, false);

		// ключ активации
		if (!License.active()) {
			boolean keyOver = in(mx, my, key);
			keyHov = Anim.approach(keyHov, keyOver ? 1f : 0f, 14f);
			String kl = Lang.t("Enter key");
			float kw = Draw.width(kl) * 0.85f + 30;
			pillAt(g, key, (width - kw) / 2f, height - 38, kw, 22, keyHov, kl, a, true);
		} else {
			key[2] = 0;
			key[3] = 0;
		}

		Draw.text(g, "Nexora Visuals", 8, height - 14, 0.8f, Draw.a(Theme.MUTED, a), false);
		String r = "Fabric 1.21.11";
		Draw.text(g, r, width - 8 - Draw.width(r) * 0.8f, height - 14, 0.8f, Draw.a(Theme.MUTED, a), false);
	}

	private static float frac(float v) {
		return v - (float) Math.floor(v);
	}
}
