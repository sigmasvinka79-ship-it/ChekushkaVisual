package dev.nexora.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

import dev.nexora.core.Theme;
import dev.nexora.feature.License;
import dev.nexora.util.Anim;
import dev.nexora.util.Draw;
import dev.nexora.util.Lang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/** Ввод ключа активации. Ключ запоминается один раз, дальше мод его не спрашивает. */
public final class ActivationScreen extends Screen {
	private static final int PW = 320, PH = 176;

	private record Region(float x, float y, float w, float h, IntConsumer click) {
		boolean has(double px, double py) {
			return px >= x && px <= x + w && py >= y && py <= y + h;
		}
	}

	private final Screen parent;
	private final Anim.Timer timer = new Anim.Timer();
	private final List<Region> regions = new ArrayList<>();
	private String input = "", msg = "";
	private int msgCol = Theme.MUTED;
	private boolean ctrl, success;
	private long successAt;
	private float t;

	public ActivationScreen(Screen parent) {
		super(Component.literal("Activation"));
		this.parent = parent;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}

	private void submit() {
		if (input.isBlank() || success) return;
		msg = Lang.t("Checking...");
		msgCol = Theme.MUTED;
		License.tryActivate(input, r -> {
			switch (r) {
				case OK -> {
					success = true;
					successAt = System.currentTimeMillis();
					msg = Lang.t("Key accepted");
					msgCol = Theme.GOOD;
				}
				case REVOKED -> {
					msg = Lang.t("Key already used");
					msgCol = Theme.BAD;
				}
				case ERROR -> {
					msg = Lang.t("Could not reach key server");
					msgCol = Theme.WARN;
				}
				default -> {
					msg = Lang.t("Invalid key");
					msgCol = Theme.BAD;
				}
			}
		});
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		float d = timer.tick();
		Anim.dt = d;
		t = Math.min(1f, t + d / 0.28f);
		float a = Anim.smooth(Mth.clamp(t * 1.6f, 0f, 1f));
		if (success && System.currentTimeMillis() - successAt > 900) {
			var mc = Minecraft.getInstance();
			if (parent != null) mc.setScreen(parent);
			else if (mc.level != null) mc.setScreen(new MenuScreen());
			else mc.setScreen(null);
			return;
		}

		g.fillGradient(0, 0, width, height, Draw.a(0xFF04060D, 0.94f * a), Draw.a(0xFF0A1226, 0.94f * a));
		regions.clear();
		float x = (width - PW) / 2f, y = (height - PH) / 2f + (1f - Anim.easeOut(t)) * 14f;
		Draw.glow(g, width / 2f, height / 2f, 420, Draw.a(Theme.accent(), 0.10f * a));
		Draw.shadow(g, x, y, PW, PH, 10, a);
		Draw.glass(g, x, y, PW, PH, 10, Math.min(1f, a * 1.2f));
		Draw.sheen(g, x, y, PW, PH, a);

		Draw.text(g, Lang.t("Activation"), x + 18, y + 14, 1.5f, Draw.a(Theme.TEXT, a), true);
		Draw.text(g, Lang.t("Enter activation key"), x + 18, y + 36, 0.8f, Draw.a(Theme.MUTED, a), false);

		float iy = y + 62;
		boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
		Draw.rounded(g, x + 18, iy, PW - 36, 26, 8, Draw.a(0x1CFFFFFF, a));
		Draw.border(g, Math.round(x) + 18, Math.round(iy), PW - 36, 26, 8, Draw.a(Theme.accent(), 0.5f * a));
		String shown = input.isEmpty() ? "NXR-XXXX-XXXX-XXXX" : input;
		Draw.text(g, shown + (!input.isEmpty() && caret ? "|" : ""), x + 28, iy + 9, Draw.a(input.isEmpty() ? Theme.MUTED : Theme.TEXT, a));

		boolean over = mx >= x + 18 && mx <= x + PW - 18 && my >= y + 100 && my <= y + 124;
		Draw.rounded(g, x + 18, y + 100, PW - 36, 24, 8, Draw.a(Theme.accent(), (over ? 0.55f : 0.35f) * a));
		String btn = Lang.t("Activate");
		Draw.text(g, btn, x + (PW - Draw.width(btn)) / 2f, y + 108, Draw.a(Theme.TEXT, a));
		regions.add(new Region(x + 18, y + 100, PW - 36, 24, b -> submit()));

		if (!msg.isEmpty()) Draw.text(g, msg, x + 18, y + 134, 0.85f, Draw.a(msgCol, a), false);

		boolean bo = mx >= x + 14 && mx <= x + 74 && my >= y + PH - 20 && my <= y + PH - 4;
		Draw.text(g, "< " + Lang.t("Back"), x + 18, y + PH - 18, 0.85f, Draw.a(bo ? Theme.TEXT : Theme.MUTED, a), true);
		regions.add(new Region(x + 14, y + PH - 20, 60, 16, b -> onClose()));
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		for (int i = regions.size() - 1; i >= 0; i--) {
			Region r = regions.get(i);
			if (r.has(e.x(), e.y())) {
				r.click().accept(e.button());
				return true;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean keyReleased(KeyEvent e) {
		int k = e.key();
		if (k == GLFW.GLFW_KEY_LEFT_CONTROL || k == GLFW.GLFW_KEY_RIGHT_CONTROL) ctrl = false;
		return super.keyReleased(e);
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		int k = e.key();
		if (k == GLFW.GLFW_KEY_LEFT_CONTROL || k == GLFW.GLFW_KEY_RIGHT_CONTROL) {
			ctrl = true;
			return true;
		}
		if (k == GLFW.GLFW_KEY_ESCAPE) {
			onClose();
			return true;
		}
		if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) {
			submit();
			return true;
		}
		if (k == GLFW.GLFW_KEY_BACKSPACE) {
			if (!input.isEmpty()) input = input.substring(0, input.length() - 1);
			return true;
		}
		if (ctrl && k == GLFW.GLFW_KEY_V) {
			String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
			if (clip != null) {
				StringBuilder sb = new StringBuilder();
				for (char c : clip.toCharArray()) if (Character.isLetterOrDigit(c) || c == '-') sb.append(Character.toUpperCase(c));
				input = sb.length() > 40 ? sb.substring(0, 40) : sb.toString();
			}
			return true;
		}
		if (input.length() < 40) {
			if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) {
				input += (char) ('A' + (k - GLFW.GLFW_KEY_A));
				return true;
			}
			if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) {
				input += (char) ('0' + (k - GLFW.GLFW_KEY_0));
				return true;
			}
			if (k == GLFW.GLFW_KEY_MINUS) {
				input += '-';
				return true;
			}
		}
		return super.keyPressed(e);
	}
}
