package dev.nexora.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;

import dev.nexora.core.Theme;
import dev.nexora.feature.License;
import dev.nexora.feature.Social;
import dev.nexora.util.Anim;
import dev.nexora.util.Draw;
import dev.nexora.util.Lang;
import dev.nexora.util.TypeIn;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/** Профиль и друзья: имя, код дружбы, о себе, статус, цвет; список друзей с онлайн-статусом; заявки. */
public final class SocialScreen extends Screen {
	private static final int PW = 430, PH = 280, SB = 104;
	private static final int[] COLORS = {0xFF4C8DFF, 0xFF38F2B2, 0xFFA78BFA, 0xFFFB7185, 0xFFF59E0B, 0xFFE879F9, 0xFF7FD6FF, 0xFFE5E7EB};
	private static final String[] TABS = {"Profile", "Friends", "Add friend"};

	private record Region(float x, float y, float w, float h, IntConsumer click) {
		boolean has(double px, double py) {
			return px >= x && px <= x + w && py >= y && py <= y + h;
		}
	}

	private final Screen parent;
	private final Anim.Timer timer = new Anim.Timer();
	private final List<Region> regions = new ArrayList<>();
	private int tab, focus; // focus: 0 нет, 1 основное поле, 2 «о себе», 3 статус
	private String nameBuf = "", targetBuf = "", selected = "";
	private boolean shift, ctrl;
	private float t;

	public SocialScreen(Screen parent) {
		super(Component.literal("Social"));
		this.parent = parent;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}

	private static String where(Social.Friend f) {
		if (!f.online()) return Lang.t("Offline");
		String w = f.where() == null ? "" : f.where();
		return switch (w) {
			case "Menu" -> Lang.t("In menu");
			case "Singleplayer" -> Lang.t("Singleplayer");
			case "Multiplayer", "" -> Lang.t("Multiplayer");
			default -> w;
		};
	}

	private void avatar(GuiGraphics g, float cx, float cy, float size, int color, String name, float a) {
		Draw.glow(g, cx, cy, size * 1.9f, Draw.a(color, 0.35f * a));
		Draw.rounded(g, cx - size / 2f, cy - size / 2f, size, size, Math.min(16, (int) (size / 2)), Draw.a(color, a));
		String ch = name == null || name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
		float s = size / 18f;
		Draw.text(g, ch, cx - Draw.width(ch) * s / 2f, cy - 4f * s, s, Draw.a(0xFF0B0B10, a), false);
	}

	private void pill(GuiGraphics g, float x, float y, float w, String label, float a, int mx, int my, IntConsumer click) {
		boolean over = mx >= x && mx <= x + w && my >= y && my <= y + 18;
		Draw.rounded(g, x, y, w, 18, 7, Draw.a(Theme.accent(), (over ? 0.5f : 0.3f) * a));
		Draw.text(g, label, x + (w - Draw.width(label) * 0.85f) / 2f, y + 5, 0.85f, Draw.a(Theme.TEXT, a), false);
		regions.add(new Region(x, y, w, 18, click));
	}

	private void input(GuiGraphics g, float x, float y, float w, String text, String hint, boolean focused, int id, float a) {
		Draw.rounded(g, x, y, w, 20, 7, Draw.a(focused ? 0x2EFFFFFF : 0x16FFFFFF, a));
		if (focused) Draw.border(g, Math.round(x), Math.round(y), Math.round(w), 20, 7, Draw.a(Theme.accent(), 0.6f * a));
		boolean caret = focused && (System.currentTimeMillis() / 500) % 2 == 0;
		String shown = text.isEmpty() ? hint : Draw.clip(text, (int) w - 16);
		Draw.text(g, shown + (!text.isEmpty() && caret ? "|" : ""), x + 7, y + 6, Draw.a(text.isEmpty() ? Theme.MUTED : Theme.TEXT, a));
		regions.add(new Region(x, y, w, 20, b -> focus = id));
	}

	private void toggle(GuiGraphics g, float x, float y, String label, boolean on, float a, Runnable flip) {
		Draw.text(g, label, x, y + 2, Draw.a(Theme.MUTED, a));
		float sx = x + 150;
		Draw.rounded(g, sx, y, 26, 12, 6, Draw.a(Draw.lerp(0x40FFFFFF, Theme.accent(), on ? 1f : 0f), a));
		Draw.rounded(g, sx + (on ? 14 : 2), y + 2, 8, 8, 4, Draw.a(0xFFFFFFFF, a));
		regions.add(new Region(x, y - 2, 180, 16, b -> flip.run()));
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		float d = timer.tick();
		Anim.dt = d;
		t = Math.min(1f, t + d / 0.28f);
		float a = Anim.smooth(Mth.clamp(t * 1.6f, 0f, 1f));
		g.fillGradient(0, 0, width, height, Draw.a(0xFF04060D, 0.94f * a), Draw.a(0xFF0A1226, 0.94f * a));
		regions.clear();

		float x = (width - PW) / 2f, y = (height - PH) / 2f + (1f - Anim.easeOut(t)) * 14f;
		Draw.shadow(g, x, y, PW, PH, 10, a);
		Draw.glass(g, x, y, PW, PH, 10, Math.min(1f, a * 1.2f));
		Draw.sheen(g, x, y, PW, PH, a);
		Draw.rounded(g, x + 7, y + 7, SB - 7, PH - 14, 8, Draw.a(0x55000000, a));
		Draw.text(g, Lang.t("Profile"), x + 18, y + 14, 1.2f, Draw.a(Theme.TEXT, a), true);

		for (int i = 0; i < TABS.length; i++) {
			float ty = y + 40 + i * 26;
			boolean sel = tab == i;
			boolean hov = mx >= x + 11 && mx <= x + SB - 4 && my >= ty && my <= ty + 22;
			if (sel) {
				Draw.rounded(g, x + 11, ty, SB - 15, 22, 7, Draw.a(0x1CFFFFFF, a));
				g.fill(Math.round(x) + 11, Math.round(ty) + 5, Math.round(x) + 13, Math.round(ty) + 17, Draw.a(Theme.accent(), a));
			}
			int ci = i;
			String label = Lang.t(TABS[i]);
			if (i == 2 && !Social.incoming.isEmpty()) label += " (" + Social.incoming.size() + ")";
			Draw.text(g, label, x + 24, ty + 7, Draw.a(sel ? Theme.TEXT : hov ? 0xFFD5D5E4 : Theme.MUTED, a));
			regions.add(new Region(x + 11, ty, SB - 15, 22, b -> {
				tab = ci;
				focus = 0;
			}));
		}
		boolean bo = mx >= x + 11 && mx <= x + SB - 4 && my >= y + PH - 30 && my <= y + PH - 10;
		Draw.text(g, "< " + Lang.t("Back"), x + 18, y + PH - 26, 0.85f, Draw.a(bo ? Theme.TEXT : Theme.MUTED, a), true);
		regions.add(new Region(x + 11, y + PH - 30, SB - 15, 20, b -> onClose()));

		float cx = x + SB + 14, cw = PW - SB - 28, cy = y + 16;

		if (!License.active()) {
			Draw.text(g, Lang.t("Activate Nexora to use profiles"), cx, cy + 20, Draw.a(Theme.TEXT, a));
			pill(g, cx, cy + 46, 120, Lang.t("Activate"), a, mx, my, b -> Minecraft.getInstance().setScreen(new ActivationScreen(this)));
			return;
		}

		// статусная строка
		String stat = !Social.configured() ? Lang.t("Social server is not set") + ": .social server <url>"
			: Social.busy ? "..." : Lang.t(Social.message);
		Draw.text(g, Draw.clip(stat, (int) (cw / 0.75f)), cx, y + PH - 22, 0.75f, Draw.a(Social.configured() ? Theme.MUTED : Theme.WARN, a), false);

		switch (tab) {
			case 0 -> profileTab(g, cx, cy, cw, a, mx, my);
			case 1 -> friendsTab(g, cx, cy, cw, a, mx, my);
			default -> addTab(g, cx, cy, cw, a, mx, my);
		}
	}

	private void profileTab(GuiGraphics g, float x, float y, float w, float a, int mx, int my) {
		if (!Social.registered()) {
			Draw.text(g, Lang.t("Create profile"), x, y + 2, 1.2f, Draw.a(Theme.TEXT, a), true);
			Draw.text(g, Lang.t("Nickname: 3-16 chars, A-Z 0-9 _"), x, y + 24, 0.75f, Draw.a(Theme.MUTED, a), false);
			input(g, x, y + 44, w - 90, nameBuf, Lang.t("Username"), focus == 1, 1, a);
			pill(g, x + w - 80, y + 45, 80, Lang.t("Create"), a, mx, my, b -> createProfile());
			return;
		}
		avatar(g, x + 22, y + 24, 36, COLORS[Social.color % COLORS.length], Social.username, a);
		Draw.text(g, Social.username, x + 52, y + 8, 1.3f, Draw.a(Theme.TEXT, a), true);
		Draw.text(g, Lang.t("Friend code") + ": " + Social.code, x + 52, y + 27, 0.85f, Draw.a(Theme.MUTED, a), false);
		pill(g, x + w - 70, y + 20, 70, Lang.t("Copy"), a, mx, my, b -> Minecraft.getInstance().keyboardHandler.setClipboard(Social.code));

		Draw.text(g, Lang.t("Bio"), x, y + 58, 0.8f, Draw.a(Theme.MUTED, a), false);
		input(g, x, y + 70, w, Social.bio, "...", focus == 2, 2, a);
		Draw.text(g, Lang.t("Status"), x, y + 98, 0.8f, Draw.a(Theme.MUTED, a), false);
		input(g, x, y + 110, w, Social.statusText, "...", focus == 3, 3, a);

		for (int i = 0; i < COLORS.length; i++) {
			float sx = x + i * 24 + 9, sy = y + 148;
			boolean sel = Social.color == i;
			if (sel) Draw.glow(g, sx, sy, 30, Draw.a(COLORS[i], 0.6f * a));
			Draw.rounded(g, sx - 8, sy - 8, 16, 16, 8, Draw.a(COLORS[i], a));
			if (sel) Draw.border(g, Math.round(sx) - 9, Math.round(sy) - 9, 18, 18, 8, Draw.a(0xFFFFFFFF, 0.9f * a));
			int ci = i;
			regions.add(new Region(sx - 9, sy - 9, 18, 18, b -> {
				Social.color = ci;
				Social.saveProfile();
			}));
		}
		toggle(g, x, y + 176, Lang.t("Appear offline"), Social.appearOffline, a, () -> {
			Social.appearOffline = !Social.appearOffline;
			Social.saveProfile();
		});
		toggle(g, x, y + 196, Lang.t("Show my server"), Social.showServer, a, () -> {
			Social.showServer = !Social.showServer;
			Social.saveProfile();
		});
	}

	private void friendsTab(GuiGraphics g, float x, float y, float w, float a, int mx, int my) {
		var list = new ArrayList<>(Social.friends);
		list.sort((p, q) -> p.online() != q.online() ? (p.online() ? -1 : 1) : p.name().compareToIgnoreCase(q.name()));
		float lw = w * 0.52f;
		if (list.isEmpty()) {
			Draw.text(g, Lang.t("No friends yet"), x, y + 4, Draw.a(Theme.MUTED, a));
			return;
		}
		Social.Friend sel = null;
		for (int i = 0; i < list.size() && i < 8; i++) {
			var f = list.get(i);
			float ry = y + i * 30;
			boolean isSel = f.name().equals(selected);
			if (isSel) sel = f;
			boolean hov = mx >= x && mx <= x + lw && my >= ry && my <= ry + 26;
			Draw.rounded(g, x, ry, lw, 26, 8, Draw.a(isSel ? 0x2AFFFFFF : hov ? 0x1EFFFFFF : 0x12FFFFFF, a));
			avatar(g, x + 16, ry + 13, 18, COLORS[f.color() % COLORS.length], f.name(), a);
			Draw.text(g, f.name(), x + 32, ry + 4, Draw.a(Theme.TEXT, a));
			Draw.text(g, Draw.clip(where(f), (int) ((lw - 50) / 0.72f)), x + 32, ry + 15, 0.72f, Draw.a(f.online() ? Theme.GOOD : Theme.MUTED, a), false);
			Draw.rounded(g, x + lw - 12, ry + 10, 6, 6, 3, Draw.a(f.online() ? Theme.GOOD : 0xFF5B6475, a));
			String nm = f.name();
			regions.add(new Region(x, ry, lw, 26, b -> selected = nm));
		}
		if (sel == null) sel = list.get(0);

		float dx = x + lw + 12, dw = w - lw - 12;
		avatar(g, dx + 20, y + 24, 36, COLORS[sel.color() % COLORS.length], sel.name(), a);
		Draw.text(g, sel.name(), dx + 48, y + 10, 1.1f, Draw.a(Theme.TEXT, a), true);
		Draw.text(g, where(sel), dx + 48, y + 26, 0.8f, Draw.a(sel.online() ? Theme.GOOD : Theme.MUTED, a), false);
		Draw.text(g, Lang.t("Friend code") + ": " + sel.code(), dx, y + 52, 0.78f, Draw.a(Theme.MUTED, a), false);
		if (!sel.status().isEmpty()) Draw.text(g, Draw.clip(sel.status(), (int) (dw / 0.85f)), dx, y + 68, 0.85f, Draw.a(Theme.accent(), a), false);
		if (!sel.bio().isEmpty()) Draw.text(g, Draw.clip(sel.bio(), (int) (dw / 0.8f)), dx, y + 84, 0.8f, Draw.a(Theme.TEXT, a), false);
		String nm = sel.name();
		pill(g, dx, y + 110, 90, Lang.t("Remove"), a, mx, my, b -> {
			Social.remove(nm);
			selected = "";
		});
	}

	private void addTab(GuiGraphics g, float x, float y, float w, float a, int mx, int my) {
		Draw.text(g, Lang.t("Add friend"), x, y + 2, 1.2f, Draw.a(Theme.TEXT, a), true);
		Draw.text(g, Lang.t("Username or friend code"), x, y + 24, 0.75f, Draw.a(Theme.MUTED, a), false);
		input(g, x, y + 40, w - 120, targetBuf, "NX-XXXXXXXX", focus == 1, 1, a);
		pill(g, x + w - 110, y + 41, 110, Lang.t("Send request"), a, mx, my, b -> sendTarget());

		float cy = y + 76;
		Draw.text(g, Lang.t("Requests"), x, cy, 0.85f, Draw.a(Theme.MUTED, a), false);
		cy += 14;
		if (Social.incoming.isEmpty()) {
			Draw.text(g, Lang.t("No requests"), x, cy + 2, 0.85f, Draw.a(0xFF5B6475, a), false);
		}
		for (String n : new ArrayList<>(Social.incoming)) {
			if (cy > y + 200) break;
			Draw.rounded(g, x, cy, w, 24, 8, Draw.a(0x14FFFFFF, a));
			Draw.text(g, n, x + 10, cy + 8, Draw.a(Theme.TEXT, a));
			pill(g, x + w - 150, cy + 3, 70, Lang.t("Accept"), a, mx, my, b -> Social.respond(n, true));
			pill(g, x + w - 76, cy + 3, 70, Lang.t("Decline"), a, mx, my, b -> Social.respond(n, false));
			cy += 28;
		}
		if (!Social.outgoing.isEmpty()) {
			Draw.text(g, Lang.t("Sent") + ": " + String.join(", ", Social.outgoing), x, Math.min(cy + 6, y + 214), 0.75f, Draw.a(Theme.MUTED, a), false);
		}
	}

	private void createProfile() {
		if (nameBuf.matches("[A-Za-z0-9_]{3,16}")) {
			Social.register(nameBuf);
			nameBuf = "";
		} else {
			Social.message = "Nickname: 3-16 chars, A-Z 0-9 _";
		}
	}

	private void sendTarget() {
		if (!targetBuf.isBlank()) {
			Social.sendRequest(targetBuf);
			targetBuf = "";
		}
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		focus = 0;
		for (int i = regions.size() - 1; i >= 0; i--) {
			Region r = regions.get(i);
			if (r.has(e.x(), e.y())) {
				r.click().accept(e.button());
				return true;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean keyReleased(KeyEvent e) {
		int k = e.key();
		if (k == GLFW.GLFW_KEY_LEFT_SHIFT || k == GLFW.GLFW_KEY_RIGHT_SHIFT) shift = false;
		if (k == GLFW.GLFW_KEY_LEFT_CONTROL || k == GLFW.GLFW_KEY_RIGHT_CONTROL) ctrl = false;
		return super.keyReleased(e);
	}

	private String current() {
		if (focus == 2) return Social.bio;
		if (focus == 3) return Social.statusText;
		if (tab == 0) return nameBuf;
		return targetBuf;
	}

	private void set(String v) {
		if (focus == 2) Social.bio = v;
		else if (focus == 3) Social.statusText = v;
		else if (tab == 0) nameBuf = v;
		else targetBuf = v;
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		int k = e.key();
		if (k == GLFW.GLFW_KEY_LEFT_SHIFT || k == GLFW.GLFW_KEY_RIGHT_SHIFT) {
			shift = true;
			return true;
		}
		if (k == GLFW.GLFW_KEY_LEFT_CONTROL || k == GLFW.GLFW_KEY_RIGHT_CONTROL) {
			ctrl = true;
			return true;
		}
		if (k == GLFW.GLFW_KEY_ESCAPE) {
			if (focus != 0) {
				if (focus >= 2) Social.saveProfile();
				focus = 0;
			} else {
				onClose();
			}
			return true;
		}
		if (focus == 0) return super.keyPressed(e);

		if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) {
			if (focus >= 2) Social.saveProfile();
			else if (tab == 0) createProfile();
			else sendTarget();
			if (focus >= 2) focus = 0;
			return true;
		}
		String cur = current();
		int max = focus == 2 ? 120 : focus == 3 ? 40 : 24;
		if (k == GLFW.GLFW_KEY_BACKSPACE) {
			if (!cur.isEmpty()) set(cur.substring(0, cur.length() - 1));
			return true;
		}
		if (ctrl && k == GLFW.GLFW_KEY_V) {
			String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
			if (clip != null) {
				StringBuilder sb = new StringBuilder(cur);
				for (char c : clip.toCharArray()) if (sb.length() < max && c >= 32 && c < 127) sb.append(c);
				set(sb.toString());
			}
			return true;
		}
		char c = TypeIn.of(k, shift);
		if (c != 0 && cur.length() < max) set(cur + c);
		return true;
	}
}
