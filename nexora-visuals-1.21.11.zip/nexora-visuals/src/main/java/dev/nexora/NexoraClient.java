package dev.nexora;

import java.util.Locale;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nexora.core.Config;
import dev.nexora.core.Module;
import dev.nexora.core.Modules;
import dev.nexora.feature.Accounts;
import dev.nexora.feature.Commands;
import dev.nexora.feature.ElytraHelper;
import dev.nexora.feature.EventDetector;
import dev.nexora.feature.Gps;
import dev.nexora.feature.License;
import dev.nexora.feature.Optimization;
import dev.nexora.feature.SessionStats;
import dev.nexora.feature.Social;
import dev.nexora.feature.Waypoints;
import dev.nexora.gui.ActivationScreen;
import dev.nexora.gui.MenuScreen;
import dev.nexora.hud.HudRenderer;
import dev.nexora.visual.BrewHelper;
import dev.nexora.visual.Fullbright;
import dev.nexora.visual.HitSound;
import dev.nexora.visual.JumpCircles;
import dev.nexora.visual.LightOverlay;
import dev.nexora.visual.ParticleFx;
import dev.nexora.visual.Zoom;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.inventory.BrewingStandScreen;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class NexoraClient implements ClientModInitializer {
	public static final String ID = "nexora";
	public static KeyMapping OPEN_MENU;

	public static String slug(String name) {
		return name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
	}

	private static KeyMapping key(String id, int code, KeyMapping.Category cat) {
		return KeyBindingHelper.registerKeyBinding(new KeyMapping(id, InputConstants.Type.KEYSYM, code, cat));
	}

	@Override
	public void onInitializeClient() {
		Config.load();
		License.load();
		Social.load();
		Accounts.load();
		Accounts.applyOnStart();

		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));
		OPEN_MENU = key("key.nexora.open_menu", GLFW.GLFW_KEY_RIGHT_SHIFT, category);
		ElytraHelper.SWAP = key("key.nexora.elytra_swap", GLFW.GLFW_KEY_UNKNOWN, category);
		ElytraHelper.FIREWORK = key("key.nexora.elytra_firework", GLFW.GLFW_KEY_UNKNOWN, category);
		Zoom.KEY = key("key.nexora.zoom", GLFW.GLFW_KEY_C, category);
		// отдельная (по умолчанию не назначенная) клавиша на каждый модуль: Управление или .bind add
		for (Module m : Modules.ALL) {
			if (m.toggleable) m.key = key("key.nexora.mod." + slug(m.name), GLFW.GLFW_KEY_UNKNOWN, category);
		}

		HudRenderer.init();

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			boolean active = License.active();
			while (OPEN_MENU.consumeClick()) {
				if (mc.level != null && mc.screen == null) {
					mc.setScreen(active ? new MenuScreen() : new ActivationScreen(null));
				}
			}
			if (!active) {
				Fullbright.restore(mc);
				Optimization.restore(mc);
				Zoom.restore(mc);
				return;
			}
			for (Module m : Modules.ALL) {
				if (m.key == null) continue;
				while (m.key.consumeClick()) {
					if (mc.screen == null && mc.level != null) m.toggle();
				}
			}
			ElytraHelper.tick(mc);
			Fullbright.tick(mc);
			ParticleFx.tick(mc);
			HitSound.tick(mc);
			Gps.tick(mc);
			Waypoints.tick(mc);
			Zoom.tick(mc);
			JumpCircles.tick(mc);
			LightOverlay.tick(mc);
			Optimization.tick(mc);
			SessionStats.tick(mc);
			Social.tick(mc);
		});

		// Команды клиента (.gps, .cfg, .key ...) не уходят на сервер
		ClientSendMessageEvents.ALLOW_CHAT.register(message -> !Commands.handle(message));

		// Авто-метка на ивенты из чата
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
			if (!overlay) EventDetector.onMessage(message.getString());
		});
		ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, timestamp) ->
			EventDetector.onMessage(message.getString()));

		// Шпаргалка рядом с варочной стойкой
		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
			if (screen instanceof BrewingStandScreen) {
				ScreenEvents.afterRender(screen).register((s, gg, mx, my, td) -> BrewHelper.render(gg, s.width, s.height));
			}
		});

		ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
			Fullbright.restore(mc);
			Zoom.restore(mc);
			Optimization.restore(mc);
			Config.save();
		});
	}
}
