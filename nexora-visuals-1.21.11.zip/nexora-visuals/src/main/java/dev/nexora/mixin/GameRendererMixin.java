package dev.nexora.mixin;

import dev.nexora.visual.AspectRatio;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Aspect ratio: подправляет матрицу проекции. Необязательный миксин: если сигнатура другая, функция просто не работает. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

	@Inject(method = "getProjectionMatrix", at = @At("RETURN"), cancellable = true)
	private void nexora$aspect(float fov, CallbackInfoReturnable<Matrix4f> cir) {
		var win = Minecraft.getInstance().getWindow();
		float window = (float) win.getGuiScaledWidth() / Math.max(1, win.getGuiScaledHeight());
		float target = AspectRatio.apply(window);
		if (Math.abs(target - window) < 0.001f) return;
		Matrix4f m = cir.getReturnValue();
		m.m00(m.m00() * window / target);
		cir.setReturnValue(m);
	}
}
