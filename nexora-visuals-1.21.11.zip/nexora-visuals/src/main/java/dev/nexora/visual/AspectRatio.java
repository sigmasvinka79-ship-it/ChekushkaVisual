package dev.nexora.visual;

import dev.nexora.core.Modules;
import dev.nexora.feature.License;

/** Целевое соотношение сторон картинки (используется миксином проекции и расчётом меток). */
public final class AspectRatio {
	private AspectRatio() {}

	public static float apply(float window) {
		if (!Modules.ASPECT.enabled || !License.active()) return window;
		return switch (Modules.AS_RATIO.mode) {
			case 1 -> 4f / 3f;
			case 2 -> 5f / 4f;
			case 3 -> 16f / 10f;
			case 4 -> 1f;
			case 5 -> 21f / 9f;
			case 6 -> 32f / 9f;
			case 7 -> Modules.AS_CUSTOM.f();
			default -> window;
		};
	}
}
