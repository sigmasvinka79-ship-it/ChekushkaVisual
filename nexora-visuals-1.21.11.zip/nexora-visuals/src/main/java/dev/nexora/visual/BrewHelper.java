package dev.nexora.visual;

import dev.nexora.core.Modules;
import dev.nexora.core.Theme;
import dev.nexora.util.Draw;
import dev.nexora.util.Lang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.joml.Matrix3x2fStack;

/** Шпаргалка по зельеварению, рисуется рядом с варочной стойкой. */
public final class BrewHelper {
	private static final Object[][] ROWS = {
		{Items.NETHER_WART, "Nether Wart", "Awkward base"},
		{Items.SUGAR, "Sugar", "Speed"},
		{Items.RABBIT_FOOT, "Rabbit Foot", "Leaping"},
		{Items.GLISTERING_MELON_SLICE, "Glistering Melon", "Healing"},
		{Items.SPIDER_EYE, "Spider Eye", "Poison"},
		{Items.PUFFERFISH, "Pufferfish", "Water Breathing"},
		{Items.MAGMA_CREAM, "Magma Cream", "Fire Resistance"},
		{Items.GOLDEN_CARROT, "Golden Carrot", "Night Vision"},
		{Items.BLAZE_POWDER, "Blaze Powder", "Strength"},
		{Items.GHAST_TEAR, "Ghast Tear", "Regeneration"},
		{Items.TURTLE_HELMET, "Turtle Helmet", "Turtle Master"},
		{Items.PHANTOM_MEMBRANE, "Phantom Membrane", "Slow Falling"},
		{Items.FERMENTED_SPIDER_EYE, "Fermented Eye", "Corrupts the potion"},
		{Items.REDSTONE, "Redstone", "Longer duration"},
		{Items.GLOWSTONE_DUST, "Glowstone", "Stronger (II)"},
		{Items.GUNPOWDER, "Gunpowder", "Splash potion"},
		{Items.DRAGON_BREATH, "Dragon's Breath", "Lingering potion"}
	};
	private static ItemStack[] icons;

	private BrewHelper() {}

	public static void render(GuiGraphics g, int sw, int sh) {
		if (!Modules.BREW.enabled || !dev.nexora.feature.License.active()) return;
		if (icons == null) {
			icons = new ItemStack[ROWS.length];
			for (int i = 0; i < ROWS.length; i++) icons[i] = new ItemStack((net.minecraft.world.item.Item) ROWS[i][0]);
		}
		boolean showIcons = Modules.BR_ICONS.bool;
		float rowH = showIcons ? 17f : 13f;
		float w = 196f, h = 26f + ROWS.length * rowH;
		float scale = Math.min(1f, (sh - 12f) / h);
		float x = Math.min(sw - w * scale - 6f, sw / 2f + 100f);
		float y = Math.max(6f, (sh - h * scale) / 2f);
		if (x < 4f) x = 4f;

		Matrix3x2fStack ps = g.pose();
		ps.pushMatrix();
		ps.translate(x, y);
		ps.scale(scale, scale);
		Draw.panel(g, 0, 0, w, h, 1f);
		Draw.text(g, Lang.t("Brew helper"), 10, 7, Theme.TEXT);
		Draw.text(g, Lang.t("Water bottle + Nether Wart = Awkward, then add ingredient"), 10, 17, 0.62f, Theme.MUTED, false);
		for (int i = 0; i < ROWS.length; i++) {
			float ry = 28f + i * rowH;
			if (showIcons) g.renderItem(icons[i], 8, Math.round(ry));
			float tx = showIcons ? 28f : 10f;
			Draw.text(g, Lang.t((String) ROWS[i][1]), tx, ry + (showIcons ? 4 : 1), 0.85f, Theme.TEXT, false);
			String eff = Lang.t((String) ROWS[i][2]);
			Draw.textRight(g, eff, w - 10, ry + (showIcons ? 4 : 1), 0.85f, Draw.lerp(Theme.accent(), Theme.accent2(), i / (float) ROWS.length));
		}
		ps.popMatrix();
	}
}
