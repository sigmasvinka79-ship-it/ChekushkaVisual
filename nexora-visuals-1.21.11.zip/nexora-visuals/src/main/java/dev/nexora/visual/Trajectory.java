package dev.nexora.visual;

import java.util.Locale;

import dev.nexora.core.Modules;
import dev.nexora.core.Theme;
import dev.nexora.util.Draw;
import dev.nexora.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Траектория того, что ты собираешься бросить или выстрелить: снежки, яйца, эндер-жемчуг, зелья,
 * пузырьки опыта, трезубец, лук, арбалет. Считается по физике игры, проверяются только блоки.
 */
public final class Trajectory {
	private static final int MAX = 150;
	private static final double[] PX = new double[MAX + 1], PY = new double[MAX + 1], PZ = new double[MAX + 1];
	private static final float[] P = new float[3];

	private Trajectory() {}

	/** {скорость, гравитация, сдвиг угла} или null. */
	private static double[] spec(LocalPlayer p) {
		ItemStack[] hands = {p.getMainHandItem(), p.getOffhandItem()};
		for (ItemStack st : hands) {
			if (st.isEmpty()) continue;
			if (st.is(Items.SNOWBALL) || st.is(Items.EGG) || st.is(Items.ENDER_PEARL)) return new double[] {1.5, 0.03, 0};
			if (Modules.TJ_POTION.bool && (st.is(Items.SPLASH_POTION) || st.is(Items.LINGERING_POTION))) return new double[] {0.5, 0.05, -20};
			if (st.is(Items.EXPERIENCE_BOTTLE)) return new double[] {0.7, 0.07, -20};
			if (st.is(Items.TRIDENT)) return new double[] {2.5, 0.05, 0};
			if (Modules.TJ_BOW.bool) {
				if (st.is(Items.BOW) && p.isUsingItem() && p.getUseItem().is(Items.BOW)) {
					float f = p.getTicksUsingItem() / 20f;
					f = (f * f + f * 2f) / 3f;
					if (f < 0.1f) return null;
					return new double[] {Math.min(1f, f) * 3.0, 0.05, 0};
				}
				if (st.is(Items.CROSSBOW) && !p.isUsingItem()) return new double[] {3.15, 0.05, 0};
			}
		}
		return null;
	}

	public static void render(GuiGraphics g, float pt) {
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (!Modules.TRAJ.enabled || !Proj.ready || p == null || mc.level == null) return;
		double[] sp = spec(p);
		if (sp == null) return;

		double yaw = Math.toRadians(p.getViewYRot(pt));
		double pitch = Math.toRadians(p.getViewXRot(pt));
		double vx = -Math.sin(yaw) * Math.cos(pitch);
		double vy = -Math.sin(Math.toRadians(p.getViewXRot(pt) + sp[2]));
		double vz = Math.cos(yaw) * Math.cos(pitch);
		double len = Math.sqrt(vx * vx + vy * vy + vz * vz);
		vx = vx / len * sp[0];
		vy = vy / len * sp[0];
		vz = vz / len * sp[0];
		Vec3 dm = p.getDeltaMovement();
		vx += dm.x;
		vz += dm.z;
		if (!p.onGround()) vy += dm.y;

		Vec3 eye = p.getEyePosition(pt);
		double x = eye.x, y = eye.y - 0.1, z = eye.z;
		int n = 0;
		boolean landed = false;
		for (int i = 0; i < MAX; i++) {
			double nx = x + vx, ny = y + vy, nz = z + vz;
			BlockHitResult hit = mc.level.clip(new ClipContext(new Vec3(x, y, z), new Vec3(nx, ny, nz),
				ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
			if (hit.getType() != HitResult.Type.MISS) {
				Vec3 l = hit.getLocation();
				PX[n] = l.x;
				PY[n] = l.y;
				PZ[n] = l.z;
				n++;
				landed = true;
				break;
			}
			PX[n] = nx;
			PY[n] = ny;
			PZ[n] = nz;
			n++;
			x = nx;
			y = ny;
			z = nz;
			vx *= 0.99;
			vy = vy * 0.99 - sp[1];
			vz *= 0.99;
			if (ny < -80) break;
		}
		if (n < 2) return;

		int c1 = Theme.accent(), c2 = Theme.accent2();
		boolean line = Modules.TJ_STYLE.mode == 1;
		int step = line ? 1 : 2;
		for (int i = 2; i < n; i += step) {
			if (!Proj.to(PX[i], PY[i], PZ[i], P)) continue;
			float f = i / (float) n;
			float al = Math.min(1f, i / 8f) * (0.95f - 0.45f * f);
			float px = Math.min(0.045f * Proj.scale(P[2]), 7f);
			if (px < 0.8f) continue;
			int col = Draw.lerp(c1, c2, f);
			if (!line) Draw.glow(g, P[0], P[1], px * 3f, Draw.a(col, al * 0.25f));
			Draw.glow(g, P[0], P[1], px * (line ? 2.2f : 1.5f), Draw.a(Draw.lerp(col, 0xFFFFFFFF, 0.4f), al));
		}

		if (landed && Modules.TJ_MARK.bool) {
			double lx = PX[n - 1], ly = PY[n - 1], lz = PZ[n - 1];
			for (int i = 0; i < 12; i++) {
				float ang = i * Mth.TWO_PI / 12f;
				if (!Proj.to(lx + Mth.cos(ang) * 0.28, ly + 0.03, lz + Mth.sin(ang) * 0.28, P)) continue;
				float px = Math.min(0.06f * Proj.scale(P[2]), 9f);
				Draw.glow(g, P[0], P[1], px * 2.4f, Draw.a(c2, 0.95f));
			}
			if (Modules.TJ_DIST.bool && Proj.to(lx, ly + 0.3, lz, P)) {
				String d = String.format(Locale.ROOT, "%.1fm", Math.sqrt((lx - eye.x) * (lx - eye.x) + (lz - eye.z) * (lz - eye.z)));
				Draw.text(g, d, P[0] - Draw.width(d) * 0.85f / 2f, P[1] - 10, 0.85f, Draw.a(Theme.TEXT, 0.95f), true);
			}
		}
	}
}
