package dev.nexora.visual;

import java.util.ArrayList;
import java.util.List;

import dev.nexora.core.Modules;
import dev.nexora.util.Poly;
import dev.nexora.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LightLayer;

/** Подсвечивает красным клетки, где могут появиться враждебные мобы (уровень света блоков = 0). */
public final class LightOverlay {
	private static final List<int[]> CELLS = new ArrayList<>();
	private static final float[] P = new float[3];
	private static final float[] XS = new float[4], YS = new float[4];
	private static int counter;

	private LightOverlay() {}

	public static void tick(Minecraft mc) {
		if (!Modules.LIGHT.enabled || mc.level == null || mc.player == null) {
			CELLS.clear();
			return;
		}
		if (++counter % 8 != 0) return;
		int r = Modules.LV_RADIUS.i();
		BlockPos base = mc.player.blockPosition();
		CELLS.clear();
		for (int dx = -r; dx <= r; dx++) {
			for (int dz = -r; dz <= r; dz++) {
				int x = base.getX() + dx, z = base.getZ() + dz;
				for (int y = base.getY() + 1; y >= base.getY() - 3; y--) {
					BlockPos pos = new BlockPos(x, y, z);
					if (mc.level.getBlockState(pos).isAir() && !mc.level.getBlockState(pos.below()).isAir()) {
						if (mc.level.getBrightness(LightLayer.BLOCK, pos) == 0) CELLS.add(new int[] {x, y, z});
						break;
					}
				}
			}
		}
	}

	public static void render(GuiGraphics g) {
		if (!Modules.LIGHT.enabled || !Proj.ready || CELLS.isEmpty()) return;
		int a = Math.round(Modules.LV_ALPHA.f() * 255f);
		int col = (a << 24) | 0xFF2A2A;
		for (int[] c : CELLS) {
			boolean ok = true;
			for (int i = 0; i < 4; i++) {
				double px = c[0] + ((i & 1) == 0 ? 0.08 : 0.92), pz = c[2] + ((i & 2) == 0 ? 0.08 : 0.92);
				if (!Proj.to(px, c[1] + 0.02, pz, P)) {
					ok = false;
					break;
				}
				XS[i] = P[0];
				YS[i] = P[1];
			}
			if (!ok) continue;
			// порядок обхода: 0,1,3,2
			float[] qx = {XS[0], XS[1], XS[3], XS[2]}, qy = {YS[0], YS[1], YS[3], YS[2]};
			Poly.fill(g, qx, qy, 4, col, col);
		}
	}
}
