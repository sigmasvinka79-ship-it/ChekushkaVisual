package dev.nexora.feature;

import dev.nexora.core.Modules;
import dev.nexora.util.Stats;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.server.level.ParticleStatus;

/**
 * Optimization «одной кнопкой»: включил, и клиент сам ставит «дешёвые» настройки, почти не меняющие картинку.
 * Light: тени существ, облака, смешивание биомов. Balanced: + меньше частиц, без VSync и лимита FPS.
 * Max: + меньшая дальность прорисовки существ. Исходные значения запоминаются и возвращаются при выключении.
 * Адаптивное качество упрощает эффекты мода, если FPS упал.
 */
public final class Optimization {
	private static boolean saved, applied;
	private static boolean sShadows, sVsync;
	private static CloudStatus sClouds;
	private static int sBiome, sFps;
	private static ParticleStatus sParticles;
	private static double sEntityDist;

	private Optimization() {}

	/** true, когда эффектам мода стоит упростить отрисовку. */
	public static boolean low() {
		return Modules.OPTIMIZATION.enabled && Modules.OP_ADAPT.bool && Stats.fps > 0 && Stats.fps < 50;
	}

	private static <T> void put(OptionInstance<T> o, T v) {
		if (!o.get().equals(v)) o.set(v);
	}

	private static void save(Minecraft mc) {
		var o = mc.options;
		sShadows = o.entityShadows().get();
		sClouds = o.cloudStatus().get();
		sBiome = o.biomeBlendRadius().get();
		sParticles = o.particles().get();
		sVsync = o.enableVsync().get();
		sFps = o.framerateLimit().get();
		sEntityDist = o.entityDistanceScaling().get();
		saved = true;
	}

	public static void tick(Minecraft mc) {
		if (mc.options == null) return;
		try {
			var o = mc.options;
			if (Modules.OPTIMIZATION.enabled) {
				if (!saved) save(mc);
				applied = true;
				int lv = Modules.OP_LEVEL.mode;
				put(o.entityShadows(), Boolean.FALSE);
				put(o.cloudStatus(), CloudStatus.OFF);
				put(o.biomeBlendRadius(), Integer.valueOf(Math.min(1, sBiome)));
				put(o.particles(), lv >= 1 ? ParticleStatus.DECREASED : sParticles);
				put(o.enableVsync(), lv >= 1 ? Boolean.FALSE : sVsync);
				put(o.framerateLimit(), lv >= 1 ? Integer.valueOf(260) : sFps);
				put(o.entityDistanceScaling(), lv >= 2 ? Double.valueOf(Math.min(0.7, sEntityDist)) : sEntityDist);
			} else if (applied) {
				restore(mc);
			}
		} catch (Throwable ignored) {
		}
	}

	public static void restore(Minecraft mc) {
		if (!applied || !saved || mc.options == null) return;
		try {
			var o = mc.options;
			put(o.entityShadows(), sShadows);
			put(o.cloudStatus(), sClouds);
			put(o.biomeBlendRadius(), sBiome);
			put(o.particles(), sParticles);
			put(o.enableVsync(), sVsync);
			put(o.framerateLimit(), sFps);
			put(o.entityDistanceScaling(), sEntityDist);
		} catch (Throwable ignored) {
		}
		applied = false;
		saved = false;
	}
}
