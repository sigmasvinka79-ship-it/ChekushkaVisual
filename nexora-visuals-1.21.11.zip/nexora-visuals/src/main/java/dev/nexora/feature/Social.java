package dev.nexora.feature;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.nexora.core.Config;
import net.minecraft.client.Minecraft;

/**
 * Профиль и друзья. Нужен сервер (server/nexora_server.py): адрес задаётся командой
 * .social server <url> или в Nexora/social.json. Без сервера профиль можно только открыть и посмотреть.
 */
public final class Social {
	public record Friend(String name, String code, String bio, String status, int color, boolean online, String where, long lastSeen) {}

	public static volatile String serverUrl = "";
	public static volatile String token = "", username = "", code = "", bio = "", statusText = "";
	public static volatile int color;
	public static volatile boolean appearOffline, showServer = true;
	public static volatile List<Friend> friends = List.of();
	public static volatile List<String> incoming = List.of(), outgoing = List.of();
	public static volatile String message = "";
	public static volatile boolean busy;

	private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
	private static long lastRefresh, lastBeat;

	private Social() {}

	public static boolean configured() {
		return !serverUrl.isBlank();
	}

	public static boolean registered() {
		return !token.isBlank();
	}

	private static Path file() {
		return Config.root().resolve("social.json");
	}

	public static void load() {
		try {
			Path f = file();
			if (!Files.exists(f)) return;
			JsonObject o = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
			serverUrl = str(o, "server");
			token = str(o, "token");
			username = str(o, "username");
			code = str(o, "code");
			bio = str(o, "bio");
			statusText = str(o, "status");
			color = o.has("color") ? o.get("color").getAsInt() : 0;
			appearOffline = o.has("appearOffline") && o.get("appearOffline").getAsBoolean();
			showServer = !o.has("showServer") || o.get("showServer").getAsBoolean();
		} catch (Exception ignored) {
		}
	}

	public static void save() {
		try {
			JsonObject o = new JsonObject();
			o.addProperty("server", serverUrl);
			o.addProperty("token", token);
			o.addProperty("username", username);
			o.addProperty("code", code);
			o.addProperty("bio", bio);
			o.addProperty("status", statusText);
			o.addProperty("color", color);
			o.addProperty("appearOffline", appearOffline);
			o.addProperty("showServer", showServer);
			Files.createDirectories(Config.root());
			Files.writeString(file(), Config.GSON.toJson(o), StandardCharsets.UTF_8);
		} catch (Exception ignored) {
		}
	}

	public static void setServer(String url) {
		String u = url.trim();
		while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
		serverUrl = u;
		save();
	}

	private static String str(JsonObject o, String k) {
		return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
	}

	private static JsonObject post(String path, JsonObject body) throws Exception {
		if (!configured()) throw new Exception("Social server is not set");
		HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(serverUrl + path))
			.timeout(Duration.ofSeconds(6))
			.header("Content-Type", "application/json")
			.POST(HttpRequest.BodyPublishers.ofString(body.toString()));
		if (!token.isBlank()) rb.header("X-Token", token);
		HttpResponse<String> r = HTTP.send(rb.build(), HttpResponse.BodyHandlers.ofString());
		JsonObject out;
		try {
			out = JsonParser.parseString(r.body()).getAsJsonObject();
		} catch (Exception e) {
			throw new Exception("Bad server answer (" + r.statusCode() + ")");
		}
		if (r.statusCode() / 100 != 2) throw new Exception(out.has("error") ? out.get("error").getAsString() : "Error " + r.statusCode());
		return out;
	}

	private static void async(Runnable r) {
		busy = true;
		CompletableFuture.runAsync(() -> {
			try {
				r.run();
			} catch (Exception e) {
				message = e.getMessage() == null ? "Error" : e.getMessage();
			} finally {
				busy = false;
			}
		});
	}

	private interface Job { void run() throws Exception; }

	private static void job(Job j) {
		async(() -> {
			try {
				j.run();
			} catch (Exception e) {
				message = e.getMessage() == null ? "Error" : e.getMessage();
			}
		});
	}

	public static void register(String name) {
		job(() -> {
			JsonObject b = new JsonObject();
			b.addProperty("username", name);
			JsonObject r = post("/api/register", b);
			token = str(r, "token");
			username = str(r, "username");
			code = str(r, "code");
			save();
			message = "";
			refreshNow();
		});
	}

	private static void refreshNow() throws Exception {
		JsonObject r = post("/api/me", new JsonObject());
		username = str(r, "username");
		code = str(r, "code");
		bio = str(r, "bio");
		statusText = str(r, "status");
		color = r.has("color") ? r.get("color").getAsInt() : 0;
		appearOffline = r.has("appear_offline") && r.get("appear_offline").getAsBoolean();
		showServer = !r.has("show_server") || r.get("show_server").getAsBoolean();
		List<Friend> fl = new ArrayList<>();
		for (JsonElement e : r.getAsJsonArray("friends")) {
			JsonObject f = e.getAsJsonObject();
			fl.add(new Friend(str(f, "username"), str(f, "code"), str(f, "bio"), str(f, "status"),
				f.has("color") ? f.get("color").getAsInt() : 0, f.has("online") && f.get("online").getAsBoolean(),
				str(f, "where"), f.has("last_seen") ? f.get("last_seen").getAsLong() : 0L));
		}
		friends = List.copyOf(fl);
		incoming = names(r.getAsJsonArray("incoming"));
		outgoing = names(r.getAsJsonArray("outgoing"));
		save();
	}

	private static List<String> names(JsonArray a) {
		List<String> l = new ArrayList<>();
		for (JsonElement e : a) l.add(e.getAsString());
		return List.copyOf(l);
	}

	public static void refresh() {
		if (!configured() || !registered()) return;
		job(Social::refreshNow);
	}

	public static void saveProfile() {
		save();
		if (!configured() || !registered()) return;
		job(() -> {
			JsonObject b = new JsonObject();
			b.addProperty("bio", bio);
			b.addProperty("status", statusText);
			b.addProperty("color", color);
			b.addProperty("appear_offline", appearOffline);
			b.addProperty("show_server", showServer);
			post("/api/profile", b);
		});
	}

	public static void sendRequest(String target) {
		job(() -> {
			JsonObject b = new JsonObject();
			b.addProperty("target", target.trim());
			JsonObject r = post("/api/friend/request", b);
			message = r.has("friends") && r.get("friends").getAsBoolean() ? "You are friends now" : "Request sent";
			refreshNow();
		});
	}

	public static void respond(String from, boolean accept) {
		job(() -> {
			JsonObject b = new JsonObject();
			b.addProperty("from", from);
			b.addProperty("accept", accept);
			post("/api/friend/respond", b);
			refreshNow();
		});
	}

	public static void remove(String name) {
		job(() -> {
			JsonObject b = new JsonObject();
			b.addProperty("username", name);
			post("/api/friend/remove", b);
			refreshNow();
		});
	}

	/** Вызывается каждый тик: отправляет «я в сети» и обновляет список друзей. */
	public static void tick(Minecraft mc) {
		if (!configured() || !registered() || !License.active()) return;
		long now = System.currentTimeMillis();
		if (now - lastBeat > 30_000) {
			lastBeat = now;
			String state = "menu", server = "";
			if (mc.level != null) {
				var sd = mc.getCurrentServer();
				if (sd != null) {
					state = "server";
					server = sd.ip;
				} else {
					state = "single";
				}
			}
			final String st = state, sv = server;
			job(() -> {
				JsonObject b = new JsonObject();
				b.addProperty("state", st);
				b.addProperty("server", sv);
				post("/api/presence", b);
			});
		}
		if (now - lastRefresh > 20_000) {
			lastRefresh = now;
			refresh();
		}
	}
}
