package dev.nexora.feature;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.nexora.core.Config;
import net.minecraft.client.Minecraft;

/**
 * Активация по ключу. Ключ проверяется офлайн (подпись), после ввода запоминается навсегда.
 * Мастер-код пропускает проверку. Для «одноразовости» между разными ПК можно задать revocationUrl
 * (ссылка на текстовый файл со списком использованных ключей) в Nexora/license.json.
 */
public final class License {
	private static final String SECRET = "gXVpXcT8rwIxGM3iNmTmywB0UlZD";
	private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	private static final String MASTER_HASH = "c6f989e88417c462a2206e2211e2e94c34c07bf2c88245ea4337e73140d9bfff";

	public enum Result { OK, INVALID, REVOKED, ERROR }

	private static boolean active;
	private static String key = "", revocationUrl = "";

	private License() {}

	public static boolean active() {
		return active;
	}

	private static Path file() {
		return Config.root().resolve("license.json");
	}

	public static void load() {
		try {
			Path f = file();
			if (!Files.exists(f)) return;
			JsonObject o = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
			active = o.has("activated") && o.get("activated").getAsBoolean();
			key = o.has("key") ? o.get("key").getAsString() : "";
			revocationUrl = o.has("revocationUrl") ? o.get("revocationUrl").getAsString().trim() : "";
		} catch (Exception ignored) {
		}
	}

	private static void save() {
		try {
			JsonObject o = new JsonObject();
			o.addProperty("activated", active);
			o.addProperty("key", key);
			o.addProperty("revocationUrl", revocationUrl);
			Files.createDirectories(Config.root());
			Files.writeString(file(), Config.GSON.toJson(o), StandardCharsets.UTF_8);
		} catch (Exception ignored) {
		}
	}

	private static String norm(String raw) {
		StringBuilder sb = new StringBuilder();
		for (char c : raw.toCharArray()) if (Character.isLetterOrDigit(c)) sb.append(Character.toUpperCase(c));
		return sb.toString();
	}

	private static String core(String raw) {
		String n = norm(raw);
		if (n.length() == 15 && n.startsWith("NXR")) n = n.substring(3);
		return n;
	}

	private static String sha256(String s) {
		try {
			byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
			StringBuilder sb = new StringBuilder();
			for (byte b : d) sb.append(String.format("%02x", b));
			return sb.toString();
		} catch (Exception e) {
			return "";
		}
	}

	private static String checksum(String id) {
		try {
			Mac mac = Mac.getInstance("HmacSHA256");
			mac.init(new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
			byte[] d = mac.doFinal(("NXR-" + id).getBytes(StandardCharsets.UTF_8));
			int v = ((d[0] & 255) << 16) | ((d[1] & 255) << 8) | (d[2] & 255);
			v >>= 4;
			return "" + ALPHABET.charAt((v >> 15) & 31) + ALPHABET.charAt((v >> 10) & 31)
				+ ALPHABET.charAt((v >> 5) & 31) + ALPHABET.charAt(v & 31);
		} catch (Exception e) {
			return "";
		}
	}

	public static boolean isMaster(String raw) {
		return sha256(norm(raw)).equals(MASTER_HASH);
	}

	public static boolean validKey(String raw) {
		String n = core(raw);
		if (n.length() != 12) return false;
		return checksum(n.substring(0, 8)).equals(n.substring(8));
	}

	private static Result checkRevoked(String core) {
		try {
			HttpClient c = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
			HttpRequest r = HttpRequest.newBuilder(URI.create(revocationUrl)).timeout(Duration.ofSeconds(5)).GET().build();
			HttpResponse<String> resp = c.send(r, HttpResponse.BodyHandlers.ofString());
			if (resp.statusCode() / 100 != 2) return Result.ERROR;
			for (String line : resp.body().split("\\R")) {
				if (!line.isBlank() && core(line).equals(core)) return Result.REVOKED;
			}
			return Result.OK;
		} catch (Exception e) {
			return Result.ERROR;
		}
	}

	private static void finish(String core, Result r, Consumer<Result> cb) {
		if (r == Result.OK) {
			active = true;
			key = core;
			save();
		}
		Minecraft.getInstance().execute(() -> cb.accept(r));
	}

	/** Результат приходит в основном потоке. Ключ запоминается один раз и больше не спрашивается. */
	public static void tryActivate(String raw, Consumer<Result> cb) {
		if (isMaster(raw)) {
			finish("MASTER", Result.OK, cb);
			return;
		}
		if (!validKey(raw)) {
			cb.accept(Result.INVALID);
			return;
		}
		String core = core(raw);
		if (revocationUrl.isEmpty()) {
			finish(core, Result.OK, cb);
			return;
		}
		CompletableFuture.runAsync(() -> finish(core, checkRevoked(core), cb));
	}
}
