package dev.nexora.feature;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import dev.nexora.core.Config;

/** Пользовательские конфиги (.cfg) + встроенные пресеты. */
public final class Configs {
	/** Встроенный «пресет»: сброс всех настроек к стандартным. */
	public static final String[] PRESETS = {"default"};

	private Configs() {}

	public static String clean(String n) {
		String s = n.toLowerCase().replaceAll("[^a-z0-9_-]", "");
		return s.length() > 32 ? s.substring(0, 32) : s;
	}

	public static boolean isPreset(String n) {
		for (String p : PRESETS) if (p.equals(n)) return true;
		return false;
	}

	public static List<String> list() {
		List<String> out = new ArrayList<>();
		Path d = Config.configsDir();
		if (Files.isDirectory(d)) {
			try (Stream<Path> st = Files.list(d)) {
				st.map(p -> p.getFileName().toString())
					.filter(f -> f.endsWith(".json"))
					.map(f -> f.substring(0, f.length() - 5))
					.sorted()
					.forEach(out::add);
			} catch (Exception ignored) {
			}
		}
		return out;
	}

	public static boolean save(String name) {
		try {
			Files.createDirectories(Config.configsDir());
			try (Writer w = Files.newBufferedWriter(Config.configsDir().resolve(name + ".json"))) {
				Config.GSON.toJson(Config.toJson(), w);
			}
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean load(String name) {
		try {
			Path f = Config.configsDir().resolve(name + ".json");
			if (Files.exists(f)) {
				try (Reader r = Files.newBufferedReader(f)) {
					Config.fromJson(JsonParser.parseReader(r).getAsJsonObject());
				}
				return true;
			}
			if (name.equals("default")) {
				dev.nexora.core.Modules.resetAll();
				for (var w : dev.nexora.hud.HudRenderer.widgets()) w.reset();
				dev.nexora.util.Fonts.reset();
				return true;
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	public static boolean delete(String name) {
		try {
			return Files.deleteIfExists(Config.configsDir().resolve(name + ".json"));
		} catch (Exception e) {
			return false;
		}
	}
}
