package dev.nexora.util;

import java.util.HashMap;
import java.util.Map;

import dev.nexora.core.Modules;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

/** Шрифты интерфейса: Poppins, Carlito или ванильный Minecraft (Theme → Interface → Font style). */
public final class Fonts {
	public static final Identifier ID = Identifier.fromNamespaceAndPath("nexora", "ui");
	private static final Style STYLE_A = Style.EMPTY.withFont(new FontDescription.Resource(ID));
	private static final Style STYLE_B = Style.EMPTY.withFont(
		new FontDescription.Resource(Identifier.fromNamespaceAndPath("nexora", "ui2")));
	private static final Map<String, Component> CACHE = new HashMap<>(512);

	private Fonts() {}

	public static Component of(String s) {
		Component c = CACHE.get(s);
		if (c == null) {
			if (CACHE.size() > 1500) CACHE.clear();
			int m = Modules.TH_FONTSTYLE.mode;
			c = m == 2 ? Component.literal(s) : Component.literal(s).withStyle(m == 1 ? STYLE_B : STYLE_A);
			CACHE.put(s, c);
		}
		return c;
	}

	public static void reset() {
		CACHE.clear();
	}
}
