package dev.nexora.util;

import net.minecraft.client.gui.GuiGraphics;

/** Заливка выпуклого многоугольника горизонтальными полосами с вертикальным градиентом. */
public final class Poly {
	private Poly() {}

	public static void fill(GuiGraphics g, float[] xs, float[] ys, int n, int colTop, int colBot) {
		float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
		for (int i = 0; i < n; i++) {
			minY = Math.min(minY, ys[i]);
			maxY = Math.max(maxY, ys[i]);
		}
		int y0 = Math.max(0, (int) Math.floor(minY)), y1 = Math.min(g.guiHeight(), (int) Math.ceil(maxY));
		if (y1 <= y0 || y1 - y0 > 500) return;
		float span = Math.max(1f, maxY - minY);
		for (int yy = y0; yy < y1; yy++) {
			float yc = yy + 0.5f, xmin = Float.MAX_VALUE, xmax = -Float.MAX_VALUE;
			for (int i = 0; i < n; i++) {
				int j = (i + 1) % n;
				float ya = ys[i], yb = ys[j];
				float lo = Math.min(ya, yb), hi = Math.max(ya, yb);
				if (yc >= lo && yc < hi) {
					float xx = xs[i] + (yc - ya) / (yb - ya) * (xs[j] - xs[i]);
					xmin = Math.min(xmin, xx);
					xmax = Math.max(xmax, xx);
				}
			}
			if (xmax - xmin < 0.5f) continue;
			int x1 = Math.round(xmin);
			g.fill(x1, yy, Math.max(x1 + 1, Math.round(xmax)), yy + 1, Draw.lerp(colTop, colBot, (yc - minY) / span));
		}
	}
}
