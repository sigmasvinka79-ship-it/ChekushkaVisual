package dev.nexora.util;

import org.lwjgl.glfw.GLFW;

/** Ввод текста по кодам клавиш (латиница, цифры и пара знаков) — без зависимости от событий символов. */
public final class TypeIn {
	private TypeIn() {}

	public static char of(int k, boolean shift) {
		if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) return (char) ((shift ? 'A' : 'a') + (k - GLFW.GLFW_KEY_A));
		if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) {
			if (shift && k == GLFW.GLFW_KEY_1) return '!';
			return (char) ('0' + (k - GLFW.GLFW_KEY_0));
		}
		return switch (k) {
			case GLFW.GLFW_KEY_SPACE -> ' ';
			case GLFW.GLFW_KEY_MINUS -> shift ? '_' : '-';
			case GLFW.GLFW_KEY_PERIOD -> '.';
			case GLFW.GLFW_KEY_COMMA -> ',';
			case GLFW.GLFW_KEY_SLASH -> shift ? '?' : '/';
			default -> 0;
		};
	}
}
