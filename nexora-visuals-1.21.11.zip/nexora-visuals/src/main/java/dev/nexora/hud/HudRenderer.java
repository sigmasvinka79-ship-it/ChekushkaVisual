package dev.nexora.hud;

import java.util.ArrayList;
import java.util.List;

import dev.nexora.NexoraClient;
import dev.nexora.core.Module;
import dev.nexora.core.Modules;
import dev.nexora.core.Theme;
import dev.nexora.gui.MenuScreen;
import dev.nexora.feature.License;
import dev.nexora.util.Anim;
import dev.nexora.util.Draw;
import dev.nexora.util.Proj;
import dev.nexora.util.Stats;
import dev.nexora.visual.Atmosphere;
import dev.nexora.visual.Cosmetics;
import dev.nexora.visual.Zoom;
import dev.nexora.visual.DamageNumbers;
import dev.nexora.visual.GpsOverlay;
import dev.nexora.visual.JumpCircles;
import dev.nexora.visual.LightOverlay;
import dev.nexora.visual.Trajectory;
import dev.nexora.visual.TargetEsp;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2fStack;

public final class HudRenderer {
	private static final List<HudWidget> WIDGETS = new ArrayList<>();
	private static final Anim.Timer TIMER = new Anim.Timer();

	private HudRenderer() {}

	public static List<HudWidget> widgets() {
		return WIDGETS;
	}

	public static boolean editing() {
		return Minecraft.getInstance().screen instanceof MenuScreen;
	}

	public static void init() {
		WIDGETS.add(new WatermarkWidget());
		WIDGETS.add(new EffectsWidget());
		WIDGETS.add(new ArmorWidget());
		WIDGETS.add(new TargetWidget());
		WIDGETS.add(new KeystrokesWidget());
		WIDGETS.add(new InfoWidget());
		WIDGETS.add(new ItemsWidget());
		WIDGETS.add(new GpsWidget());
		WIDGETS.add(new SessionWidget());
		WIDGETS.add(new MaceWidget());
		WIDGETS.add(new ComboWidget());
		WIDGETS.add(new ElytraWidget());
		WIDGETS.add(new ArrayListWidget());

		// Атмосфера рисуется ПЕРВОЙ (под ванильным HUD), остальное — поверх.
		HudElementRegistry.addFirst(Identifier.fromNamespaceAndPath(NexoraClient.ID, "atmosphere"), Atmosphere::render);
		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(NexoraClient.ID, "overlay"), HudRenderer::render);

		// Подмена ванильных элементов. Имена констант ищем рефлексией, чтобы сборка
		// не ломалась, если в твоей версии Fabric API они названы чуть иначе.
		Identifier cross = vanilla("CROSSHAIR");
		if (cross != null) {
			HudElementRegistry.replaceElement(cross, prev -> (g, dt) -> {
				if (License.active() && Modules.CROSSHAIR.enabled) CrosshairRenderer.render(g);
				else prev.render(g, dt);
			});
		}
		Identifier fx = vanilla("STATUS_EFFECTS", "MOB_EFFECTS");
		if (fx != null) {
			HudElementRegistry.replaceElement(fx, prev -> (g, dt) -> {
				if (!(License.active() && Modules.EFFECTS.enabled && Modules.EF_VANILLA.bool)) prev.render(g, dt);
			});
		}
	}

	private static Identifier vanilla(String... names) {
		for (String n : names) {
			try {
				return (Identifier) VanillaHudElements.class.getField(n).get(null);
			} catch (Throwable ignored) {
			}
		}
		return null;
	}

	public static void render(GuiGraphics g, DeltaTracker dt) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) return;
		if (!License.active()) return;

		Anim.dt = TIMER.tick();
		Zoom.frame(mc, Anim.dt);
		Stats.frame();
		TargetTracker.update(mc);

		int sw = g.guiWidth(), sh = g.guiHeight();
		float pt = dt.getGameTimeDeltaPartialTick(false);
		boolean edit = mc.screen instanceof MenuScreen;

		// 3D-эффекты в экранных координатах
		Proj.begin(mc, pt, sw, sh);
		TargetEsp.render(g, pt);
		JumpCircles.render(g);
		Trajectory.render(g, pt);
		LightOverlay.render(g);
		Cosmetics.render(g, pt, sw, sh);
		DamageNumbers.render(g);
		GpsOverlay.render(g, sw, sh);

		for (Module m : Modules.ALL) m.vis = Anim.approach(m.vis, m.enabled ? 1f : 0f, 14f);

		for (HudWidget w : WIDGETS) {
			Module m = w.module;
			if (m.vis < 0.02f) {
				w.w = 0;
				w.h = 0;
				continue;
			}
			w.layout(sw, sh);
			Matrix3x2fStack ps = g.pose();
			ps.pushMatrix();
			ps.translate(0f, (1f - m.vis) * -5f);
			if (w.scale != 1f) {
				ps.translate(w.px, w.py);
				ps.scale(w.scale, w.scale);
				ps.translate(-w.px, -w.py);
			}
			w.draw(g, pt, sw, sh, m.vis);
			ps.popMatrix();

			if (edit && w.w > 0) {
				boolean drag = mc.screen instanceof MenuScreen ms && ms.draggingWidget() == w;
				g.renderOutline(Math.round(w.px) - 2, Math.round(w.py) - 2, Math.round(w.bw()) + 4, Math.round(w.bh()) + 4,
					drag ? Draw.a(Theme.accent(), 0.95f) : Draw.a(0xFFFFFFFF, 0.28f));
			}
		}
		Notifications.render(g, sw, sh);
	}
}
