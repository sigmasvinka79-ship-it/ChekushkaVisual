package dev.nexora.hud;

import java.util.Locale;

import dev.nexora.core.Modules;
import dev.nexora.core.Theme;
import dev.nexora.util.Anim;
import dev.nexora.util.Draw;
import dev.nexora.util.Lang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.Items;

/** Помощник булавы: дистанция падения, расчётный урон smash-удара и готовность. Показывается с булавой в руке. */
public final class MaceWidget extends HudWidget {
	private float shown;

	public MaceWidget() {
		super(Modules.MACE, 0.53f, 0.30f);
	}

	/** Урон smash-удара: 6 + бонус за падение (до 3 блоков +4, до 8 блоков +2, дальше +1 за блок). */
	public static double smash(double fall) {
		if (fall < 1.5) return 6.0;
		double bonus = fall <= 3 ? 4 * fall : (fall <= 8 ? 12 + 2 * (fall - 3) : 22 + (fall - 8));
		return 6.0 + bonus;
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		var p = Minecraft.getInstance().player;
		boolean holding = p.getMainHandItem().is(Items.MACE) || p.getOffhandItem().is(Items.MACE);
		boolean edit = HudRenderer.editing();
		shown = Anim.approach(shown, (holding || edit) ? 1f : 0f, 12f);
		if (shown < 0.02f) {
			w = 0;
			h = 0;
			return;
		}
		float al = a * shown;

		double fall = p.fallDistance;
		if (!holding && edit) fall = 9.4;
		boolean air = !p.onGround();
		float cd = p.getAttackStrengthScale(0f);
		String status;
		int col;
		if (air && fall >= 1.5 && cd >= 0.95f) {
			status = "READY";
			col = Theme.GOOD;
		} else if (cd < 0.95f) {
			status = Math.round(cd * 100f) + "%";
			col = Theme.WARN;
		} else {
			status = "JUMP";
			col = Theme.MUTED;
		}

		int rows = 1 + (Modules.MC_FALL.bool ? 1 : 0) + (Modules.MC_DMG.bool ? 1 : 0);
		w = 96;
		h = rows * 12 + 8;
		Draw.panel(g, x, y, w, h, al);
		float cy = y + 5;
		Draw.text(g, "MACE", x + 7, cy + 1, 0.72f, Draw.a(Theme.MUTED, al), false);
		Draw.textRight(g, status, x + w - 7, cy, 1f, Draw.a(col, al));
		cy += 12;
		if (Modules.MC_FALL.bool) {
			Draw.text(g, "FALL", x + 7, cy + 1, 0.72f, Draw.a(Theme.MUTED, al), false);
			Draw.textRight(g, String.format(Locale.ROOT, "%.1f m", fall), x + w - 7, cy, 1f, Draw.a(Theme.TEXT, al));
			cy += 12;
		}
		if (Modules.MC_DMG.bool) {
			Draw.text(g, "SMASH", x + 7, cy + 1, 0.72f, Draw.a(Theme.MUTED, al), false);
			Draw.textRight(g, String.format(Locale.ROOT, "%.1f", smash(fall)), x + w - 7, cy, 1f, Draw.a(Theme.BAD, al));
		}
	}
}
