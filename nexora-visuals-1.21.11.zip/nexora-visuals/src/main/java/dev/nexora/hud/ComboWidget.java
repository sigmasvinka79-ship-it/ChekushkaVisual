package dev.nexora.hud;

import dev.nexora.core.Modules;
import dev.nexora.core.Theme;
import dev.nexora.util.Anim;
import dev.nexora.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

/** Счётчик комбо: растёт при каждом попадании, сбрасывается через 3 секунды. */
public final class ComboWidget extends HudWidget {
	private float shown, pop;
	private int last;

	public ComboWidget() {
		super(Modules.COMBO, 0.53f, 0.42f);
	}

	@Override
	protected void render(GuiGraphics g, float x, float y, float pt, int sw, int sh, float a) {
		long now = Util.getMillis();
		long window = (long) (Modules.CB_TIME.f() * 1000f);
		boolean active = TargetTracker.combo > 0 && now - TargetTracker.comboTime < window;
		boolean edit = HudRenderer.editing();
		shown = Anim.approach(shown, (active || edit) ? 1f : 0f, 12f);
		if (shown < 0.02f) {
			w = 0;
			h = 0;
			return;
		}
		int c = active ? TargetTracker.combo : 7;
		if (c != last) {
			last = c;
			pop = 1f;
		}
		pop = Anim.approach(pop, 0f, 9f);
		float al = a * shown;

		String num = "x" + c;
		float s = 1.5f + pop * 0.4f;
		w = 78;
		h = 32;
		Draw.panel(g, x, y, w, h, al);
		Draw.text(g, num, x + 10, y + 7 - pop * 2f, s, Draw.a(Draw.lerp(Theme.accent(), Theme.accent2(), Mth.clamp(c / 15f, 0f, 1f)), al), true);
		Draw.text(g, "COMBO", x + 12 + Draw.width(num) * s, y + 9, 0.72f, Draw.a(Theme.MUTED, al), false);
		float frac = active ? 1f - Mth.clamp((now - TargetTracker.comboTime) / (float) window, 0f, 1f) : 0.6f;
		if (Modules.CB_BAR.bool) Draw.bar(g, x + 8, y + h - 7, w - 16, 2, frac, Theme.accent(), al);
	}
}
