package dev.nexora.core;

import net.minecraft.util.Mth;

/**
 * Тема клиента. По умолчанию — «Nexora»: чёрное стекло с переливающимся синим акцентом.
 * Цвета переливаются во времени (Shimmer), второй цвет можно выбрать (Second color).
 */
public final class Theme {
	public static final String[] NAMES = {"Nexora", "Ice", "Aurora", "Violet", "Sunset", "Ember", "Mono", "Custom"};
	/** {цвет 1, цвет 2, база панели RGB}. */
	private static final int[][] PRESETS = {
		{0xFF4C8DFF, 0xFF7FD6FF, 0x060A14},
		{0xFF9FE8FF, 0xFFFFFFFF, 0x070C12},
		{0xFF38F2B2, 0xFF6C8CFF, 0x06100F},
		{0xFFA78BFA, 0xFFE879F9, 0x0D0818},
		{0xFFFB7185, 0xFFFB923C, 0x120709},
		{0xFFF59E0B, 0xFFEF4444, 0x110A06},
		{0xFFE5E7EB, 0xFF9CA3AF, 0x08090B}
	};

	public static final int TEXT = 0xFFF4F6FA;
	public static final int MUTED = 0xFF9AA4B8;
	public static final int GOOD = 0xFF4ADE80;
	public static final int WARN = 0xFFFBBF24;
	public static final int BAD = 0xFFF87171;

	private static long bucket = Long.MIN_VALUE;
	private static int a1 = 0xFF4C8DFF, a2 = 0xFF7FD6FF, baseRgb = 0x060A14;

	private Theme() {}

	private static int mix(int c1, int c2, float t) {
		t = Mth.clamp(t, 0f, 1f);
		int out = 0;
		for (int s = 0; s <= 24; s += 8) {
			int x = (c1 >>> s) & 255, y = (c2 >>> s) & 255;
			out |= (Math.round(x + (y - x) * t) & 255) << s;
		}
		return out;
	}

	private static float hueOf(int rgb) {
		float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
		float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
		if (d < 1e-4f) return 0f;
		float h;
		if (max == r) h = ((g - b) / d) % 6f;
		else if (max == g) h = (b - r) / d + 2f;
		else h = (r - g) / d + 4f;
		h /= 6f;
		return h < 0 ? h + 1f : h;
	}

	private static void update() {
		long b = System.nanoTime() >> 21;
		if (b == bucket) return;
		bucket = b;

		int c1, c2;
		int preset = Modules.TH_ACCENT.mode;
		if (preset >= PRESETS.length) {
			float h = Modules.TH_HUE.f() / 360f, s = Modules.TH_SAT.f(), v = Modules.TH_VAL.f();
			c1 = 0xFF000000 | Mth.hsvToRgb(h, s, v);
			c2 = 0xFF000000 | Mth.hsvToRgb((h + 0.07f) % 1f, s * 0.6f, v);
			baseRgb = Mth.hsvToRgb(h, 0.55f, 0.07f);
		} else {
			c1 = PRESETS[preset][0];
			c2 = PRESETS[preset][1];
			baseRgb = PRESETS[preset][2];
		}
		int second = c2;
		switch (Modules.TH_SECOND.mode) {
			case 1 -> second = 0xFF000000 | Mth.hsvToRgb((hueOf(c1) + 0.5f) % 1f, 0.55f, 1f);
			case 2 -> second = 0xFF000000 | Mth.hsvToRgb((hueOf(c1) + 0.1f) % 1f, 0.6f, 1f);
			case 3 -> second = 0xFFFFFFFF;
			default -> {
			}
		}
		float t = (System.nanoTime() / 1.0e9f) * Modules.TH_SPEED.f() * 1.3f;
		float ph = 0.5f + 0.5f * Mth.sin(t);
		float amount = Modules.TH_SHIMMER.f();
		a1 = mix(c1, second, ph * amount);
		a2 = mix(second, c1, (1f - ph) * amount * 0.5f);
	}

	public static int accent() {
		update();
		return a1;
	}

	public static int accent2() {
		update();
		return a2;
	}

	public static int radius() {
		return Modules.TH_RADIUS.i();
	}

	/** Фон стеклянной панели: тёмная база с лёгкой тонировкой акцентом. */
	public static int bg(float alpha) {
		update();
		int rgb = mix(0xFF000000 | baseRgb, a1, Modules.TH_TINT.f()) & 0xFFFFFF;
		int a = Mth.clamp(Math.round(Modules.TH_OPACITY.f() * 255f * alpha), 0, 255);
		return (a << 24) | rgb;
	}
}
