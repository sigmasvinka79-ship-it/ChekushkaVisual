package dev.nexora.core;

import java.util.ArrayList;
import java.util.List;

/** Реестр всех модулей и их настроек. У каждого переключаемого модуля есть хотя бы одна настройка (ПКМ). */
public final class Modules {
	public static final List<Module> ALL = new ArrayList<>();

	private static Module reg(Module m) {
		ALL.add(m);
		return m;
	}

	/** Сброс всего к значениям по умолчанию. */
	public static void resetAll() {
		for (Module m : ALL) {
			m.enabled = m.defEnabled;
			m.guiToggle = m.enabled ? 1f : 0f;
			for (Setting s : m.settings) s.reset();
		}
	}

	// ───────────── HUD ─────────────
	public static final Module WATERMARK = reg(new Module("Watermark", "Name, FPS, ping and clock", Category.HUD, true, true));
	public static final Setting WM_FPS = WATERMARK.add(Setting.bool("fps", "Show FPS", true));
	public static final Setting WM_PING = WATERMARK.add(Setting.bool("ping", "Show ping", true));
	public static final Setting WM_TIME = WATERMARK.add(Setting.bool("time", "Show clock", true));

	public static final Module EFFECTS = reg(new Module("Effects", "Potion list with countdown timers", Category.HUD, true, true));
	public static final Setting EF_VANILLA = EFFECTS.add(Setting.bool("hide_vanilla", "Hide vanilla icons", true));
	public static final Setting EF_ICONS = EFFECTS.add(Setting.bool("icons", "Icons", true));
	public static final Setting EF_BAR = EFFECTS.add(Setting.bool("bar", "Progress bar", true));
	public static final Setting EF_FORMAT = EFFECTS.add(Setting.mode("format", "Time format", 0, "m:ss", "Seconds"));
	public static final Setting EF_WARN = EFFECTS.add(Setting.num("warn", "Blink below (sec)", 10, 0, 30, 1));

	public static final Module ARMOR = reg(new Module("Armor", "Armor pieces with durability", Category.HUD, true, true));
	public static final Setting AR_LAYOUT = ARMOR.add(Setting.mode("layout", "Layout", 0, "Vertical", "Horizontal"));
	public static final Setting AR_PCT = ARMOR.add(Setting.bool("percent", "Show percent", true));
	public static final Setting AR_WARN = ARMOR.add(Setting.bool("warn", "Low durability warning", true));

	public static final Module TARGET = reg(new Module("Target HUD", "Info about what you look at", Category.HUD, true, true));
	public static final Setting TG_STYLE = TARGET.add(Setting.mode("style", "Style", 0, "Modern", "Minimal"));
	public static final Setting TG_ARMOR = TARGET.add(Setting.bool("armor", "Show armor", true));
	public static final Setting TG_DIST = TARGET.add(Setting.bool("distance", "Show distance", true));
	public static final Setting TG_LINGER = TARGET.add(Setting.num("linger", "Keep visible (sec)", 2, 0.5, 6, 0.5));

	public static final Module KEYS = reg(new Module("Keystrokes", "WASD, mouse buttons and CPS", Category.HUD, true, true));
	public static final Setting KS_MOUSE = KEYS.add(Setting.bool("mouse", "Mouse buttons", true));
	public static final Setting KS_SPACE = KEYS.add(Setting.bool("space", "Space bar", true));
	public static final Setting KS_CPS = KEYS.add(Setting.bool("cps", "Show CPS", true));

	public static final Module INFO = reg(new Module("Info", "Coordinates, speed and direction", Category.HUD, true, true));
	public static final Setting IN_COORDS = INFO.add(Setting.bool("coords", "Coordinates", true));
	public static final Setting IN_SPEED = INFO.add(Setting.bool("speed", "Speed", true));
	public static final Setting IN_DIR = INFO.add(Setting.bool("direction", "Direction", true));

	public static final Module ITEMS = reg(new Module("Item counter", "Totems, apples, pearls, fireworks", Category.HUD, true, true));
	public static final Setting IT_TOTEM = ITEMS.add(Setting.bool("totem", "Totems", true));
	public static final Setting IT_GAPPLE = ITEMS.add(Setting.bool("gapple", "Golden apples", true));
	public static final Setting IT_PEARL = ITEMS.add(Setting.bool("pearl", "Ender pearls", true));
	public static final Setting IT_FIREWORK = ITEMS.add(Setting.bool("firework", "Fireworks", true));
	public static final Setting IT_CRYSTAL = ITEMS.add(Setting.bool("crystal", "End crystals", false));
	public static final Setting IT_XP = ITEMS.add(Setting.bool("xp", "XP bottles", false));
	public static final Setting IT_HIDE = ITEMS.add(Setting.bool("hide_empty", "Hide empty", true));

	public static final Module ARRAY = reg(new Module("ArrayList", "List of enabled modules", Category.HUD, true, true));
	public static final Setting AL_BAR = ARRAY.add(Setting.bool("bar", "Accent bar", true));
	public static final Setting AL_HUD = ARRAY.add(Setting.bool("hud", "Include HUD modules", false));

	public static final Module COMBO = reg(new Module("Combo", "Hit combo counter", Category.HUD, true, true));
	public static final Setting CB_TIME = COMBO.add(Setting.num("timeout", "Timeout (sec)", 3, 1, 6, 0.5));
	public static final Setting CB_BAR = COMBO.add(Setting.bool("bar", "Show timer bar", true));

	public static final Module ELYTRA_HUD = reg(new Module("Elytra HUD", "Durability, speed, altitude, rockets", Category.HUD, true, true));
	public static final Setting EH_SPEED = ELYTRA_HUD.add(Setting.bool("speed", "Show speed", true));
	public static final Setting EH_ALT = ELYTRA_HUD.add(Setting.bool("alt", "Show altitude", true));
	public static final Setting EH_ROCKETS = ELYTRA_HUD.add(Setting.bool("rockets", "Show rockets", true));

	public static final Module MACE = reg(new Module("Mace helper", "Fall distance, smash damage, ready state", Category.HUD, true, true));
	public static final Setting MC_FALL = MACE.add(Setting.bool("fall", "Show fall distance", true));
	public static final Setting MC_DMG = MACE.add(Setting.bool("damage", "Show damage", true));

	public static final Module SESSION = reg(new Module("Session", "Playtime, kills, deaths, combat timer", Category.HUD, true, true));
	public static final Setting SE_KD = SESSION.add(Setting.bool("kd", "Kills and deaths", true));
	public static final Setting SE_COMBAT = SESSION.add(Setting.bool("combat", "Combat timer", true));

	public static final Module NOTIFS = reg(new Module("Notifications", "Toasts when modules are toggled", Category.HUD, true, true));
	public static final Setting NF_TIME = NOTIFS.add(Setting.num("time", "Duration (sec)", 2.5, 1, 6, 0.5));

	// ───────────── Visuals ─────────────
	public static final Module ESP = reg(new Module("Target ESP", "Effects around the entity you look at", Category.VISUALS, true, true));
	public static final Setting ESP_MODE = ESP.add(Setting.mode("mode", "Mode", 0,
		"Ghosts", "Souls", "Orbit", "Ring", "Spiral", "Marker", "Corners", "Halo", "Saturn"));
	public static final Setting ESP_COLOR = ESP.add(Setting.mode("color", "Color", 0, "Theme", "Health", "Rainbow"));
	public static final Setting ESP_COUNT = ESP.add(Setting.num("count", "Count", 3, 1, 8, 1));
	public static final Setting ESP_SIZE = ESP.add(Setting.num("size", "Size", 1.0, 0.5, 2.0, 0.1));
	public static final Setting ESP_SPEED = ESP.add(Setting.num("speed", "Speed", 1.0, 0.4, 2.5, 0.1));
	public static final Setting ESP_HOLD = ESP.add(Setting.num("hold", "Keep visible (sec)", 2, 0.5, 8, 0.5));

	public static final Module TRAJ = reg(new Module("Trajectory", "Path of thrown items, arrows and potions", Category.VISUALS, true, true));
	public static final Setting TJ_STYLE = TRAJ.add(Setting.mode("style", "Style", 0, "Dots", "Line"));
	public static final Setting TJ_MARK = TRAJ.add(Setting.bool("marker", "Landing marker", true));
	public static final Setting TJ_DIST = TRAJ.add(Setting.bool("distance", "Show distance", true));
	public static final Setting TJ_BOW = TRAJ.add(Setting.bool("bow", "Bow and crossbow", true));
	public static final Setting TJ_POTION = TRAJ.add(Setting.bool("potion", "Potions", true));

	public static final Module CROSSHAIR = reg(new Module("Crosshair", "Custom crosshair with hit marker", Category.VISUALS, true, true));
	public static final Setting CH_STYLE = CROSSHAIR.add(Setting.mode("style", "Style", 0, "Cross", "Dot", "Circle", "T-Shape"));
	public static final Setting CH_COLOR = CROSSHAIR.add(Setting.mode("color", "Color", 0, "Accent", "White", "Rainbow"));
	public static final Setting CH_SIZE = CROSSHAIR.add(Setting.num("size", "Size", 4, 1, 12, 1));
	public static final Setting CH_GAP = CROSSHAIR.add(Setting.num("gap", "Gap", 2, 0, 10, 1));
	public static final Setting CH_THICK = CROSSHAIR.add(Setting.num("thickness", "Thickness", 1, 1, 4, 1));
	public static final Setting CH_DYNAMIC = CROSSHAIR.add(Setting.bool("dynamic", "Dynamic gap", true));
	public static final Setting CH_OUTLINE = CROSSHAIR.add(Setting.bool("outline", "Outline", true));
	public static final Setting CH_HIT = CROSSHAIR.add(Setting.bool("hitmarker", "Hit marker", true));
	public static final Setting CH_COOLDOWN = CROSSHAIR.add(Setting.bool("cooldown", "Attack cooldown bar", true));
	public static final Setting CH_TARGET = CROSSHAIR.add(Setting.bool("target_red", "Red on target", true));

	public static final Module PARTICLES = reg(new Module("Particles", "Client-side hit and aura particles", Category.VISUALS, true, true));
	public static final Setting PA_HIT = PARTICLES.add(Setting.bool("hit", "On hit", true));
	public static final Setting PA_TYPE = PARTICLES.add(Setting.mode("type", "Hit type", 0, ParticleNames.NAMES));
	public static final Setting PA_AMOUNT = PARTICLES.add(Setting.num("amount", "Amount", 14, 3, 40, 1));
	public static final Setting PA_AURA = PARTICLES.add(Setting.bool("aura", "Self aura", false));
	public static final Setting PA_AURA_TYPE = PARTICLES.add(Setting.mode("aura_type", "Aura type", 2, ParticleNames.NAMES));
	public static final Setting PA_KILL = PARTICLES.add(Setting.bool("kill", "Kill burst", true));
	public static final Setting PA_TRAIL = PARTICLES.add(Setting.bool("trail", "Elytra trail", false));
	public static final Setting PA_TRAIL_TYPE = PARTICLES.add(Setting.mode("trail_type", "Trail type", 0, ParticleNames.NAMES));

	public static final Module DAMAGE = reg(new Module("Damage numbers", "Floating damage on your target", Category.VISUALS, true, true));
	public static final Setting DM_SIZE = DAMAGE.add(Setting.num("size", "Size", 1.2, 0.8, 2.0, 0.1));

	public static final Module HITSOUND = reg(new Module("Hit sound", "Sound when you hit a target", Category.VISUALS, false, true));
	public static final Setting HS_SOUND = HITSOUND.add(Setting.mode("sound", "Sound", 0, "Orb", "Chime", "Arrow"));
	public static final Setting HS_VOL = HITSOUND.add(Setting.num("volume", "Volume", 0.5, 0.1, 1.0, 0.1));
	public static final Setting HS_PITCH = HITSOUND.add(Setting.num("pitch", "Pitch", 1.2, 0.5, 2.0, 0.1));

	public static final Module JUMP = reg(new Module("Jump circles", "Rings that spread when you jump", Category.VISUALS, true, true));
	public static final Setting JC_SIZE = JUMP.add(Setting.num("size", "Size", 1.0, 0.5, 2.5, 0.1));

	public static final Module ZOOM = reg(new Module("Zoom", "Hold the zoom key, scroll to adjust", Category.VISUALS, true, true));
	public static final Setting ZOOM_FACTOR = ZOOM.add(Setting.num("factor", "Zoom factor", 4.0, 1.5, 12.0, 0.5));
	public static final Setting ZOOM_SMOOTH = ZOOM.add(Setting.num("smooth", "Smooth speed", 14, 4, 30, 1));
	public static final Setting ZOOM_SCROLL = ZOOM.add(Setting.bool("scroll", "Scroll adjusts zoom", true));
	public static final Setting ZOOM_SENS = ZOOM.add(Setting.bool("sens", "Lower sensitivity", true));

	public static final Module LIGHT = reg(new Module("Light level", "Marks spots where mobs can spawn", Category.VISUALS, false, true));
	public static final Setting LV_RADIUS = LIGHT.add(Setting.num("radius", "Radius", 5, 3, 8, 1));
	public static final Setting LV_ALPHA = LIGHT.add(Setting.num("alpha", "Opacity", 0.35, 0.15, 0.8, 0.05));

	public static final Module FULLBRIGHT = reg(new Module("Fullbright", "Max brightness (gamma)", Category.VISUALS, false, true));
	public static final Setting FB_LEVEL = FULLBRIGHT.add(Setting.num("level", "Gamma", 16, 2, 16, 1));

	public static final Module ATMOSPHERE = reg(new Module("Atmosphere", "Dark tint and vignette", Category.VISUALS, true, true));
	public static final Setting AT_PRESET = ATMOSPHERE.add(Setting.mode("preset", "Preset", 1, "Depressive", "Midnight", "Crimson", "Ash"));
	public static final Setting AT_TINT = ATMOSPHERE.add(Setting.num("tint", "Tint", 0.12, 0.0, 0.5, 0.02));
	public static final Setting AT_VIGN = ATMOSPHERE.add(Setting.num("vignette", "Vignette", 0.55, 0.0, 1.0, 0.05));
	public static final Setting AT_PULSE = ATMOSPHERE.add(Setting.bool("pulse", "Breathing pulse", true));
	public static final Setting AT_LOWHP = ATMOSPHERE.add(Setting.bool("lowhp", "Low HP warning", true));

	public static final Module COSMETICS = reg(new Module("Cosmetics", "Cape, hat, wings, horns and pet (only you see them)", Category.VISUALS, true, true));
	public static final Setting CO_CAPE = COSMETICS.add(Setting.mode("cape", "Cape", 0, "Off", "Crimson", "Violet", "Midnight", "Galaxy", "Rainbow"));
	public static final Setting CO_HAT = COSMETICS.add(Setting.mode("hat", "Hat", 0, "Off", "China hat"));
	public static final Setting CO_WINGS = COSMETICS.add(Setting.mode("wings", "Wings", 0, "Off", "Angel"));
	public static final Setting CO_HALO = COSMETICS.add(Setting.bool("halo", "Halo", false));
	public static final Setting CO_HORNS = COSMETICS.add(Setting.mode("horns", "Horns", 0, "Off", "Theme", "Devil"));
	public static final Setting CO_PET = COSMETICS.add(Setting.mode("pet", "Pet", 0, "Off", "Ghost", "Slime", "Bat", "Fire Sprite", "Wisp"));
	public static final Setting CO_FIRST = COSMETICS.add(Setting.bool("first", "Show in first person", false));
	public static final Setting CO_SCALE = COSMETICS.add(Setting.num("scale", "Cosmetic scale", 1.0, 0.6, 1.8, 0.1));

	// ───────────── Animations ─────────────
	public static final Module SWING = reg(new Module("Swing", "Swing animation and hand pose", Category.ANIMATIONS, true, true));
	public static final Setting SW_MODE = SWING.add(Setting.mode("mode", "Animation", 1,
		"Vanilla", "Smooth", "Slash", "Slide", "Block", "Spin", "Poke", "Wave", "Drop"));
	public static final Setting SW_POSE = SWING.add(Setting.mode("pose", "Hand pose", 0,
		"Default", "Horizontal", "Low", "Tilted", "Block Pose", "Forward"));
	public static final Setting SW_POWER = SWING.add(Setting.num("power", "Strength", 1.0, 0.3, 1.5, 0.1));
	public static final Setting SW_SCALE = SWING.add(Setting.num("scale", "Item scale", 1.0, 0.4, 1.6, 0.05));

	// ───────────── Utility ─────────────
	public static final Module GPS = reg(new Module("GPS", "Waypoint arrow, .gps x z, event auto-detect", Category.UTILITY, true, true));
	public static final Setting GPS_AUTO = GPS.add(Setting.bool("auto", "Auto from chat events", true));
	public static final Setting GPS_MARKER = GPS.add(Setting.bool("marker", "World marker", true));
	public static final Setting GPS_DEATH = GPS.add(Setting.bool("death", "Mark death point", true));
	public static final Setting GPS_ARRIVE = GPS.add(Setting.num("arrive", "Arrive radius", 6, 2, 30, 1));

	public static final Module ELYTRA = reg(new Module("Elytra helper", "Keys: swap elytra/chestplate, firework", Category.UTILITY, true, true));
	public static final Setting EL_NOTIFY = ELYTRA.add(Setting.bool("notify", "Chat feedback", true));

	public static final Module ASPECT = reg(new Module("Aspect ratio", "Stretch the game image (4:3, 21:9...)", Category.UTILITY, false, true));
	public static final Setting AS_RATIO = ASPECT.add(Setting.mode("ratio", "Ratio", 1, "Window", "4:3", "5:4", "16:10", "1:1", "21:9", "32:9", "Custom"));
	public static final Setting AS_CUSTOM = ASPECT.add(Setting.num("custom", "Custom ratio", 1.5, 0.8, 3.6, 0.05));

	public static final Module BREW = reg(new Module("Brew helper", "Recipe cheat sheet at the brewing stand", Category.UTILITY, true, true));
	public static final Setting BR_ICONS = BREW.add(Setting.bool("icons", "Show icons", true));

	public static final Module OPTIMIZATION = reg(new Module("Optimization", "Raises FPS without visible changes", Category.UTILITY, false, true));
	public static final Setting OP_LEVEL = OPTIMIZATION.add(Setting.mode("level", "Level", 1, "Light", "Balanced", "Max"));
	public static final Setting OP_ADAPT = OPTIMIZATION.add(Setting.bool("adapt", "Adaptive quality", true));

	// ───────────── Theme ─────────────
	public static final Module THEME = reg(new Module("Interface", "Theme, glass style, font", Category.THEME, true, false));
	public static final Setting TH_ACCENT = THEME.add(Setting.mode("accent", "Theme", 0, Theme.NAMES));
	public static final Setting TH_SECOND = THEME.add(Setting.mode("second", "Second color", 0, "Preset", "Complement", "Analogous", "White"));
	public static final Setting TH_SHIMMER = THEME.add(Setting.num("shimmer", "Shimmer", 0.7, 0.0, 1.0, 0.05));
	public static final Setting TH_SPEED = THEME.add(Setting.num("shimmer_speed", "Shimmer speed", 1.0, 0.2, 3.0, 0.1));
	public static final Setting TH_TINT = THEME.add(Setting.num("tint", "Glass tint", 0.10, 0.0, 0.4, 0.02));
	public static final Setting TH_HUE = THEME.add(Setting.num("hue", "Hue (Custom)", 215, 0, 360, 5));
	public static final Setting TH_SAT = THEME.add(Setting.num("sat", "Saturation (Custom)", 0.65, 0.2, 1.0, 0.05));
	public static final Setting TH_VAL = THEME.add(Setting.num("val", "Brightness (Custom)", 1.0, 0.5, 1.0, 0.05));
	public static final Setting TH_OPACITY = THEME.add(Setting.num("opacity", "Glass opacity", 0.62, 0.3, 1.0, 0.02));
	public static final Setting TH_RADIUS = THEME.add(Setting.num("radius", "Corner radius", 5, 0, 8, 1));
	public static final Setting TH_HUDSTYLE = THEME.add(Setting.mode("hud_style", "HUD style", 0, "Glass", "Solid", "Minimal"));
	public static final Setting TH_FONTSTYLE = THEME.add(Setting.mode("font_style", "Font style", 0, "Poppins", "Carlito", "Minecraft"));
	public static final Setting TH_SHADOW = THEME.add(Setting.bool("shadow", "Text shadow", true));
	public static final Setting TH_TITLE = THEME.add(Setting.bool("title", "Custom main menu", true));
	public static final Setting TH_LANG = THEME.add(Setting.mode("lang", "Language", 0, "Auto", "English", "Русский"));

	private Modules() {}
}
